(Back to the) Futura
=======================

Scraper framework for handling divergent POI scraping implementations.

Preamble
-----------

Futura is a Python library suitable for serving as a framework for both Scrapy_ and BeautifulSoup_-based POI scrapers. How it accomplishes such is by adapting BeautifulSoup_-based scrapers into a Scrapy-compatible form. Provided one follows the guidelines below regarding Scrapy_ or BeautifulSoup_-based implementations, there should be little friction between how one currently does a scraper and how one implementats a Futura scraper.

Futura is written in Python 3 and is known compatible with Python 3.6. You may install Python 3.6 on your laptop either by using the `official downloads <https://www.python.org/downloads/>`_ or by using an alternative installation method. If you're using OSX, it is highly recommended that you utilize Homebrew_ to manage installation of Python 3.6 (via ``brew install python3``). Futura is designed to live within a venv, virtualenvironment or user-owned install. With that in mind, at no point should you ever type ``sudo pip`` unless you know precisely what you're doing.

Design
-------

Futura wraps the Scrapy_ framework within a more controlled interface and provides an easily-adapted-to variant of the BeautifulSoup_ approach seen in the `POI Scraping`_ repository.


Installation
--------------

Futura can be installed in three steps.::

    $ cd /path/to/futura
    $ python3.6 -m pip install -e .

After that, any additional ``git pull``s will automatically update the Futura (barring of course any change in dependencies or package structure. In such a case, you will need to redo the third step).

If you wish to have MySQL support, you will need to install the MySQL client::

    $ python3.6 -m pip install --egg https://github.com/mysql/mysql-connector-python/archive/2.2.2.zip

However, it is expected that most development will take place using the `stdout`_ or `csv`_ pipelines.

Pipelines
----------

csv
****

Intended for mass-validation and ``LOAD DATA INFILE`` on MySQL.

Use case::

    $ python3.6 -m futura futura.scrapers.apple_stores.apple_au -p csv:filename=apple.csv
    [futura] [2017-02-13 17:30:46,493] [PID 17656] [INFO] Begin Scraping
    [futura.support.bs4] [2017-02-13 17:30:46,496] [PID 17656] [INFO] Starting apple_stores.apple_au
    [futura] [2017-02-13 17:34:52,431] [PID 17656] [INFO] Scraping took 245.94s

The CSV pipeline will take results from scrapers and will write them to a CSV file (defaults as ``output-%Y-%m-%d.csv``).

stdout
*******

This is intended to be a quick method of checking if the data output is correct while developing.

Use case::

    $ python3.6 -m futura futura.scrapers.apple_stores.apple_au -p stdout
    [futura] [2017-02-13 17:31:35,752] [PID 17788] [INFO] Begin Scraping
    [futura.support.bs4] [2017-02-13 17:31:35,755] [PID 17788] [INFO] Starting apple_stores.apple_au
    {'brand_id': 285, 'brand_name': 'Apple Store', 'store_name': 'YES OPTUS - RICHMOND', 'address_1': '126 SWAN ST ', 'address_2': None, 'city': 'RICHMOND', 'state': 'VIC', 'zipcode': '3121', 'country_code': 'AU', 'latitude': -37.826, 'longitude': 144.994, 'phone_number': '', 'url': 'https://locate.apple.com/au/en/sales/?pt=all&lat=-37.823002&lon=144.998001', 'del': False, 'updatedDate': datetime.datetime(2017, 2, 14, 1, 31, 42, 67837)}
    ... snip ..
    [futura] [2017-02-13 17:34:52,431] [PID 17656] [INFO] Scraping took 245.94s

database
**********

This is intended for production use only.


Supported Approaches
-----------------------

Scrapy-based
**************

Scrapy is natively supported by Futura in a more restricted context. See the `24hourfitness <futura/scrapers/24hourfitness/24hourfitness_com.py>`_ for an example.

You should ``yield`` scrapy Requests and StoreLocations (which implement the Scrapy Item inteface).

BeautifulSoup-based
*********************

BeautifulSoup/Requests is also supported. See the `Apple Store <futura/scrapers/apple_stores/apple_au.py>`_ for an example. Of note, the use of ``yield`` and ``yield from``.

Use ``yield`` to give back ``requests.get`` (and other requests operations) and StoreLocations.

Use ``yield from`` for calling subroutines (like the use of ``extractor``).

Finally, the entry point (``seeder``) **must** be decorated with ``@register`` and a URL (or set of urls).

Example::

    @register('url1', 'url2')
    def seeder(url):
        req = yield requests.get(url)
        print('{} got {}'.format(req.url, req.text))

Bug Reporting
----------------

Futura is new and therefore will have bugs. Such is software. Please report bugs immediately. Be sure to document:

    - What OS are you using? (Windows/Mac/Linux)
    - When this issue occurred?
    - What did you see on the terminal?
    - Does this issue come and go?


.. _Scrapy: https://scrapy.org/
.. _BeautifulSoup: https://www.crummy.com/software/BeautifulSoup/
.. _Homebrew: https://brew.sh/
.. _`POI Scraping`: https://github.com/xadrnd/poi_scraping
