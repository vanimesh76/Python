import sys
import time
import logging
import textwrap

from scrapy.crawler import CrawlerProcess
from terminaltables import SingleTable, AsciiTable

from .scrapers import Scrapers
from .support.pipelines import PIPELINES


handler = logging.StreamHandler()
handler.setLevel(logging.DEBUG)
handler.setFormatter(
    logging.Formatter('[%(name)s] [%(asctime)s] [PID %(process)d] [%(levelname)s] %(message)s'))

logger = logging.getLogger('futura')
logger.setLevel(logging.INFO)
logger.addHandler(handler)
logger.propagate = False

requests_logger = logging.getLogger('requests')
requests_logger.setLevel(logging.INFO)
requests_logger.addHandler(handler)
requests_logger.propagate = False

scrapy_logger = logging.getLogger('scrapy')
scrapy_logger.setLevel(logging.INFO)
scrapy_logger.addHandler(handler)
scrapy_logger.propagate = False


if __name__ == '__main__':
    import argparse
    if sys.stdout.isatty():
        table_cls = SingleTable
    else:
        table_cls = AsciiTable

    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', help='debug mode', action='store_true', default=None)
    parser.add_argument(
        '--list-spiders', help='List all available spiders', action='store_true',
        default=None)
    parser.add_argument(
        '--list-pipelines', help='List all pipelines', action='store_true', default=None)
    parser.add_argument(
        '-p', '--pipeline', default=None, metavar='PIPELINE',
        help='Pipeline to use. Available ones are: {}'.format(
            ''.join(x.__name__ for x in PIPELINES)))
    parser.add_argument(
        'parser', nargs='*', default=[],
        help='Parser(s) to use. If you specify `all`, then all will be used.')
    args = parser.parse_args()
    if args.debug:
        for x in (logger, requests_logger, scrapy_logger):
            x.setLevel(logging.DEBUG)
    args.parser = tuple(args.parser)
    if args.parser:
        if args.parser == ('all',):
            args.parser = tuple(Scrapers.keys())
        parsers = {
            key: Scrapers.get(key)
            for key in args.parser
        }
        for key, value in parsers.items():
            if value is None:
                print('Cannot find a spider by the name of {!r}!'.format(key))
        if any(value is None for value in parsers.values()):
            raise SystemExit(1)
        args.parser = tuple(parsers.values())

    if any((args.list_spiders, args.list_pipelines)):
        if args.list_spiders:
            print('Spiders Available:')
            data = [
                ['scraper', 'name', 'urls'],
            ]
            for scraper_name in Scrapers:
                scraper = Scrapers[scraper_name]
                data.append([scraper_name, scraper.name, scraper.urls])
            table = table_cls(data)
            print(table.table)
        if args.list_pipelines:
            print('Pipelines Available:')
            data = [
                ['name', 'cls', 'description'],
            ]
            for pipeline in PIPELINES:
                data.append(
                    [pipeline.name, repr(pipeline),
                     textwrap.dedent(getattr(pipeline, 'description', '')).strip()])
            table = table_cls(data)
            print(table.table)
        raise SystemExit

    if not args.pipeline:
        raise SystemExit('Please select a pipeline or use `--list`. Options: {}'.format(
            ', '.join(x.name for x in PIPELINES)))
    if args.pipeline.split(':', 1)[0] not in frozenset(x.name for x in PIPELINES):
        raise SystemExit('Please select a valid pipeline or use `--list`. Options: {}'.format(
            ', '.join(x.name for x in PIPELINES)))
    pipeline_args = args.pipeline.split(':', 1)
    if len(pipeline_args) > 1:
        args.pipeline, pipeline_args = pipeline_args[0], pipeline_args[1].split(':')
    else:
        pipeline_args = []

    pipeline_settings = {}
    pipeline_settings['pipeline_kwargs'] = {}
    pipeline_settings['pipeline_varargs'] = []

    for pipeline in PIPELINES:
        if pipeline.name == args.pipeline:
            for item in pipeline_args:
                if '=' in item:
                    key, value = item.split('=', 1)
                    pipeline_settings['pipeline_kwargs'][key] = value
                else:
                    pipeline_settings['pipeline_varargs'].append(item)
            break
    pipeline_settings = dict(pipeline_settings)

    runner = CrawlerProcess()
    runner.settings['ITEM_PIPELINES']['futura.support.pipelines.{}'.format(pipeline.__name__)] = 100
    runner.settings['LOG_ENABLED'] = False
    runner.settings['LOG_LEVEL'] = 'INFO'
    runner.settings.update(pipeline_settings)

    for scraper in args.parser:
        scraper().run(runner)
    logger.info('Begin Scraping')
    t_s = time.time()
    runner.start()
    logger.info('Scraping took {:.2f}s'.format(time.time() - t_s))

