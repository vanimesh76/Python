import functools
import inspect
import logging
import sys
import time
import types
from collections import namedtuple

import requests_cache
from scrapy.crawler import CrawlerProcess
from scrapy.http import Request
from scrapy.spiders import Spider
from scrapy.item import BaseItem

from . import async_requests
from ..atomic import IScraper
from .async_requests import convert_response, convert_request


async_requests.patch()

logger = logging.getLogger(__name__)


class RequestArguments(namedtuple('RequestArguments', ['url', 'headers', 'cookies'])):
    def __new__(cls, url, headers=None, cookies=None):
        if headers is None:
            headers = {}
        if cookies is None:
            cookies = {}
        if not isinstance(headers, dict):
            raise ValueError('headers must be a dictionary or None!')
        if not isinstance(cookies, dict):
            raise ValueError('cookies must be a dictionary or None')
        return super(cls, cls).__new__(cls, url, headers, cookies)


class BeautifulSoupScraper(IScraper, Spider):
    _import_name = None
    urls = ()

    def __init__(self, name=None, locations=None):
        self.name = name or self._import_name.split('.', 2)[-1]
        self._started_func = False

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        import requests_cache
        requests_cache.install_cache(backend='memory')
        spider = cls(*args, **kwargs)
        spider._set_crawler(crawler)
        return spider

    def start_requests(self):
        logger.info('Starting {}'.format(self.name))
        for url_data in self.urls:
            headers = {}
            cookies = {}
            url, *rest = url_data
            logger.debug('[{}] Operating on {}'.format(self.name, url))
            if rest:
                headers, *rest = rest
                logger.debug('[{}] Using initial headers {}'.format(self.name, headers))
            if rest:
                cookies, *rest = rest
                logger.debug('[{}] Using initial cookies {}'.format(self.name, cookies))
            if rest:
                logger.debug('[{}] Ignoring extra data {}'.format(self.name, rest))

            req = Request(
                url,
                callback=self.cache_and_seed, headers=headers, cookies=cookies)
            if len(url_data) == 1:
                req.url_data = url
            else:
                req.url_data = url_data
            yield req

    def cache_and_seed(self, response):
        logger.debug('Got a response for {}'.format(self.__class__.__name__))
        url_data = response.request.url
        _response = convert_response(response)
        _request = _response.request
        cache_ = requests_cache.core.get_cache()

        key = cache_.create_key(_request)
        cache_.save_response(key, _response)
        logger.debug('Saving {} -> {}'.format(key, response.url))

        if self._started_func:
            logger.debug('Aborting')
            return
        self._started_func = True

        logger.debug('[{}] Fetching module'.format(self.name))
        logger.debug('[{}] Beginning run'.format(self.name))
        t_s = time.time()
        module = sys.modules[self._import_name]
        self.gen = module.seeder(url_data)
        assert isinstance(self.gen, types.GeneratorType), \
            '{}.seeder does not have any yields in it!'.format(
                module.__name__)

        item = next(self.gen)
        logger.debug('{} yielded {!r}'.format(self._import_name, item))
        while not hasattr(item, 'callback'):
            assert isinstance(item, (Request, BaseItem)), \
                '{!r} is not a request.get(..)/request.post(..)/etc result or a supported \
result item (like StoreLocation). Did you forget a ``yield from`` for a subroutine?'.format(item)
            yield item
            try:
                item = next(self.gen)
            except StopIteration:
                break
            logger.debug('{} yielded {!r}'.format(self._import_name, item))
        else:
            item.callback = functools.partial(self.cache_and_seed_item, item)
            yield item
        logger.debug('[{}] finished in {:.2f}'.format(self.name, time.time() - t_s))

    def cache_and_seed_item(self, item, response):
        _response = convert_response(response)
        _request = _response.request
        cache_ = requests_cache.core.get_cache()
        key = cache_.create_key(_request)
        cache_.save_response(key, _response)
        logger.debug('Saving {} -> {}'.format(key, response.url))

        _request = convert_request(item)
        cache_ = requests_cache.core.get_cache()

        cache_key = cache_.create_key(_request)
        response, timestamp = cache_.get_response_and_time(cache_key)
        logger.debug('Getting {} -> {} -> {}'.format(cache_key, item.url, response))
        # assert response, '{} not found!?'.format(item.url)
        item = self.gen.send(response)
        while not hasattr(item, 'callback'):
            assert isinstance(item, (Request, BaseItem)), \
                '{!r} is not a request.get(..)/request.post(..)/etc result or a supported \
result item (like StoreLocation). Did you forget a ``yield from`` for a subroutine?'.format(item)

            yield item
            try:
                item = next(self.gen)
            except StopIteration:
                break
            logger.debug('{} yielded {!r}'.format(self._import_name, item))
        else:
            item.callback = functools.partial(self.cache_and_seed_item, item)
            yield item

    def run(self, process=None):
        if process is None:
            process = CrawlerProcess()
        process.crawl(self, self.name)
        return process


def register(*urls):
    caller_sandbox = inspect.currentframe().f_back.f_locals.copy()
    last_url_index = 0
    _urls = urls[:]
    urls = []
    for url in _urls:
        if isinstance(url, str):
            last_url_index += 1
            urls.append((url,))
        elif isinstance(url, RequestArguments):
            urls.append(url)
            last_url_index += 1
        else:
            urls[last_url_index] += (url,)
    from .. import scrapers
    scraper_name = caller_sandbox['__name__']
    nice_name = scraper_name.rsplit('.', 1)[-1]
    cls = type(nice_name, (BeautifulSoupScraper,), {
        '_import_name': scraper_name,
        'urls': tuple(urls),
        'name': nice_name
        })
    scrapers.Scrapers[scraper_name] = cls

    def wrapper(func):
        @functools.wraps(func)
        def wrapped(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapped
    return wrapper
