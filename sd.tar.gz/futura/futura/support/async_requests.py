import inspect
import requests as _requests
import scrapy.http

REQUEST_TYPES = {
    scrapy.http.Request: _requests.PreparedRequest,
    _requests.PreparedRequest: scrapy.http.Request,
}

DEFAULT_REASONS = {
    200: "Ok",
    404: "Not Found",
    500: "Internal Server Error",
    403: "Forbidden",
    301: "Permanently Redirected",
    302: "Temporarily Redirected",
}


def convert_request(request):
    assert isinstance(request, (scrapy.http.Request, _requests.Request, _requests.PreparedRequest))
    cls = REQUEST_TYPES[type(request)]
    kwargs = {}
    if cls is scrapy.http.Request:
        kwargs['url'] = request.url
        kwargs['dont_filter'] = True
    r = cls(**kwargs)
    if cls is _requests.PreparedRequest:
        r.url = request.url
        r.headers = _requests.structures.CaseInsensitiveDict()

    r.method = request.method
    for key in sorted(request.headers):
        r.headers[key] = request.headers[key]
    if hasattr(r, '_set_body'):
        r._set_body(request.body)
    else:
        r.body = request.body
    return r


def convert_response(response):
    '''
    Convert from scrapy.http.Response to Requests.Response
    '''
    assert isinstance(response, scrapy.http.Response)
    r = _requests.Response()
    r.url = response.url
    r.status_code = response.status
    for key in response.headers:
        r.headers[key] = response.headers[key]
    r._content_consumed = True
    r._content = response.body
    r.reason = DEFAULT_REASONS.get(r.status_code, 'Unknown')
    r.encoding = r.headers.get('content-encoding') or r.apparent_encoding
    session = _requests.Session()
    req = convert_request(response.request)
    if not isinstance(req, _requests.PreparedRequest):
        req = session.prepare_request(req)
    r.request = req
    return r


def wrap_request(func):
    if hasattr(func, '__wrap_wrap__'):
        return func
    orig_request = func

    def scrapy_request(method, url, **kwargs):
        frame = inspect.currentframe().f_back
        try:
            i = 0
            while frame:
                i += 1
                scope = frame.f_globals
                if '__name__' in scope and scope['__name__'].startswith(__name__.rsplit('.', 2)[0]):
                    break
                if i == 2:
                    break
                frame = frame.f_back
            else:
                return orig_request(method, url, **kwargs)
        except AttributeError:
            return orig_request(method, url, **kwargs)
        for key in ('timeout', 'allow_redirects'):
            if key in kwargs:
                del kwargs[key]
        r = _requests.Request(method, url, **kwargs)
        return convert_request(r.prepare())
    scrapy_request.__wrap_wrap__ = True
    return scrapy_request


def patch():
    _requests.api.request = wrap_request(_requests.api.request)
