import datetime
import logging
try:
    from mysql.connector import MySQLConnection
except ImportError:
    MySQLConnection = None

logger = logging.getLogger(__name__)
PIPELINES = set()
INSERT_QUERY = \
    ''' INSERT IGNORE INTO scrapers.locations
        VALUES
            {}
    '''
INSERT_ROW_TEMPLATE = '''
    (
        %(brand_name)s, %(store_name)s, %(type)s, %(address_1)s,
        %(city)s, %(state)s, %(zipcode)s, %(country_code)s, %(phone_number)s,
        %(primary_sic)s, %(secondary_sic)s, %(latitude)s, %(longitude)s,
        %(brand_id)s, %(raw_address)s, %(updated_date)s, %(url)s
    )
    '''.strip()


def register(cls):
    PIPELINES.add(cls)
    name = cls.__name__
    if name.lower().endswith('pipeline'):
        index = name.lower().rindex('pipeline')
        name = name[:index]
    cls.name = name.lower()
    return cls


class AbstractPipeline(object):
    @classmethod
    def from_crawler(cls, crawler):
        return cls(*crawler.settings['pipeline_varargs'], **crawler.settings['pipeline_kwargs'])


@register
class StdoutPipeline(AbstractPipeline):
    description = '''
        Standard Out Pipeline. Will print each item as it gets it to stdout.
    '''

    def process_item(self, item, spider):
        print(item.serialize())


@register
class CSVPipeline(AbstractPipeline):
    description = '''
        CSV Pipeline.

        Arguments:
            filename: path to CSV filename.

        Example:
            -p csv:filename=my_output_file.csv
            -p csv:my_output_file.csv
    '''

    def __init__(self, filename=None):
        if filename is None:
            filename = datetime.datetime.now().strftime('output-%Y-%m-%d.csv')
        self.filename = filename
        self.write_header = True

    def open_spider(self, spider):
        self.fh = open(self.filename, 'a+')

    def close_spider(self, spider):
        self.fh.close()
        self.fh = None

    def process_item(self, item, spider):
        if self.write_header:
            self.fh.seek(0)
            data = self.fh.read(1)
            if data and data == '#':
                self.write_header = False
            self.fh.seek(0, 2)
        item.to_csv(self.fh, write_header=self.write_header)
        self.write_header = False

if MySQLConnection:
    @register
    class DatabasePipeline(AbstractPipeline):
        description = '''
            Database Pipeline.

            Ingests into the database.

            Arguments:
                host: Database host (defaults to localhost)
                username: Database username (defaults to root)
                password: Database password (defaults to venableroot)
                port: Database port (defaults to 3306)

            Examples:
                -p database:db.xad.com:root:password:3307
                -p database:username=ben
        '''

        def __init__(self, host= "10.100.10.46", username = "root", password ="india@123", port = "3306", batch_size=10):
            self.host = host
            self.username = username
            self.password = password
            self.port = port
            self.queue = []
            if isinstance(batch_size, str):
                batch_size = int(batch_size, 10)
            self.batch_size = batch_size
            self.conn = None

        def open_spider(self, spider):
            self.conn = MySQLConnection(
                host=self.host, user=self.username, password=self.password, port=self.port)

        def process_item(self, item, spider):
            if len(self.queue) + 1 >= self.batch_size:
                self.flush()
            self.queue.append(item)

        def close_spider(self, spider):
            self.flush()
            self.conn.close()

        def flush(self):
            if not self.queue:
                return

            rows = []
            items = self.queue[:]
            self.queue[:] = []
            try:
                self.conn.start_transaction()
                cursor = self.conn.cursor(dictionary=True)
                values = {}

                for index, location in enumerate(items):
                    local_values = location.bind_index(index).to_mysql()
                    values.update(local_values)
                    local_keys = location.bind_index(index).key_mapping
                    rows.append(INSERT_ROW_TEMPLATE % {
                        key: '%({})s'.format(value) for key, value in local_keys.items()
                    })
                query = INSERT_QUERY.format(',\n\t\t'.join(rows))
                cursor.execute(query, values)
            except Exception:
                logger.exception('Unexpected fault!')
                self.conn.rollback()
            else:
                self.conn.commit()

PIPELINES = frozenset(PIPELINES)
