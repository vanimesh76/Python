import inspect
import logging
from abc import ABCMeta

from scrapy.crawler import CrawlerProcess


logger = logging.getLogger(__name__)


class AbstractScrapySupport(ABCMeta):
    def __new__(cls, class_name, bases, attrs):
        cls = super().__new__(cls, class_name, bases, attrs)
        if class_name != "ScrapySupport":
            from .. import scrapers
            caller_sandbox = inspect.currentframe().f_back.f_locals.copy()
            # Register the module name into the Scrapers mapping
            scrapers.Scrapers[caller_sandbox['__name__']] = cls
            cls.urls = tuple(cls.start_urls)
            cls.name = cls.__name__
        return cls


class ScrapySupport(metaclass=AbstractScrapySupport):
    def start_requests(self):
        logger.info('Starting {}'.format(self.name))
        yield from super().start_requests()

    def run(self, process=None):
        if process is None:
            process = CrawlerProcess()
        process.crawl(self)
        return process
