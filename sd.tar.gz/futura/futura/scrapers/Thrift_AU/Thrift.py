import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    try:
        Address = soup.find("span",{"itemprop":"streetAddress"}).text
        City = soup.find("span",{"itemprop":"addressLocality"}).text
        State = soup.find("span",{"itemprop":"addressRegion"}).text
        Zip = soup.find("span",{"itemprop":"postalCode"}).text
        Phone = soup.find("span",{"itemprop":"telephone"}).text.replace(" ","")
        lat = re.findall("\!3d(.*?)\!",data.text)[0]
        lon = re.findall("\!2d(.*?)\!",data.text)[0]
    except:
        aa = soup.find("div",{"class":"mid-standard-listings"})
        cc = aa.find_all("p")[1].text.split("\n")
        if len(cc)==3:
            Address = aa.find_all("p")[1].text.split("\n")[0]
            City = aa.find_all("p")[1].text.split("\n")[1]
            State = aa.find_all("p")[1].text.split("\n")[2].split(" ")[0]
            Zip = aa.find_all("p")[1].text.split("\n")[2].split(" ")[1]
            Phone = ''.join(re.findall("\d+",aa.find_all("p")[2].text))
            try:
                lat = re.findall("\!3d(.*?)\!",data.text)[0]
                lon = re.findall("\!2d(.*?)\!",data.text)[0]
            except:
                lat = re.findall("\;ll\=(.*?)\&",data.text)[0].split(",")[0]
                lon = re.findall("\;ll\=(.*?)\&",data.text)[0].split(",")[1]
        else:
            Address = aa.find_all("p")[1].text.split("\n")[0]
            City = ""
            State = aa.find_all("p")[1].text.split("\n")[1].split(" ")[0]
            Zip = aa.find_all("p")[1].text.split("\n")[1].split(" ")[1]
            Phone = ''.join(re.findall("\d+",aa.find_all("p")[2].text))
            lat = re.findall("\!3d(.*?)\!",data.text)[0]
            lon = re.findall("\!2d(.*?)\!",data.text)[0]
    BrandName = "Thrift"
    BussinessName = "Thrift"
    StoreType = ""
    Country = "AU"
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BussinessName,
        address_1=Address,
        type=StoreType,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    linkss = []
    urll = ["https://www.thrifty.com.au/car-hire/nsw/sydney-and-surrounds.aspx","https://www.thrifty.com.au/car-hire/nsw/other-nsw.aspx","https://www.thrifty.com.au/car-hire/queensland.aspx","https://www.thrifty.com.au/car-hire/south-australia.aspx","https://www.thrifty.com.au/car-hire/tasmania.aspx","https://www.thrifty.com.au/car-hire/victoria.aspx"]
    for k in urll:
        data = yield requests.get(k)
        soup = BeautifulSoup(data.text,"lxml")
        a = soup.find_all("tbody")[1]
        for j in a.find_all("td"):
            if j.text != "":
                linkss.append("https://www.thrifty.com.au"+j.a['href'])
    url = "https://www.thrifty.com.au/car-hire/northern-territory.aspx"
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("table",{"style":"width:100%"})[2].find_all("a"):
        linkss.append("https://www.thrifty.com.au"+i['href'])
    url = "https://www.thrifty.com.au/car-hire/western-australia.aspx"
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("table",{"style":"width:100%"})[1].find_all("a"):
        linkss.append("https://www.thrifty.com.au"+i['href'])
    linkss.append("https://www.thrifty.com.au/car-hire/canberra-airport.aspx")
    linkss.append("https://www.thrifty.com.au/car-hire/canberra.aspx")
    linkss.append("https://www.thrifty.com.au/car-hire/Ayers-Rock-Airport.aspx")
    for l in linkss:
        if "about" not in l.lower():
            yield from extractor(l)