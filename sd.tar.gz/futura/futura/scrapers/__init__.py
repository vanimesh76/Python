import os
import pkg_resources
import logging
import sys
import imp
from collections import OrderedDict

logger = logging.getLogger(__name__)

Scrapers = OrderedDict()
ROOT = os.path.dirname(os.path.abspath(__file__))


def load_spider(module_name, path=''):
    module_name_path = module_name
    module_name_path = '.'.join(x for x in (module_name_path,) + os.path.split(path) if x)
    logger.debug('Loading Spiders for {}'.format(module_name_path))
    for filename, file_path in ((f, os.path.join(path, f)) for
                                f in pkg_resources.resource_listdir(module_name, path)):
        if filename.endswith('.py') and not filename.startswith('__'):
            name = filename[:-len('.py')]
            if path:
                name = '.'.join(os.path.split(path) + (name,))
            if name.startswith(('/', '.')):
                name = name[1:]

            with pkg_resources.resource_stream(module_name, file_path) as fh:
                try:
                    parent = sys.modules['.'.join((module_name, path))]
                except KeyError:
                    parent = sys.modules['.'.join((module_name, path))] = \
                        imp.new_module('.'.join((module_name, path)))

                patch = {
                    '__name__': '.'.join((module_name, path, filename[:-3])),
                    '__file__': file_path,
                    '__package__': parent.__name__
                }
                _globals = dict(globals(), **patch)
                mod = imp.new_module(patch['__name__'])
                mod.__dict__.update(_globals)
                sys.modules[_globals['__name__']] = mod
                exec(compile(fh.read(), os.path.join(ROOT, file_path), 'exec'), mod.__dict__)
        elif not filename.endswith('.py') and pkg_resources.resource_isdir(module_name, filename):
            load_spider(module_name, filename)

load_spider(__name__)
