import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        a = soup.find("div",{"class":"store-description top-left-absolute white s-padding"}).p.text.replace("UK","").strip(" ").strip("\n").strip(" ").split("\n")
        if len(a)>1:
            Country = "UK"
            State = ""
            Phone = ""
            if len(a)==4:
                Address = a[0]
                City = a[1]
                State = a[2]
                Zip = a[3]
            elif len(a)==3:
                Address = a[0]
                City = a[1]
                Zip = a[2]
            elif len(a)==5:
                Address = a[0]
                City = a[1]
                State = a[2]
                Zip = a[3]
            elif len(a)==2:
                Address = a[0]
                City = a[1]
                Zip = ""
            try:
                Phone = ''.join(re.findall("\d+",soup.find("a",{"itemprop":"telephone"}).text))
            except:
                Phone = ""
            BussinessName = ""
            lat = re.findall("lat\:(.*?)\,",re.findall("var ShopPosition \= \{(.*?)\}\;",data.text.replace("\n",""))[0])[0].strip(" ")
            lon = re.findall("lng\:(.*?)$",re.findall("var ShopPosition \= \{(.*?)\}\;",data.text.replace("\n",""))[0])[0].strip(" ")
            BrandName = "Aquascutum"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=None,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                raw_address = Rawaddress,
                url=url)
            yield location
        else:
            print(url)
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("http://www.aquascutum.com/asia/stores/united-kingdom")
def seeder(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    v = soup.find("main",{"class":"move-on-open-menu"})
    for i in v.find_all("a"):
        print (i['href'])
        if "online" not in i['href']:
            yield from extractor("http://www.aquascutum.com/asia"+i['href'])