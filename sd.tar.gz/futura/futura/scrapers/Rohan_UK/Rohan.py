import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data =yield requests.get(url)
    a = json.loads(re.findall("areas \= (.*?)\}\]\;",data.text)[0]+"}]")
    for i in a:
        for j in i['Stores']:
            Phone = ''.join(re.findall("\d+",j['TelephoneNumber']))
            lat = j['Latitude']
            lon = j['Longitude']
            c = len(j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>"))
            if c==6:
                Zip = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-2]
                Country = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-1]
                City = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-3]
                Address = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-4]
                BussinessName = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[1]
            else:
                Zip = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-2]
                Country = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-1]
                City = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-3]
                Address = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-4]+" "+ j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[-5]
                BussinessName = j['Address'].replace("</li>","").replace("<ul>","").replace("</ul>","").split("<li>")[1]           
            BrandId = None
            State = ""
            Country = "GB"
            BrandName = "Rohan"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=BrandId,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=None,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("http://www.rohan.co.uk/Home/ShopFinder/All")
def seeder(url):
    yield from extractor(url)