import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("div",{"class":"storefinder-search-store"}):
        Phone = ''.join(re.findall("\d+",i.find("div",{"class":"storefinder-search-store-data storefinder-search-store-telephone-number"}).text))
        lon = i['data-lng']
        lat = i['data-lat']
        State = ""
        a = i['data-address'].split("\n")
        if len(a)==5:
            Zip = a[-1]
            State = a[-2].replace("United Kingdom","")
            City = a[-3].split(",")[0]
            try:
                State = a[-3].split(",")[1]
            except:
                pass
            Address = ' '.join(a[:2])
        elif len(a)==4:
            Zip = a[-1]
            try:
                City =a[-2].strip(", \r").split(",")[1]
            except:
                City = a[-2].strip(", \r")
            Address = ' '.join(a[:2]).replace("  "," ")
        elif len(a)==3:
            Zip = a[-1].split(",")[-1].strip()
            City = a[-1].split(",")[0].strip().replace(Zip,"")
            Address = a[0]
            if City == "":
                City = a[1]
            else:
                Address =Address+" "+a[1]
            Address = Address.replace("\r","")
        elif len(a)==2:
            Zip = re.findall("\w+\d+ \d\w+",a[-1])[0]
            City = a[-1].replace(Zip,"")
            Address = a[0]
        elif len(a)==1:
            Zip = re.findall("\w+\d+ \d\w+",a[0])[0]
            City = ""
            Address = a[0].replace(Zip,"").strip(", ")
        BrandName = "Menkind"
        BussinessName = "Menkind"
        Country = "UK"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address.replace("\r","").strip(),
            type=StoreType,
            city=City.replace("\r","").strip(),
            state=State.strip(),
            zipcode=Zip.strip(),
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.menkind.co.uk/storelocator/")
def seeder(url):
    yield from extractor(url)