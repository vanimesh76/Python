import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("poi"):
        BussinessName = i.find("name").text
        Address = i.address1.text+" "+i.address2.text
        City = i.city.text
        Country = i.country.text
        lat = i.latitude.text
        lon = i.longitude.text
        Phone = i.phone.text
        Zip = i.postalcode.text
        BrandName = "Kiehls"
        StoreType = ""
        State = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://hosted.where2getit.com/kiehlsuk/ajax?lang=en_US&xml_request=%3Crequest%3E%3Cappkey%3E23C1CA56-BD86-11E6-B012-078BA38844B8%3C%2Fappkey%3E%3Cformdata+id%3D%22getlist%22%3E%3Cobjectname%3EStoreLocator%3C%2Fobjectname%3E%3Corder%3EICON+DESC%2CNAME%3C%2Forder%3E%3Cwhere%3E%3Ccountry%3E%3Ceq%3EUK%3C%2Feq%3E%3C%2Fcountry%3E%3C%2Fwhere%3E%3C%2Fformdata%3E%3C%2Frequest%3E")
def seeder(url):
    yield from extractor(url)