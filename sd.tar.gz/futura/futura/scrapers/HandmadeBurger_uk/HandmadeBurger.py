import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        a = soup.find("div",{"class":"content-column one_half"}).text.split("\n")
        Phone = ''.join(re.findall("\d+",a[-1]))
        Zip = a[-2]
        City = a[-3]
        Address = ' '.join(a[1:-3])
        Country = "UK"
        State = ""
        geourl = ''.join(['http://geocode.xad.com:8080/xadutils/tools/geocode?country=', Country, '&city=', City, '&zipcode=', Zip, '&address1=', Address, '&state=', State])
        headers = {'X-ACCESS-KEY':'1bb0e458-29d7-4c63-95af-03b19fcb1f91', 'X-APP-ID':'SCRAPE'}
        geores = yield requests.get(geourl, headers = headers)
        geodatajson =  geores.json()
        if 'result' in geodatajson.keys():
            lat = geodatajson['result']['lat']
            lon = geodatajson['result']['lon']
        else:
            lat = 0.0
            lon = 0.0
        BussinessName = ""
        BrandName = "Handmade Burger Company"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state="",
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("http://handmadeburger.co.uk/our-restaurants/")
def seeder(url):
    data= yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    aa = soupp.find("div",{"class":"content col-xs-12"})
    for j in aa.find_all("a"):
        print (j['href'])
        yield from extractor(j['href'])