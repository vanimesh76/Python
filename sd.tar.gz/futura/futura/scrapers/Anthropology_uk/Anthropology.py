import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        for i in soup.find_all("div",{"itemtype":"http://schema.org/LocalBusiness"}) :
            Address = i.find("span",{"itemprop":"streetAddress"}).text
            City = i.find("span",{"itemprop":"addressLocality"}).text
            State = i.find("span",{"itemprop":"addressRegion"}).text
            Zip = i.find("span",{"itemprop":"postalCode"}).text
            Phone = ''.join(re.findall("\d+",i.find("span",{"itemprop":"telephone"}).text))
            lat = i.find("meta",{"itemprop":"latitude"})['content']
            lon = i.find("meta",{"itemprop":"longitude"})['content']
            BussinessName = i.find("h1",{"itemprop":"name"}).text
            BrandId = None
            try:
                Zip = Zip.split("-")[0].strip(" ")
            except:
                pass
            if Zip.isdigit():
                Country = "US"
            else:
                Country = "UK"
            BrandName = "Anthropologie"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=None,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("https://www.anthropologie.com/en-gb/store_sitemap.xml")
def seeder(url):
    c = 0
    data = yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    for j in soupp.find_all("loc"):
        print (j.text)
        c +=1
        print (c)
        yield from extractor(j.text)