import logging
import json
import random
import re
import time
import requests
import datetime
import ast
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("article"):
        BussinessName = i.find("h1",{"itemprop":"name"}).text
        Address = i.find("span",{"class":"streetAddress"}).text
        City = i.find("span",{"class":"addressLocality"}).text
        Zip = i.find("span",{"class":"postalCode"}).text
        Phone = ''.join(re.findall("\d+",i.find("p",{"itemprop":"telephone"}).text))
        coor = ast.literal_eval(re.findall("setView\((.*?)\]",str(i))[0]+"]")
        lat = coor[0]
        lon = coor[1]
        StoreType = ""
        BrandName = "Honest Burgers"
        StoreType = ""
        Country = "UK"
        State = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.honestburgers.co.uk/locations/")
def seeder(url):
    yield from extractor(url)