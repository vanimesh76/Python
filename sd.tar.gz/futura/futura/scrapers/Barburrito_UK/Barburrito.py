import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data =yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        a =len(soup.find("address",{"class":"restaurant-contact-address column"}).text.replace("\t","").replace("\r","").replace("  "," ").strip("\n").split("\n"))
        b = soup.find("address",{"class":"restaurant-contact-address column"}).text.replace("\t","").replace("\r","").replace("  "," ").strip("\n").split("\n")
        State = ""
        Zip = ""
        City = ""
        if a==3:
            Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",b[-1])
            if Zip == []:
                Zip = ""
                City = b[-1]
            else:
                Zip = Zip[0]
                City = b[1]
            Address = b[0]
        elif a==4:
            Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",b[-1].strip(" "))
            if Zip ==[]:
                Zip = [b[-1]]
            State = b[-2]
            City = b[1]
            Address = b[0]
            Zip = Zip[0].strip(" ")
        elif a==5:
            Zip = b[-1].strip(" ")
            State = b[-2]
            City = b[-3]
            Address = b[0]+" "+b[1]
        elif a==2:
            City = b[-1]
            Address = b[0]
        Country = "GB"
        lat = re.findall("\d+\.\d+",soup.find("a",{"class":"map-link"})['href'])[0]
        lon = re.findall("\d+\.\d+",soup.find("a",{"class":"map-link"})['href'])[1]
        Phone = ''.join(re.findall("\d+",soup.find("div",{"class":"restaurant-contact-links column"}).a.text))
        BrandId = None
        BrandName = "Barburrito"
        BussinessName = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address.strip(" "),
            type=None,
            city=City.strip(" "),
            state=State.strip(" "),
            zipcode=Zip.strip(" "),
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("https://barburrito.co.uk/sitemap.xml")
def seeder(url):
    data = yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    for i in soupp.find_all("loc"):
        if "https://barburrito.co.uk/restaurants/" in i.text:
            url = i.text
            yield from extractor(url)