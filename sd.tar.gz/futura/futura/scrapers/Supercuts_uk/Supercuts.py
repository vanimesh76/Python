import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    Address = soup.find("div",{"class":"storeAddress"}).text.replace("\r\n","\n").replace("\t","").replace("  ","").replace("Telephone","").replace("Directions from","").replace("Address","").replace("\n\n\n","\n").strip("\n").split("\n")
    Phone = ''.join(re.findall("\d+",Address[-1]))
    Zip = Address[-2]
    State = Address[-4]
    City = Address[-5]
    Address = ' '.join(Address[:-3]).replace(City,"").replace(State,"")
    BrandName = "Supercuts"
    BusinessName = "Supercuts"
    Country = "UK"
    geourl = ''.join(['http://geocode.xad.com:8080/xadutils/tools/geocode?country=', Country, '&city=', City, '&zipcode=', Zip, '&address1=', Address, '&state=', State])
    headers = {'X-ACCESS-KEY':'1bb0e458-29d7-4c63-95af-03b19fcb1f91', 'X-APP-ID':'SCRAPE'}
    geores = yield requests.get(geourl, headers = headers)
    geodatajson =  geores.json()
    if 'result' in geodatajson.keys():
        lat = geodatajson['result']['lat']
        lon = geodatajson['result']['lon']
    else:           
        lat = 0.0           
        lon = 0.0
    print (lat,lon)
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BusinessName,
        address_1=Address,
        type=None,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location

# This registers the seeder(url) to be:
@register("https://www.supercuts.co.uk/page-sitemap.xml")
def seeder(url):
    linkss = []
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("loc"):
        if "locator" in i.text:
            linkss.append(i.text)
    for i in linkss[1:]:
        yield from extractor(i)