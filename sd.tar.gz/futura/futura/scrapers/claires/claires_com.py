# coding:utf-8
import logging
import json
import random
import re
import time
import requests
import sys
import pdb

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, sdch",
        "Accept-Language": "en-US,en;q=0.8",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        # "Cookie": "language_id=1; country_iso=US; default_site=PWS_US; _msuuid_52852r30482=02B92FAE-BF12-451E-9B7B-7BC7872D1BF8; _hjIncludedInSample=1; wingify_push_do_not_show_notification_popup=true; _ga=GA1.2.1582520162.1496724757; _gid=GA1.2.2021606971.1496724757; xyz_cr_939_et_112==NaN&cr=939&et=112&ap=; ki_t=1496724763876%3B1496724763876%3B1496726909774%3B1%3B6; ki_r=; currency_iso=USD; JSESSIONID=E116182517C3208D6D6FBEC1C9F0F26B.ClairesNAfcpapp3a; fcp_shopping_basket=",
        "Host": "www.claires.com",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    }

    #"uncomment the below line to check requests and comment line 34-35"
    #Also change line number 39 to "soup3 = BeautifulSoup(res3.text,"lxml")"
    #which will produce the error: "Request Module has no attribute "Text", althogh we used "requests module"
    res3 = yield requests.get(url, headers=headers, allow_redirects=False)
    soup3 = BeautifulSoup(res3.text, "lxml")

    info = soup3.find('div', {'class': 'row store_details'}).find('address').find_all('em')
    BusinessName = soup3.find('div', {'class':'row store_details'}).find('h2').text
    ZIP = info[-1].text.replace(',', '')
    State = info[-2].text.replace(',', '')
    City = info[-3].text.replace(',', '')
    Address1 = []
    for add in info[:-3]:
        add1 = add.text
        Address1.append(add1)

    Address1 = ' '.join(Address1).replace(',',' ').replace('#',' ').replace('  ',' ')
    try:
        phone = ''.join(re.findall(
            r'\d+',
            soup3.find('div', {'class': 'row store_details'}).find(
                'address').find_next('p').find('strong').text))[:10]
    except:
        phone = None
    try:
        Latitude = float(soup3.find('div', {'id': 'store_map'}).get('data-lat'))
        Longitude = float(soup3.find('div', {'id': 'store_map'}).get('data-lng'))
    except:
        Latitude = 0.0
        Longitude = 0.0
    Country = 'US'

    location = StoreLocation(
        brand_id=None,
        brand_name='Claires',
        store_name=BusinessName,
        address_1=Address1,
        type=None,
        city=City,
        state=State,
        zipcode=ZIP,
        country_code=Country,
        latitude=Latitude,
        longitude=Longitude,
        phone_number=phone,
        url=url)
    yield location


@register('http://www.claires.com/us/pws/StoreFinder.ice?findStore=true&country=US&countryRegion=Alabama')
def seeder(url):
    """
    1) We have to hard code url to Make links that contain the data to be scrapped
       If we don't hard code the url, and keep the main link in 'register decorator' then the url
       passed in the seeder is 'www.claires.co.uk" against the expected "http://www.claires.com/us/pws/StoreFinder.ice?findStore=true&country=US&countryRegion=Alabama'.
       Somewhere after passing from the register decorator the link get's changed.
    2) Also if we have multiple links like in this case, we were able to produce the list of those links out of register decorator
       but were not able to successfully pass that list of links in register, any information on how to pass multiple links in the 
       register will be helpful.
    """
    linkss = []
    # url = 'http://www.claires.com/us/pws/StoreFinder.ice?findStore=true&country=US&countryRegion=Alabama'
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate, sdch",
        "Accept-Language": "en-US,en;q=0.8",
        "Cache-Control": "no-cache",
        "Cookie": "language_id=1; country_iso=US; currency_iso=USD; default_site=PWS_US; _msuuid_52852r30482=02B92FAE-BF12-451E-9B7B-7BC7872D1BF8; _hjIncludedInSample=1; fcp_shopping_basket=; _dc_gtm_UA-48487400-2=1; _ga=GA1.2.1582520162.1496724757; _gid=GA1.2.2021606971.1496724757; xyz_cr_939_et_112==&cr=939&et=112&ap=; ki_t=1496724763876%3B1496724763876%3B1496724926838%3B1%3B2; ki_r=https%3A%2F%2Fwww.google.co.in%2F; JSESSIONID=E116182517C3208D6D6FBEC1C9F0F26B.ClairesNAfcpapp3a",
        "Host": "www.claires.com",
        "Pragma": "no-   cache",
        "Proxy-Connection": "keep-alive",
        "Referer": "https: //www.google.co.in/",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    }
    res = yield requests.get(url, headers=headers, allow_redirects=False)
    # print(res.data)
    soup = BeautifulSoup(res.text, "lxml")
    # print (soup)
    state = soup.find('select', {'id': 'countryRegion'}).find_all('option')[2:]
    for store in state:
        # print (store)
        link = 'http://www.claires.com/us/pws/StoreFinder.ice?findStore=true&country=US&countryRegion='+str(store.text.replace(' ','%20'))
        res2 = yield requests.get(link, headers=headers)

        soup2 = BeautifulSoup(res2.text, "lxml")
        store_link = soup2.find('div', {'id': 'stores_list'}).find_all('li')
        for link1 in store_link:
            final_link = 'http://www.claires.com'+str(link1.find('a').get('href'))
            # linkss.append(final_link)
            yield from extractor(final_link)
    # print (len(linkss))