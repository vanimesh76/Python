import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    b = soup.find_all("div",{"class":"sidebar--content"})[2].p.text
    a = b.split(",")
    State = ""
    if len(a)==5:
        Zip = a[-1]
        Address = a[0]+a[1]+a[2]
        City = a[3]
    elif len(a)==3:
        Zip = a[-1]
        Address = a[0]
        City = a[1]
    elif len(a)==4:
        Zip = a[-1]
        Address = a[0]+a[1]
        City = a[2]
    elif len(a)==2:
        Address = a[0]
        try:
            Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",a[1])[0]
        except:
            Zip = ""
        City = a[1].replace(Zip,"")
        
    else:
        Address = a[0]
        Zip =""
        City = ""
    for i in soup.find_all("a"):
        try:
            if "/maps" in i['href']:
                lat = (re.findall("\/\@(.*?)\/data",i['href']))[0].split(",")[0]
                lon = (re.findall("\/\@(.*?)\/data",i['href']))[0].split(",")[1]
        except:
            lat = 0.0
            lon = 0.0
    BussinessName = ""
    Phone = ''.join(re.findall("\d+",soup.find("ul",{"class":"fa-ul"}).text))
    BrandName = "Harry Ramsdens"
    Country = "UK"
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BussinessName,
        address_1=Address,
        type=None,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location

# This registers the seeder(url) to be:
@register("http://harryramsdens.co.uk/locations/")
def seeder(url):
    data = yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    for i in soupp.find_all("div",{"class":"grid-xs-6 grid-sm-6 grid-md-4 fadeScroll"}):
        print(i.a['href'])
        yield from extractor(i.a['href'])