import logging
import json
import random
import re
import time
import requests
import datetime
import geocoder
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    print (url)
    headers = {"accept":"application/json, text/javascript, */*; q=0.01",
    "accept-encoding":"gzip, deflate, br",
    "accept-language":"en-GB,en-US;q=0.8,en;q=0.6",
    "cache-control":"no-cache",
    "cookie":"term-cookie=Value; _gat_UA-20172546-1=1; _ga=GA1.2.1313102397.1498812675; _gid=GA1.2.1265156645.1498812675",
    "pragma":"no-cache",
    "referer":"https://modpizza.com/location/",
    "user-agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
    "x-requested-with":"XMLHttpRequest"}
    # headers = {"user-agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36"}
    data= yield requests.get(url,headers = headers)
    print (data.text)
    a =data.json()
    for i in a:
        Address = i['address']+" "+i['address2']
        lat= i['lat']
        lon = i['lng']
        Phone = ''.join(re.findall("\d+",i['phone']))
        City = i['city']
        State = i['state']
        Zip = i['postal']
        StoreType = i['bh_sl_loc_cat']
        BussinessName = ""
        StoreType = ""
        try:
            g = geocoder.google(lat+","+lon)
            Country = g.country
        except:
            Country = ""
        BrandName = "MOD Pizza"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state="",
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("https://modpizza.com/wp-admin/admin-ajax.php?action=bh_storelocator_posts_query_ajax&postType=bh_sl_locations&security=ac3c015042&postID=5&formattedAddress=&boundsNorthEast=&boundsSouthWest=")
def seeder(url):
    yield from extractor(url)