import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        a = soup.find("div",{"class":"store-address"}).text.strip("\n").replace("\n\n","\n").split("\n")
        State = ""
        if len(a)==4:
            Address = a[0]
            City = a[1]
            State = a[2]
            Zip = a[3]
        elif len(a)==3:
            Address = a[0]
            City = a[1]
            Zip = a[2]
        Phone = ''.join(re.findall("\d+",soup.find("div",{"class":"store-phone"}).text))
        BussinessName = soup.find("div",{"class":"store_title"}).text
        lat = re.findall("latitude\"\:(.*?)\,",soup.find("div",{"id":"map-data"}).text)[0]
        lon = re.findall("longitude\"\:(.*?)\,",soup.find("div",{"id":"map-data"}).text)[0]
        BrandId = None
        Country = "UK"
        BrandName = "Oasis"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("https://www.oasis-stores.com/gb/stores")
def seeder(url):
    data =yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    b = json.loads(soup.find("div",{"id":"map-data"}).text)
    Id = []
    for i in b:
        Id.append(i['storeId'])
    for j in Id:
        yield from extractor("https://www.oasis-stores.com/on/demandware.store/Sites-Oasis-UK-Site/en_GB/Stores-Details?StoreID="+str(j)+"&phone=1&image=1&name=1&storeType=1&country=1")