import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        a = soup.find("div",{"class":"col-md-12 branch-details"})
        BussinessName = a.find("h1",{"class":"lead-heading"}).text
        State = ""
        try:
            Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",a.find("span",{"class":"location"}).next)[0]
        except:
            Zip = ""
        b = a.find("span",{"class":"location"}).next.replace(Zip,"").strip(" ").split(",")
        if len(b)==3:
            Address = b[0]+" "+b[1]
            City = b[2]
            # State = b[2]
        if len(b)==4:
            Address = b[0]+" "+b[1]+" "+b[2]
            City = b[3]
            # State = b[3]
        if len(b)==5:
            Address = b[0]+b[1]+b[2]+" "+b[3]
            City = b[4]
            # State = b[4]
        Phone = ''.join(re.findall("\d+",soup.find("li",{"class":"contact"}).next.text))
        lat = soup.find("input",{"id":"Lat"})['value']
        lon = soup.find("input",{"id":"Lng"})['value']
        BrandName = "Eurochange"
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("https://www.eurochange.co.uk/branches/all")
def seeder(url):
    data = yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    for i in soupp.find_all("div",{"class":"col-md-4 branch-content"}):
        print ("https://www.eurochange.co.uk"+i.a['href'])
        yield from extractor("https://www.eurochange.co.uk"+i.a['href'])