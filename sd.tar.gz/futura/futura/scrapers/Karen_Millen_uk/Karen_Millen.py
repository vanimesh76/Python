import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in re.findall("StoreID=(.*?)\&",data.text):
        url = "https://www.karenmillen.com/on/demandware.store/Sites-KarenMillen-UK-Site/en_GB/Stores-Details?StoreID="+str(i)+"&phone=1&image=1&name=1&storeType=1&country=1"
        dataa = yield requests.get(url)
        soup = BeautifulSoup(dataa.text,"lxml")
        a = soup.find("div",{"class":"store-address"}).text.strip("\n").split("\n")
        Zip = a[-1].strip()
        City = a[-2].strip()
        State = a[-3].strip()
        Address = ' '.join(a[:-3])
        lat = re.findall("titude&quot\;\:(.*?)\,",dataa.text)[0]
        lon = re.findall("gitude&quot\;\:(.*?)\,",dataa.text)[0]
        BussinessName = soup.find("div",{"class":"store_title"}).text
        BrandName = "Karen Millen"
        StoreType = ""
        Country = "UK"
        Phone = ''.join(re.findall("\d+",soup.find("div",{"class":"store-phone"}).text))
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.karenmillen.com/gb/stores?dwdm=0.38167134704155314")
def seeder(url):
    yield from extractor(url)