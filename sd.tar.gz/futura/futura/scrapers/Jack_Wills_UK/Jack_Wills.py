import logging
import json
import random
import re
import time
import requests
import datetime
import ast
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("div",{"class":"storeContainer"}):
        BussinessName = i.find("h1",{"class":"storeListName"}).span.text
        a = i.find("p",{"class":"storeAddress"}).text.replace("\t","").strip("\n").split("\n")
        try:
            Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+|\w+\d\w \d\w+",a[-1])[0]
            City = a[-1].replace(Zip,"")
            Address = a[0]
        except:
            City = a[-1]
            Address = a[0]
        BrandName = "Jack Wills"
        Country = "GB"
        State = ""
        Phone = ""
        StoreType = ""
        c =  ast.literal_eval(i['data-store'])
        lon = c['lng']
        lat = c['lat']
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.jackwills.com/on/demandware.store/Sites-jwuk-Site/en_GB/StoreFinder-Find?source=find&format=ajax&lat=51.5073509&lng=-0.12775829999998223&maxDist=15000&extDist=150&type=search&refinements=%7B%7D&s=london")
def seeder(url):
    yield from extractor(url)