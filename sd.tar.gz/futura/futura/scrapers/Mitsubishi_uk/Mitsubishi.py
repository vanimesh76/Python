import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    a = json.loads(re.findall("results\"\:(.*?)\]",data.text)[0]+"]")
    dictt = {}
    for i in a:
        lat = i['Latitude']
        lon = i['Longitude']
        deal = str(i['iDealer'])
        key = re.findall("\d+",re.findall("Dealers(.*?)$",str(i['__metadata']))[0])[0]
        dictt[key] = [lat,lon,deal]
    for i in dictt:
        lat = dictt[i][0]
        lon = dictt[i][1]
        StoreType = dictt[i][2]
        if StoreType == "1":
            StoreType = "Sales&Service"
        else:
            StoreType = "Service Only"
        url = "http://www.mitsubishi-cars.co.uk/dealers/getDealerList"
        headers = {"Host":"www.mitsubishi-cars.co.uk",
        "Connection":"keep-alive",
        "Content-Length":"299",
        "Pragma":"no-cache",
        "Cache-Control":"no-cache",
        "Origin":"http://www.mitsubishi-cars.co.uk",
        "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8",
        "Accept":"application/json, text/javascript, */*; q=0.01",
        "X-Requested-With":"XMLHttpRequest",
        "Referer":"http://www.mitsubishi-cars.co.uk/dealers/",
        "Accept-Encoding":"gzip, deflate",
        "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
        "Cookie":"__utmt=1; _s3_id.18.e4d7=688ad074211c8581.1499325894.0.1499325894..; _s3_id.18.0269=1c5f1e8f3afb31b8.1499325894.1.1499325894.1499325894.; _s3_ses.18.0269=*; s3_AEsess=pageCnt%3A0%26time%3A30000; cookiesConfirm=confirmed; _gat_UA-980409-13=1; __utma=20166948.936893440.1499325890.1499325890.1499325890.1; __utmb=20166948.10.9.1499326153675; __utmc=20166948; __utmz=20166948.1499325890.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); _gali=searchBtn; _ga=GA1.3.936893440.1499325890; _gid=GA1.3.2040801109.1499325890"}
        payload = {"dealerCodes[]":str(i).zfill(6)}
        print (payload)
        data = yield requests.post(url,headers = headers, data = payload)
        a = data.json()[0]
        Phone = ''.join(re.findall("\d+",a['address']['Phone_No']))
        Address = a['address']['address_1']
        City = a['address']['address_2']
        State = a['address']['address_3']
        Zip = a['address']['post_code']
        BussinessName = a['score']['dealer_name']
        BrandName = "Mitsubishi"
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location  

@register("https://spatial.virtualearth.net/REST/v1/data/f8b55acc723f4c4d8521dc244235f21c/MitsubishiUKDealerData/MitsubishiUKDealers/?%24format=json&jsonp=gotNearestDealers&%24filter=(PublicStatus+Eq+1+OR+PublicStatus+Eq+4)+&spatialFilter=nearby(51.506420135498%2C-0.127210006117821%2C1000)&%24select=*%2C__Distance&%24top=5000&key=AuVGjvdTR1MBXpmQkqMEAOpNDdQM293p0fFUwnlJvZ17cp-rUnrSWcAd8-083Jut&callback=jQuery1102030171623017669_1499325889895&_=1499325889898")
def seeder(url):
    yield from extractor(url)