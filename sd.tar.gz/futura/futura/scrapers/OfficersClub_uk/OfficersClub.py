import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    b = re.findall("maps.LatLng\((.*?)\)",data.text)
    a = soup.find("div",{"class":"store-locator__stores"})
    c = []
    m = 0
    for i in b[1:]:
        c.append([i.split(",")[0],i.split(",")[1]])
    for i in a.find_all("div",{"class":"col l-col-16"}):
        BussinessName = i.find("strong",{"itemprop":"name"}).text
        Address = i.find("span",{"itemprop":"streetAddress"}).text.strip("\n")
        City = i.find("span",{"itemprop":"addressLocality"}).text.strip("\n")
        try:
            State = i.find("span",{"itemprop":"addressRegion"}).text.strip("\n")
        except:
            State = ""
        Zip = i.find("span",{"itemprop":"postalCode"}).text.strip("\n")
        try:
            Phone = ''.join(re.findall("\d+",i.find("span",{"itemprop":"telephone"}).text.strip("\n")))
        except:
            Phone = ""
        BrandName = "Officers Club"
        lat = c[m][0]
        lon = c[m][1]
        m+=1
        StoreType = ""
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.officersclub.com/map")
def seeder(url):
    yield from extractor(url)