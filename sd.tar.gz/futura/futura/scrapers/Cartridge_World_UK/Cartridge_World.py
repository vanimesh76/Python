import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "var storeLocator" in i.text:
            a = json.loads("[{"+re.findall("locations\: \[\{(.*?)\}\]\,",i.text)[0].replace('\\','')+"}]")
    for i in a:
        if "closed" not in i['address_display'].lower():
            Address = i['address_display']
            try:
                Zip = re.findall("\w+\d \d\w+",i['address_display'])[0]
            except:
                Zip = i['address_display'].split(",")[-1]
            Address = Address.replace(Zip,"").strip(",")
            try:
                City = Address.split(",")[1]
            except:
                pass
            Address = Address.split(",")[0]
            Country = "GB"
            lat = i['latitude']
            lon = i['longitude']
            State = ""
            Phone = ''.join(re.findall("\d+",i['phone']))
            BussinessName = i['title']
            BrandId = None
            BrandName = "Cartridge World"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=BrandId,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=None,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("https://www.cartridgeworld.co.uk/locations.php")
def seeder(url):
    yield from extractor(url)