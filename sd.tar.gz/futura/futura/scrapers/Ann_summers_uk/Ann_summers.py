import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    for i in soupp.find_all("div",{"class":"col-sm-4 col-md-3"}):
        for j in i.find_all("a"):
            url = j['href']
            data = yield requests.get(url)
            soup = BeautifulSoup(data.text,"lxml")
            a = soup.find("div",{"class":"col-1"}).text.replace("Address:","").strip("\n").split("\n")
            if len(a)>=4:
                Phone = ''.join(re.findall("\d+",a[-1]))
                try:
                    Zip = re.findall("\w+\d \d\w+|\w+\d, \d\w+|\w+\d\d\w+",a[-3])[0]
                except:
                    Zip = ""
                    print (a, url)
                b = a[-3].replace(Zip,"").split(" ")
                State = ""
                if len(b)>=2:
                    City = b[0]
                    State = b[1]
                else:
                    City = b[0]
                Address = a[0]
                StoreType = ""
                Country = "UK"
                BrandName = "Ann Summers"
                BussinessName = "Ann Summers"
                lon = soup.find("div",{"class":"store-information"})['data-long']
                lat = soup.find("div",{"class":"store-information"})['data-lat']        
                Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
                location = StoreLocation(
                    brand_id=None,
                    brand_name=BrandName,
                    store_name=BussinessName,
                    address_1=Address,
                    type=StoreType,
                    city=City,
                    state=State,
                    zipcode=Zip,
                    country_code=Country,
                    latitude=float(lat),
                    longitude=float(lon),
                    phone_number=Phone,
                    secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                    raw_address = Rawaddress,
                    url=url)
                yield location
            else:
                print (a,url)

@register("http://global.annsummers.com/store-directory.html")
def seeder(url):
    yield from extractor(url)