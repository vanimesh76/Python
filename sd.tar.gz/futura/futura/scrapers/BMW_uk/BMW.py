import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    # print (data.text)
    a =json.loads(re.findall("callback\((.*?)\}\)",data.text)[0]+"}")
    for i in a['data']['pois']:
        Phone = "".join(re.findall("\d+",i['attributes']['phone']))
        StoreType = i['attributes']['outletTypes'][0]    
        City = i['city']
        Country = i['countryCode']
        lat = i['lat']
        lon = i['lng']
        BussinessName = i['name']
        Zip = i['postalCode']
        State = i['state']
        Address = i['street']
        Country = "UK"
        State = ""
        BrandName = "BMW"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("https://c2b-services.bmw.com/c2b-localsearch/services/api/v3/clients/BMWDIGITAL_DLO/GB/pois?country=GB%2CJE%2CIM%2CGG&category=BM&maxResults=500&language=en&name=&lat=51.52863766189159&lng=-0.10150869693359255&callback=callback&_1498548072745=")
def seeder(url):
    yield from extractor(url)