import logging
import json
import random
import re
import time
import requests
import datetime
import geocoder
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    # for j in range(0,73,12):
    url = "https://www.randw.com.au/find-an-office.html?offset=12"
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    a = soup.find_all("div",{"class":"fluidgrid-group fluidgrid-group-light"})[1]
    for i in a.find_all("div",{"class":"fluidgrid-cell fluidgrid-cell-2"}):
        Address = i.find_all("div",{"class":"text"})[0].text
        b = i.find_all("div",{"class":"text"})[1].text.split(",")
        City = b[0].strip()
        State = b[1].strip()
        Zip = b[2].strip()
        Phone = ''.join(re.findall("\d+",i.find("a").text))
        Country = "AU"
        StoreType = ""
        BrandName = "Richardson & Wrench"
        BussinessName = "Richardson & Wrench"
        g = geocoder.google(','.join([Address.replace(",",""),City,State,Zip]))
        if g.lat!=None:
            lat = g.lat
            lon = g.lng
        else:
            lat = 0.0
            lon = 0.0
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    yield from extractor(url)