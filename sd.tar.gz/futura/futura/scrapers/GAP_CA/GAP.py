import logging
import json
import random
import re
import time
import requests
import datetime
import ast
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation
print("dfsdf")

def extractor(url):
    print(url)
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "var caStores" in i.text:
            a = re.findall("Stores\=(.*?)$",str(i.text).replace("\n","").replace("\r","").replace("  ",""))[0]
    b = re.findall("\[(.*?)\],",a.replace(",,",",0,"))
    listt = []
    for i in b:
        c = "["+i+"]"
        listt.append(ast.literal_eval(c.replace("[[","[")))
    for i in listt:
        BussinessName = i[1]
        Address = i[2]
        City = i[3]
        State = i[4]
        Zip = i[5]
        Phone = ''.join(re.findall("\d+",i[6]))
        StoreType = ""
        if i[7] == 1:
            StoreType = StoreType+"Women/"
        if i[8] == 1:
            StoreType = StoreType+"Men/"
        
        if i[9] == 1:
            StoreType = StoreType+"Baby/"
        
        if i[10] == 1:
            StoreType = StoreType+"kids/"
        
        if i[11] == 1:
            StoreType = StoreType+"Body/"
        
        if i[12] == 1:
            StoreType = StoreType+"Accessories/"
        
        if i[13] == 1:
            StoreType = StoreType+"Maternity/"
        StoreType = "Factory Outlet"
        lat = i[14]
        lon = i[15]
        Country = "CA"
        BrandName = "GAP"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.gapcanada.ca")
def seeder(url):
    print(url)
    url = "http://www.gapcanada.ca/browse/info.do?cid=57319&mlink=5058,10777897&clink=10777897"
    yield from extractor(url)