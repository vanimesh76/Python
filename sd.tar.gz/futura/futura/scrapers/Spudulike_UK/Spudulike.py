import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script"):
        if "jQuery" in i.text:
            data_json = json.loads(re.findall("settings\, (.*?)\)\;",i.text)[0])
    for i in data_json['openlayers']['maps']['openlayers-map-425c40ff']['layers']['locations_openlayers_1']['features']:
        s = BeautifulSoup(str(i['attributes']['description']),"lxml")
        Address = s.find("div",{"class":"premise"}).text
        BussinessName = s.find("div",{"class":"thoroughfare"}).text
        try:
            City = s.find("div",{"class":"locality"}).text
        except:
            City =""
        Address = Address+" "+City
        City = ""
        try:
            State = s.find("div",{"class":"state"}).text
        except:
            State = ""
        Zip = s.find("div",{"class":"postal-code"}).text
        Phone = s.find("br").next.next.replace(" ","")
        lon = re.findall("\((.*?)\)",i['attributes']['field_ol_locator_geofield'])[0].split(" ")[0].strip()
        lat = re.findall("\((.*?)\)",i['attributes']['field_ol_locator_geofield'])[0].split(" ")[1].strip()
        City = State.split(",")[0]
        try:
            State = State.split(",")[1]
        except:
            State = ""
        StoreType = ""
        BrandName = "Spudulike"
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.spudulike.com/locations?circle_op=%3C&circle%5Bvalue%5D=1000&circle%5Blocation%5D=london")
def seeder(url):
    yield from extractor(url)