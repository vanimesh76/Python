import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    headers = {"Connection":"keep-alive",
    "Pragma":"no-cache",
    "Cache-Control":"no-cache",
    "Upgrade-Insecure-Requests":"1",
    "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding":"gzip, deflate, br",
    "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6"}

    data = yield requests.get(url,headers = headers)

    soup = BeautifulSoup(data.text,"lxml")

    for i in soup.find("div",{"class":"two-thirds column"}).find_all("p"):
        a = len(i.text.split(","))
        if a==2:
            Zip =re.findall("\w+\d \d\w+",i.text.split(",")[-1])[0]
            City = i.text.split(",")[-1].replace(Zip,"").strip(" ")
            Address = i.text.split(",")[0].replace(City,"").replace("-","").strip(" ")
            State = ""
        elif a == 3:
            Zip = re.findall("\w+\d \d\w+",i.text.split(",")[-1])[0]
            City = i.text.split(",")[1].strip(" ") 
            Address = i.text.split(",")[0].replace(City,"").replace("-","").strip(" ")
            State = ""
        elif a==4:
            Zip = re.findall("\w+\d \d\w+",i.text.split(",")[-1])[0]
            City = i.text.split(",")[1].strip(" ")
            State = i.text.split(",")[2].strip(" ")
            Address = i.text.split(",")[0].replace(City,"").replace("-","").strip(" ").replace(State,"")
        elif a==5:
            Zip = i.text.split(",")[-1]
            State = i.text.split(",")[-2]
            City = i.text.split(",")[-3]
            Address = i.text.split(",")[-5]+" "+i.text.split(",")[-4]
            Address = Address.replace(City,"").replace("-","").strip(" ").replace(State,"")
        Country = "GB"
        Phone = ""
        geourl = ''.join(['http://geocode.xad.com:8080/xadutils/tools/geocode?country=', Country, '&city=', City, '&zipcode=', Zip, '&address1=', Address, '&state=', State])
        headers = {'X-ACCESS-KEY':'1bb0e458-29d7-4c63-95af-03b19fcb1f91', 'X-APP-ID':'SCRAPE'}
        geores = yield requests.get(geourl, headers = headers)
        geodatajson =  geores.json()
        if 'result' in geodatajson.keys():
            lat = geodatajson['result']['lat']
            lon = geodatajson['result']['lon']
        else:
            lat = 0.0
            lon = 0.0
        BussinessName = ""
        BrandId = None
        BrandName = "Stan James"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("http://www.stanjamesshops.com/locations/")
def seeder(url):
    yield from extractor(url)