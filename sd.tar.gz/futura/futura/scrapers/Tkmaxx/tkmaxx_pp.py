# from bs4 import BeautifulSoup
# import urllib2
# import requests
# import json
# import re
# import MySQLdb
# import datetime
# import time
# import os
# import pp
# import math
# import csv
# con = MySQLdb.connect(host='10.100.10.46', user='root', passwd='india@123', db='O_O_DATA', use_unicode=True, charset="utf8")
# cur = con.cursor()


# def visit(url, start_index):
#     from bs4 import BeautifulSoup
#     import requests
#     import re
#     import random
#     import time
#     import MySQLdb
#     import sys
#     import datetime
#     import csv
#     import json
#     import pp
#     import math
#     import itertools
#     import os
#     import urllib2
#     #     print url
#     #     try:
#     con = MySQLdb.connect(host='10.100.10.46', user='root', passwd='india@123', db='O_O_DATA', use_unicode=True,
#                           charset="utf8")
#     cur = con.cursor()
#     for l in url:
#         try:
#             data = requests.get(l)
#             soup = BeautifulSoup(data.text,"lxml",from_encoding = "utf-8")
#             Address = soup.find("p",{"itemprop":"streetAddress"}).text
#             try:
#                 Zip = soup.find("p",{"itemprop":"zipCode"}).text
#             except:
#                 Zip = ""
#             try:
#                 City = soup.find("p",{"itemprop":"addressLocality"}).text.replace(Zip,"").strip(" ")
#             except:
#                 City = ""
#             try:
#                 Phone = ''.join(re.findall("\d+",soup.find("p",{"itemprop":"telephone"}).text))
#             except:
#                 Phone = ""
#             try:
#                 lat = soup.find("div",{"class":"nearby-store active-store"})['data-latitude']
#             except:
#                 lat = soup.find("div",{"class":"nearby-store "})['data-latitude']
#             try:
#                 lon = soup.find("div",{"class":"nearby-store active-store"})['data-longitude']
#             except:
#                 lon = soup.find("div",{"class":"nearby-store "})['data-longitude']
#             BrandId = None
#             BrandName = "Tk Maxxx"
#             Country = "DE"
#             StoreType = ""
#             State = ""
#             BussinessName = ""
#             string_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#             Last_update = datetime.datetime.strptime(string_time, "%Y-%m-%d %H:%M:%S")
#             Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State,str(lat),str(lon)]))
#             SecondarySIC = datetime.datetime.now().strftime("%Y-%m")
#             PrimarySIC = ''
#             Data = [BrandName, BussinessName, StoreType, Address, City, State, Zip, Country, Phone, PrimarySIC,
#                 SecondarySIC, lat, lon, BrandId, Rawaddress, Last_update, l]
#             # print Data
#             # break
#             cur.execute("INSERT IGNORE INTO " + str(
#                 'O_O_DATA') + " values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", Data)
#             con.commit()
#         except Exception as e:
#             print e
#             print l
#             pass


# # url = "http://www.tkmaxx.de/filialen/TK_MAXX_Munchen"
# # visit([url],'')

# linkss = []
# url = 'http://www.tkmaxx.de/sitemap'
# data = requests.get(url)
# soup = BeautifulSoup(data.text,"lxml")
# # print soup
# for j in soup.find_all("ul",{"class":"site-map-menu"}):
#     for i in j.find_all("a"):
#         if "filialen" in i['href']:
#             # print i['href']
#             linkss.append("http://www.tkmaxx.de"+i['href'])
# # print linkss

# start_time = time.time()
# def increaser(inputlist):
#     number_of_process = 12
#     lencheck = len(inputlist)%number_of_process
#     # print len(inputlist), lencheck
#     for i in range(0, number_of_process-lencheck):
#         inputlist.append('')
#     # lencheck = len(inputlist)/number_of_process
#     # print lencheck,len(inputlist)
# #     print inputlist
#     return inputlist
# # print linkss
# url_list = increaser(linkss)

# def mp(url_list):
# #     print url_list
#     job_server = pp.Server(secret='abc')
#     job_server.set_ncpus(12)
#     slot = int(math.ceil(len(url_list)/job_server.get_ncpus()))
#     start_index = 0
#     end_index = 0
#     jobs = []

#     for k in range(job_server.get_ncpus()):
#         start_index = end_index
#         end_index = start_index+slot
#         print start_index,end_index
#         _file = url_list[start_index:end_index]
#         # print _file
#         jobs.append(job_server.submit(visit,(_file, start_index)))

#     for job in jobs:
#         print job()
#         print("--- %s seconds ---" % (time.time() - start_time))
# mp(url_list)
