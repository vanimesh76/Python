import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data = yield requests.get(url)
        a= json.loads("["+data.text.strip(",")+"]")
        for i in a:
            City = i['City']
            State = ""
            Zip = i['PostCode']
            lat = i['Latitude']
            lon = i['Longitude']
            Address = i['AddressName']+" "+i['Address']+" "+i['Address2']
            Country = i['Country']
            BussinessName = i['StoreName']
            Phone = ''.join(re.findall("\d+",i['Phone']))
            BrandId = None
            StoreType = i['Key1']
            BrandName = "Tk Maxx"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State,str(lat),str(lon)]))
            location = StoreLocation(
                brand_id=BrandId,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                raw_address = Rawaddress,
                url=url)
            yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("http://www.tkmaxx.com/scat/storeloc&temp=storesjson&layout=blank")
def seeder(url):
    yield from extractor(url)