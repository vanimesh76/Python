import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    headers = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36'}
    payload = {"postcode":"48143", "radius":"5000"}
    print (url)
    res = yield requests.post(url,data = payload, headers = headers)
    print (res.text)
    soup = BeautifulSoup(res.text,"lxml")
    for i in soup.find_all("div",{"style":"background-color: #F2F2F2; padding: 10px; margin-bottom: 10px;"}):
        addresstext =str(i).replace("\r","").replace("\n","").replace("  "," ").replace("\t","")
        addressinfo = [x.strip() for x in filter(None, re.findall(r'<br\/>(.*?)<a href', addresstext)[0].split('<br/>'))[2:]]
        if len(addressinfo)==1:
            addressinfo = [x.strip() for x in filter(None, re.findall(r'<br\/>(.*?)<a href', addresstext)[0].split('<br/>'))[1:]]
        Zip =addressinfo[1].split(" ")[0]
        Address = addressinfo[1].split(" ")[1]
        City = addressinfo[0]
        Phone = ''.join(re.findall("\d+",re.findall("Telefon\:(.*?)\<br\/\>",str(i))[0]))
        BussinessName = i.strong.text.replace("+","&")
        try:
            lat = re.findall("ll\=(.*?)\&amp",str(i))[0].split(",")[0]
            lon = re.findall("ll\=(.*?)\&amp",str(i))[0].split(",")[1]
        except:
            try:
                lat = re.findall("\/\@(.*?)\/",str(i))[0].split(",")[0]
                lon = re.findall("\/\@(.*?)\/",str(i))[0].split(",")[1]
            except:
                lat = re.findall("ll\=(.*?)\"",str(i))[0].split(",")[0]
                lon = re.findall("ll\=(.*?)\"",str(i))[0].split(",")[1]
        State = ""
        Country = "DE"
        BrandName = "K & K Verbrauchermärkte"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BusinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("http://www.klaas-und-kock.de/naechster-kk/")
def seeder(url):
    yield from extractor(url)