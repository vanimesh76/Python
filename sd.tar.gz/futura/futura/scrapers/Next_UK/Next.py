import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    res = yield requests.get(url)
    soup = BeautifulSoup(res.text,"lxml")

    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "results.push" in i.text:
            aa = json.loads("["+re.findall("window.lctr.results.push\((.*?)$",i.text.replace("\n",""))[0].replace("window.lctr.results.push({","[{").replace("});[","},").replace("});","}").replace("        ","").replace("}[{","},{")+"]")
    for i in aa:
        BrandName = "Next"
        Address = i['street']
        lat = i['Latitude']
        lon = i['Longitude']
        Zip = i['PostalCode']
        Phone = ''.join(re.findall("\d+",i['telephone']))
        Country = i['country']
        BussinessName = i['branch_name']
        if "kingdom" in Country.lower():
            Country = "UK"
        State = i['county']
        StoreType = i['store_type']
        City = i['city']
        if Address == "":
            Address = i['AddressLine']
        if City == "":
            City == i['town']
        else:
            Address = Address+" "+i['town']
        BrandId = None
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State,str(lat),str(lon)]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            raw_address = Rawaddress,
            url=url)
        yield location


# This registers the seeder(url) to be:
@register('http://stores.next.co.uk/stores/country/United+Kingdom')
def seeder(url):
    yield from extractor(url)

