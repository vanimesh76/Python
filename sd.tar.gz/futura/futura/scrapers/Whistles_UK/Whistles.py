import logging
import json
import random
import re
import time
import requests
import datetime
import geocoder
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("div",{"class":"store-list-address-wrap"}):
        BussinessName = i.span.text 
        a = BeautifulSoup(str(i).split("</span>")[1],"lxml").text.strip("\n").split("\r\n")
        # a =  i.text.strip("\n").replace("\r\n",",").split(",")
        Zip = re.findall("\w+\d+ \d\w+|\w+\d\w \d\w+",a[-2])
        Phone = ''.join(re.findall("\d+",a[-1]))
        State = ""
        if Zip==[]:
            Zip = re.findall("\w+\d+ \d\w+|\w+\d\w \d\w+",a[-3])
        try:
            Zip = Zip[0]
        except:
            Zip = ""
        if len(a)==3:
            City = ""
            Address = a[0]
            Zip = a[-2]
            Phone = ''.join(re.findall("\d+",a[-1]))
        elif len(a) == 4:
            Zip
            Phone
            City = a[1]
            Address = a[0]
        elif len(a)==5:
            City = a[2]
            if "kingdom" in City.lower() or Zip.lower() in City.lower():
                City = a[1]
            Address = a[0]
        elif len(a)==6:
            Address = ' '.join(a[:2])
            City = a[-4]
            if Zip in a[-4]:
                City = a[-3]
            City= City
        elif len(a) == 7:
            State = a[-3]
            if Zip in a[-3]:
                State = a[-4]
            City = a[-5]
            Address = ' '.join(a[:2])
        elif len(a) == 8:
            State = a[-3]
            if Zip in a[-3]:
                State = a[-4]
            City = a[-5]
            Address = ' '.join(a[:3])
        elif len(a)==9:
            if "kingdom" in a[-2].lower():
                Address = ' '.join(a[:5])
                City = a[-4]
        Country = "UK"
        StoreType = ""
        BrandName = "Whistles"
        g = geocoder.google(','.join([Address.replace(",",""),City,Zip,Country]))
        if g.lat!=None:
            lat = g.lat
            lon = g.lng
        else:
            lat = 0.0
            lon = 0.0
        # geourl = ''.join(['http://geocode.xad.com:8080/xadutils/tools/geocode?country=', Country, '&city=', City, '&zipcode=', Zip, '&address1=', Address, '&state=', State])
        # headers = {'X-ACCESS-KEY':'1bb0e458-29d7-4c63-95af-03b19fcb1f91', 'X-APP-ID':'SCRAPE'}
        # geores = yield requests.get(geourl, headers = headers)
        # geodatajson =  geores.json()
        # if 'result' in geodatajson.keys():
        #     lat = geodatajson['result']['lat']
        #     lon = geodatajson['result']['lon']
        # else:           
        #     lat = 0.0           
        #     lon = 0.0
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.whistles.com/our-stores/our-stores.html")
def seeder(url):
    yield from extractor(url)