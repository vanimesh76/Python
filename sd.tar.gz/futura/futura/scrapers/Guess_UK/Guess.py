import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    # url = "https://api.guess.com/rest/1.0/Store/GetByCoordinate?latitude=51.5073509&longitude=-0.12775829999998223&storeConceptType=&radius=999"
    data = yield requests.get(url)
    print (data.text)
    data_json = json.loads(data.text)
    for i in data_json['Result']:
        Address = i['AddressLine1']+" "+i['AddressLine2']
        City = i['City']
        Country = i['Country']
        lat = i['Latitude']
        lon = i['Longitude']
        BussinessName = i['Name']
        Phone = i['PhoneNumber']
        Zip = i['PostalCode']
        BrandName = "Guess"
        State = ""
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# @register("https://www.snowandrock.com/api/services/public/store/snowandrock/en")
# def seeder(url):
#     yield from extractor(url)
@register('http://www.latlong.net/country/united-kingdom-235.html')
def seeder(url):
    f = open("/home/skymap/PycharmProjects/Virtual env/Thomson.csv",'r')
    for i in f:
        Latitude,Longitude = i.split(",")
        new_url = ''.join(['https://api.guess.com/rest/1.0/Store/GetByCoordinate?latitude='+str(Latitude)+'&longitude='+str(Longitude).strip("\n")+'&storeConceptType=&radius=999'])
        yield from extractor(new_url)
    # yield from extractor(url)
    # res = yield requests.get(url)
    # soup = BeautifulSoup(res.text.encode('utf-8'))
    # lat_long_link = soup.find('div',{'class':'col-8'}).find('ul').find_all('li')
    # for lat_long in lat_long_link:
    #     lat_long_links = lat_long.find('a').get('href')
    #     res2 = yield requests.get(lat_long_links)
    #     soup2 = BeautifulSoup(res2.text.encode('utf-8'))
    #     if 'next' in  str(soup2):
    #         number_of_pages = soup2.find_all('ul', {'class':'list-horizontal'})[-2].find_all('li')[-2].text.encode('utf-8')
    #         for page in range(1, int(number_of_pages)+1):
    #             pagelink = lat_long_links.replace('.html',  '-' + str(page) + '.html') 
    #             # time.sleep(random.randint(1, 4))
    #             res3 = yield requests.get(pagelink)
    #             soup3 = BeautifulSoup(res3.text.encode('utf-8'))
    #             lat_long_list = soup3.find('table').find_all('tr')
                
    #             for lat_long_main in lat_long_list:
    #                 if '<td><a href' in str(lat_long_main):     
    #                     Latitude = lat_long_main.find('td').find_next('td').text.encode('utf-8')
    #                     # print(Latitude)   
    #                     Longitude = lat_long_main.find('td').find_next('td').find_next('td').text.encode('utf-8')
    #                     new_url = ''.join(['https://api.guess.com/rest/1.0/Store/GetByCoordinate?latitude='+str(Latitude)+'&longitude='+str(Longitude)+'&storeConceptType=&radius=999'])
    #                     yield from extractor(new_url)
    #                     # print new_url
    #     else:
    #         lat_long_list = soup2.find('table').find_all('tr')
            
    #         for lat_long_main in lat_long_list:
    #             if '<td><a href' in str(lat_long_main):     
    #                 Latitude = lat_long_main.find('td').find_next('td').text.encode('utf-8')            
    #                 Longitude = lat_long_main.find('td').find_next('td').find_next('td').text.encode('utf-8')
    #                 new_url = ''.join(['https://api.guess.com/rest/1.0/Store/GetByCoordinate?latitude='+str(Latitude)+'&longitude='+str(Longitude)+'&storeConceptType=&radius=999'])
    #                 yield from extractor(new_url)