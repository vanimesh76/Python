import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    url = "https://www.timpson.co.uk/wp/store-finder/?/front/get/53.95996510000001/-1.0872979000000669/1"
    headers = {"Host":"www.timpson.co.uk",
    "Connection":"keep-alive",
    "Content-Length":"46",
    "Pragma":"no-cache",
    "Cache-Control":"no-cache",
    "X-NewRelic-ID":"Vw8CU1RaGwIAXFdRAgIH",
    "Origin":"https://www.timpson.co.uk",
    "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
    "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8",
    "Accept":"application/json, text/javascript, */*; q=0.01",
    "X-Requested-With":"XMLHttpRequest",
    "Referer":"https://www.timpson.co.uk/stores/",
    "Accept-Encoding":"gzip, deflate, br",
    "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
    "Cookie":"frontend_cid=nSohPLxTsi2YNOrB; frontend=abpl4odogmj8gi5kl5s4sjboa3; _ga=GA1.3.1315650375.1500530559; _gid=GA1.3.543459744.1500530559; ci_session=2NAV1FiwkIiO51HgxALDSxJSnBNTOoZaekBCrSm4XGVNvwRiEIXiMz%2BwvkTAnZCokaSEyVRWCTY%2B47c06byxbHd169HvLv1nRHKoaHuUsPrJ3ShbXp6UvpJOAybM4QG9jzb9ToA7iopyeZtxOLpbiwZBE4oPfcOMaPILcnVDBhgOFZTxXoqs6KFwILrYvkfxa7hoqMhiukZWnrmYD2ZpjB%2FxdTthuTYmW7Cfh3Uj1O4GeCIW0ceF1cto9pCq6PKBxnSP0EeVtKIQ6Jf3cU0SL7CIcLn9qKP5Ody4pXjcgVy2gWSNS3KvU1jYulukcAJt9u4tMwgWRALK2gigLC0zMgcQ1v%2BI5a%2Bq7N7XEWvyRNSmCR%2F4gViywGOgs2rRHVQX%2BPedTeWXOGZHTwp99HCk5HnVYnFH%2FsvB6YszvLjaOImwseVmrf3G2ksavLD27XLHTn3hMR2v3Vj84LGsNM21%2FA%3D%3D"}
    payload = {"search2":"",
    "address":"york United Kingdom",
    "start":"18"}
    data =yield requests.post(url,headers = headers,data = payload)
    a = json.loads(data.text)
    for i in a['locations']:
        City = i['city']
        Country = i['country']
        if "kingdom" in Country.lower():
            Country = "UK"
        elif "land" in Country.lower():
            Country = "IR"
        else:
            Country = ""
        lat = i['lat']
        lon = i['lng']
        BussinessName = i['name']
        Phone = i['phone']
        Address = i['street1']
        Zip = i['zip']
        BrandName = "Timpson"
        StoreType = ""
        State = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    yield from extractor(url)