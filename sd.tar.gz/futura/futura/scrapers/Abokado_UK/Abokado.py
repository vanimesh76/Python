import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data =yield requests.get(url)
    a = data.json()
    for i in a:
        Address = i['address']
        City = i['address2']
        State = i['city']
        Country = "GB"
        lat = i['lat']
        lon = i['lng']
        Phone = ''.join(re.findall("\d+",i['phone']))
        BussinessName = i['store']
        Zip = i['zip']
        Country = "GB"
        BrandId = None
        BrandName = "Abokado"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("http://abokado.com/wp/wp-admin/admin-ajax.php?action=store_search&lat=51.507351&lng=-0.12775799999997162&max_results=250&radius=50000&autoload=1")
def seeder(url):
    yield from extractor(url)