# import logging
# import json
# import random
# import re
# import time
# import requests

# logger = logging.getLogger(__name__)

# from bs4 import BeautifulSoup

# # This allows for this scraper to be accessible from Futura:
# from ...support.bs4 import register
# # This is where we'll store our Location Data:
# from ...types import StoreLocation


# def extractor(url):
#         data= yield requests.get(url)
#         soup = BeautifulSoup(data.text,"lxml")
#         Phone = ''.join(re.findall("\d+",a.find("p",{"class":"impinfo"}).text))
#         # try:
#         #     lat = re.findall("sll\=(.*?)\&",soup.find("iframe",{"id":"map"})['src'])[0].split(",")[0]
#         #     lon = re.findall("sll\=(.*?)\&",soup.find("iframe",{"id":"map"})['src'])[0].split(",")[1]
#         # except:
#         #     for i in soup.find_all("iframe"):
#         #         if "maps" in str(i.get("src")):
#         #             lat = re.findall("2d(.*?)\!",i.get('src'))[0]
#         #             lon = re.findall("3d(.*?)\!",i.get('src'))[0]
#         # try:
#         #     a = soup.find("div",{"id":"cq-shop-info"})
#         #     Address =  str(a.find_all("p")[0]).split("<br/>")[0].replace("<p>","")
#         #     City = str(a.find_all("p")[0]).split("<br/>")[1]
#         #     Zip = str(a.find_all("p")[0]).split("<br/>")[-1].replace("</p>","")
#         #     Phone = ''.join(re.findall("\d+",a.find("p",{"class":"impinfo"}).text))
#         # except:
#         #     a = soup.find("div",{"class":"cq-shop-info"})
#         #     Address =  str(a.find_all("p")[0]).split("<br/>")[0].replace("<p>","")
#         #     City = str(a.find_all("p")[0]).split("<br/>")[1]
#         #     Zip = str(a.find_all("p")[0]).split("<br/>")[-1].replace("</p>","")
#         #     Phone = ''.join(re.findall("\d+",a.find("p",{"class":"impinfo"}).text))
#     for i in soup.find_all("marker"):
#         a = len(i.find("address").text.split("<br />"))
#         b = i.find("address").text.split("<br />")
#         if a== 3:
#             Address = ''.join(b[:1])
#             City = b[-2]
#             Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",b[-1])[0]
#         elif a== 4:
#             Address = ''.join(b[:2]) 
#             City = b[-2]
#             try:
#                 Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",b[-1])[0]
#             except:
#                 Zip = b[-1]
#         elif a== 5:
#             Address = ''.join(b[:3])
#             City = b[-2]
#             try:
#                 Zip = re.findall("\w+\d \d\w+|\w+\d\d\w+",b[-1])[0]
#             except:
#                 Zip = ""
#         elif a==6:
#             Address = ''.join(b[:4])
#             City = b[-2]
#             Zip = b[-1]
#         lat = i.find("lat").text
#         lon = i.find("lng").text
#         BrandId = None
#         Country = "UK"
#         State = ""
#         BussinessName = "John Lewis"
#         BrandName = "John Lewis"
#         Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
#         location = StoreLocation(
#             brand_id=BrandId,
#             brand_name=BrandName,
#             store_name=BussinessName,
#             address_1=Address,
#             type=None,
#             city=City,
#             state=State,
#             zipcode=Zip,
#             country_code=Country,
#             latitude=float(lat),
#             longitude=float(lon),
#             phone_number=Phone,
#             raw_address = Rawaddress,
#             url=url)
#         yield location
#     # except:
#     #     pass

# # This registers the seeder(url) to be:
# @register("https://www.johnlewis.com/our-shops")
# def seeder(url):
#     print (url)
#     data = yield requests.get(url)
#     soupp = BeautifulSoup(data.text,"lxml")
#     # print (soupp)
#     aa = soupp.find("section",{"class":"shop-list"})
#     for j in aa.find_all("li"):
#         print (j.a['href'])
#         yield from extractor("https://www.johnlewis.com"+j.a['href'])