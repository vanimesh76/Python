import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find("tbody").find_all("tr")[1:]:
        try:
            BussinessName = i.find_all("td")[0].text
        except:
            try:
                BussinessName = i.find_all("span",{"style":"color: rgb(0,0,0)"})[0].text
            except:
                BussinessName = i.find("td",{"style":"text-align: left"}).text
        a = i.find_all("td")[1].text.split(",")
        City = a[-1]
        Address = " ".join(a[:-1])
        try:
            Zip = i.find_all("td")[2].text
        except:
            try:
                Zip = i.find_all("span",{"style":"color: rgb(0,0,0)"})[2].text
            except:
                Zip = i.find("td",{"nowrap":"nowrap"}).text
        try:
            lat = re.findall("ll\=(.*?)\&s",i.a['href'])[0].split(",")[0].strip(" ")
            lon = re.findall("ll\=(.*?)\&s",i.a['href'])[0].split(",")[1].strip(" ")
        except:
            try:
                lat = re.findall("\d+\.\d+|-\d+.\d+",i.a['href'])[0].strip(" ")
                lon = re.findall("\d+\.\d+|-\d+.\d+",i.a['href'])[1].strip(" ")
            except:
                lat = 0.0
                lon = 0.0
                print (i)
        try:
            Phone = i.find_all("td")[-1].text
        except:
            try:
                Phone = i.find_all("span",{"style":"color: rgb(0,0,0)"})[3].text
            except:
                Phone = i.find("td",{"style":"text-align: left"}).text
        Country = "UK"
        State = ""
        BrandName = "Cooplandss"
        BrandId = None
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("http://www.cooplands-bakery.co.uk/page/shop-locations")
def seeder(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    a = soup.find("div",{"id":"content"})
    for i in a.find_all("a"):
        yield from extractor("http://www.cooplands-bakery.co.uk"+i['href'])