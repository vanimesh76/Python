import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(Zipp,Lat,Lon):
    print("sds")
    url = "http://www.postoffice.co.uk/branch-finder-search"
    headers = {"Host":"www.postoffice.co.uk",
    "Connection":"keep-alive",
    "Content-Length":"106",
    "Pragma":"no-cache",
    "Cache-Control":"no-cache",
    "Origin":"http://www.postoffice.co.uk",
    "Upgrade-Insecure-Requests":"1",
    "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
    "Content-Type":"application/x-www-form-urlencoded",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Referer":"http://www.postoffice.co.uk/branch-finder-search",
    "Accept-Encoding":"gzip, deflate",
    "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
    "Cookie":'VISITOR=returning; AMCV_D7ECF561577691407F000101%40AdobeOrg=T; AMCVS_D7ECF561577691407F000101%40AdobeOrg=1; VISITOR=returning; s_ppvl=branch-finder%2C23%2C9%2C678%2C1301%2C678%2C1366%2C768%2C1%2CP; cookie-approve=true; JSESSIONID=87AD1612BA48A4A19D5984810888C8D4; s_pageName=no%20value; check=true; _uetsid=_uet64acdcf7; _ga=GA1.3.1418292273.1500970481; _gid=GA1.3.1960611578.1500970481; _gat=1; AMCV_D7ECF561577691407F000101%40AdobeOrg=102365995%7CMCIDTS%7C17373%7CMCMID%7C33207828110234518153107467898516061564%7CMCAAMLH-1501575564%7C3%7CMCAAMB-1501575564%7CNRX38WO0n5BH8Th-nqAG_A%7CMCOPTOUT-1500977964s%7CNONE%7CMCSYNCSOP%7C411-17380%7CMCAID%7CNONE%7CvVersion%7C2.2.0; mbox=session#1b486777b56246d6800d3470d04d819b#1500972628|PC#1b486777b56246d6800d3470d04d819b.28_73#1564215285; s_cc=true; ADRUM_BTa="R:0|g:14220104-ea77-489a-bd87-9a3daac6537e"; ADRUM_BT1="R:0|i:583|e:1"; s_sq=%5B%5BB%5D%5D; s_ppv=branch-finder%2C100%2C23%2C2910%2C753%2C678%2C1366%2C768%2C1%2CP; ADRUM=s=1500970781917&r=http%3A%2F%2Fwww.postoffice.co.uk%2Fbranch-finder-search%3F0'}
    payload = {"searchString":"York, United Kingdom",
    "SelectedCoordinates":"-1.0872979000000669|53.95996510000001|locality"}
    # payload = {"searchString":Zipp,
    # "SelectedCoordinates":str(Lon)+"|"+str(Lat)+"|postal_code"}
    data = yield requests.post(url,headers = headers,data = payload)
    print(data.text)
    soup = BeautifulSoup(data.content,"lxml")
    for i in soup.find_all("script"):
        if "var branchFinderData" in i.text:
            s = i.text
    latt = []
    lonn = []
    latt = re.findall("Latitude = \"(.*?)\"",s)
    lonn = re.findall("Longitude = \"(.*?)\"",s)
    c = 0
    for i in soup.find_all("div",{"class":"singleBranchDetail"}):
        a = i.find("div",{"class":"BranchResultsAddress"}).text
        State = a.split(",")[-1]
        City = a.split(",")[-2]
        Address = ' '.join(a.split(",")[:-2])
        Zip = i.find("div",{"class":"BranchResultsPostcode"}).text
        # link = i.find("a",{"title":"View detailed branch information"})['href']
        lat = latt[c]
        lon = lonn[c]
        c +=1
        StoreType = ""
        BrandName = "Post Office"
        BussinessName = "Post Office"
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    f = open("/home/skymap/Downloads/spreadsheet - UK_zip_latlon.csv","r")
    for i in f:
        Zipp,Lat,Lon = i.strip("\n").split(",")
        yield from extractor(Zipp,Lat,Lon)
        yield from extractor(1,2,3)
