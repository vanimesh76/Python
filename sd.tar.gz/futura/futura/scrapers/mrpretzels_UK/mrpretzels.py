# # for i in range(30):
# c = re.findall("0\;(.*?) href",data.text)
# for i in c:
#     a = re.findall("\>(.*?)\<a",i)[0].strip("<br/>").replace("</h4>"," ").split("<br/>")

#     if len(a)==4:
#         Phone = ''.join(re.findall("\d+",a[-1]))
#         Zip = re.findall("\w+\d \d\w+|\w+\d, \d\w+|\w+\d\d\w+",a[-2].split(",")[-1])[0]
#         b = a[-2].replace(Zip,"").split(",")
#         if b>1:
#             City =b[0]
#             State = b[1]
#         else:
#             City = b[0]
#         Address = ' '.join(a[:-2]).replace(City,"")
#         print City
#         print State
#         print Zip
#         print Address
#         print Phone
#     elif len(a)==3:
#         Phone = ''.join(re.findall("\d+",a[-1]))
#         if len(Phone)<=5:
#             Zip = re.findall("\w+\d \d\w+|\w+\d, \d\w+|\w+\d\d\w+",a[-1].split(",")[-1])[0]
#             b = a[-1].replace(Zip,"").split(",")
#             if b>1:
#                 City =b[0]
#                 State = b[1]
#             else:
#                 City = b[0]
#             Address = ' '.join(a[:-1]).replace(City,"")
#             print City
#             print State
#             print Zip
#             print Address
#             print Phone
#         else:
#             Zip = re.findall("\w+\d \d\w+|\w+\d, \d\w+|\w+\d\d\w+",a[-2].split(",")[-1])[0]
#             b = a[-2].replace(Zip,"").split(",")
#             if b>1:
#                 City =b[0]
#                 State = b[1]
#             else:
#                 City = b[0]
#             Address = ' '.join(a[:-1]).replace(City,"")
#             print City
#             print State
#             print Zip
#             print Address
#             print Phone