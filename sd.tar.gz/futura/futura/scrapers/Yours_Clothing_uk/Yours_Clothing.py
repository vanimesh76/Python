import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    listt = []
    for i in soup.find_all("div",{"class":"panel-heading panel-heading-stores collapsed"}):
        listt.append(i.find("span",{"itemprop":"name"}).text)
    listt= listt[::-1]
    for i in soup.find_all("div",{"class":"panel-body__stores"}):
        City = listt.pop()
        Address = i.find("span",{"class":"storeSingleLine"}).text
        Zip = i.find("span",{"class":"storePostcode"}).text
        Phone = ''.join(re.findall("\d+",i.find("a",{"class":"storeTelephone"}).text))
        lat = re.findall("addr\=(.*?)\&amp",str(i))[0].split(",")[0]
        lon = re.findall("addr\=(.*?)\&amp",str(i))[0].split(",")[1]
        try:
            print(float(lat))
            print(float(lon))
        except:
            lat =0.0
            lon = 0.0
        Address = Address.replace(City,"")
        if "/img/skin/yc-marker-flat.jpg" in i.find("img",{"class":"stores-key__icons media-object"})['src']:
            StoreType = "Yours Clothing Store"
        else:
            StoreType = "BadRhino Also Available"
        BrandName = "Yours Clothing"
        BusinessName = "Yours Clothing"
        Country = "UK"
        State = ""
        print (lat,lon)
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BusinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("https://www.yoursclothing.com/store-finder")
def seeder(url):
    yield from extractor(url)