import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    url ="http://www.soletrader.co.uk/modules/staff/ajax.aspx"
    headers = {"Host":"www.soletrader.co.uk",
    "Connection":"keep-alive",
    "Content-Length":"90",
    "Pragma":"no-cache",
    "Cache-Control":"no-cache",
    "Origin":"http://www.soletrader.co.uk",
    "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
    "Content-Type":"application/x-www-form-urlencoded; charset=UTF-8",
    "Accept":"application/json, text/javascript, */*; q=0.01",
    "X-Requested-With":"XMLHttpRequest",
    "Referer":"http://www.soletrader.co.uk/service/store-locator/",
    "Accept-Encoding":"gzip, deflate",
    "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
    "Cookie":"SiteCurrentCulture_1=en-GB; incap_ses_501_318169=zsLjDouFj3L/PM6UQ+nzBozLZVkAAAAAsfRXDjhGiWHX3z2iTMrkag==; 0W22OoQ8MbotOrN8e6QobPsxIPRsY7y93Q7c%2BGpIprQ%3D=8FA2753oHY%2BIE9aU2pnyxvP3A1kchuOhlaKKXSdZwmj9yJNBhhHaOxGGyXCXHesxYAuGtoS%2FA9uJ3tGPzetOo%2BvzPwDmfDLZWkXfTgi%2FwXU%3D; ST_emailSignupPopup=1; visid_incap_318169=Hin4EI5jShmdeDnE896ozYvLZVkAAAAAQUIPAAAAAAAVUBOArp0AvHQMJ8L3p6cN; incap_ses_712_318169=+CdMNmqb10g5h7adPIjhCdvkZVkAAAAAWkonk8pzYRz22PCZqafx4Q==; _ga=GA1.3.1046386823.1499843472; _gid=GA1.3.57477099.1499843472; _gat=1; stc111555=env:1499850092%7C20170812090132%7C20170712093132%7C1%7C1013567:20180712090132|uid:1499843477831.1681738114.996512.111555.318805684.9:20180712090132|srchist:1013567%3A1%3A20170812071117%7C1013566%3A1499843487%3A20170812071127%7C1013567%3A1499850092%3A20170812090132:20180712090132|tsa:1499850092502.1391762480.7511883.8743217371180072.:20170712093132; tms_VisitorID=wiiz8o2xrv; _uetsid=_uetf1a31f2f; tms_wsip=1; QU%2Fxy0p8BQVtZZndVWZVo%2FmsFC9IARDu5c%2BoAdnc%2FGE%3D=; LPVID=Y0NjViMmZjMjMyNGYyODY1; LPSID-281333=7RuGhj65TJmSz7YT3EVY-A"}
    payload = {"Longitude":"-0.12775829999998223",
    "Latitude":"51.5073509",
    "RangeInMiles":"9999",
    "F":"GetClosestLocations"}
    data =yield requests.post(url,headers = headers, data = payload)
    data_json = data.json()
    for i in data_json:
        
        City = i['City']
        StoreType = str(i['IsActive'])
        lat = i['Latitude']
        lon = i['Longitude']
        BussinessName = i['Name']
        Phone = i['Phone'].replace(" ","")
        State = i['State']
        Zip = i['Zip']
        Address = i['Address1'].strip()+" "+i['Address2'].strip()
        Address = Address.replace(City,"")
        BrandName = "SOLETRADER"
        Country = "UK"
        State = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=" ")
        yield location

@register("https://store-locator-api.allsaints.com/shops")
def seeder(url):
    yield from extractor(url)