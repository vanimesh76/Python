import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    latt = []
    lonn = []
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "lat" in i.text:
            latt.append(re.findall("lat\: (.*?)\,",i.text)[0])
            lonn.append(re.findall("lng\:(.*?)\,",i.text)[0])
    c = 0
    
    for k in soup.find_all("div",{"class":"county"}):
        for i in k.find_all("div",{"class":"pharmacyDetails"}):
            a = i.find_all("div",{"class":"row"})
            if len(a)==5:
                Phone = a[-1].text.replace(" ","")
                Zip = a[-2].text
                City = a[-3].text
                Address = a[-4].text
                lat = latt[c]
                lon = lonn[c]
                State = ""
                c +=1
                StoreType = ""
                BussinessName = "Rowlands Pharmacy"
                BrandName = "Rowlands Pharmacy"
                Country = "UK"
                Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
                location = StoreLocation(
                    brand_id=None,
                    brand_name=BrandName,
                    store_name=BussinessName,
                    address_1=Address,
                    type=StoreType,
                    city=City,
                    state=State,
                    zipcode=Zip,
                    country_code=Country,
                    latitude=float(lat),
                    longitude=float(lon),
                    phone_number=Phone,
                    secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                    raw_address = Rawaddress,
                    url=url)
                yield location
            elif len(a)==6:
                Phone = a[-1].text.replace(" ","")
                Zip = a[-2].text
                City = a[-3].text
                Address = a[-5].text
                State = a[-4].text
                lat = latt[c]
                lon = lonn[c]
                c+=1
                StoreType = ""
                BussinessName = "Rowlands Pharmacy"
                BrandName = "Rowlands Pharmacy"
                Country = "UK"
                Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
                location = StoreLocation(
                    brand_id=None,
                    brand_name=BrandName,
                    store_name=BussinessName,
                    address_1=Address,
                    type=StoreType,
                    city=City,
                    state=State,
                    zipcode=Zip,
                    country_code=Country,
                    latitude=float(lat),
                    longitude=float(lon),
                    phone_number=Phone,
                    secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                    raw_address = Rawaddress,
                    url=url)
                yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    # linkss = []
    f = open("/home/skymap/PycharmProjects/Virtual env/Thomson.csv",'r')
    for i in f:
        Latitude,Longitude = i.split(",")
        # linkss.append(''.join([]))
        yield from extractor('http://www.rowlandspharmacy.co.uk/pharmacy/?event=rowlands.pharmacyfront.pharmacy.googlemaps.search.do.ajax&lat='+str(Latitude)+'&lng='+str(Longitude).strip("\n")+'&limit=1000&serviceid=&startRow=0')