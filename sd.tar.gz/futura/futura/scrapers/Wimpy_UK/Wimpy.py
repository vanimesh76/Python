import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    a = json.loads(re.findall("var maplistScriptParamsKo = (.*?)\}\;",data.text.replace("\\",""))[0]+"}")
    for i in a['KOObject']:
        for j in i['locations']:
            State = ""
            b = j['address'].replace(">n",">").replace("<p>","").replace("</p>","").split("<br />")
            if len(b)==4:
                Zip = b[-1].split(",")[0]
                State = b[-2]
                City = b[-3]
                Address = b[-4]
            if len(b)==5:
                Zip = b[-1]
                State = b[-2]
                City = b[-3]
                Address = ' '.join(b[:-3])
            if len(b)==6:
                Zip = b[-1].split(",")[0]
                State = b[-3]
                City = b[-4]
                Address = ' '.join(b[:-4])
            if len(b)==3:
                Zip = b[-1]
                City = b[-2]
                Address = b[-3]
            if len(b)==1:
                Zip = re.findall("\w+\d+ \d+\w+",b[-1])[0]
                City = b[-1].replace(Zip,"").strip().split(",")[-1]
                Address = b[-1].replace(Zip,"").replace(City,"").strip(", ")
            lat = j['latitude']
            lon = j['longitude']
            Phone = ''.join(re.findall("\d+",re.findall("Telephone:(.*?)\<",str(j))[0])).lstrip("0")
            StoreType = ""
            BrandName = "Wimpy"
            BussinessName = "Wimpy"
            Country = "UK"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location

@register("https://mcewan.co.za/wimpyuklocator/")
def seeder(url):
    yield from extractor(url)