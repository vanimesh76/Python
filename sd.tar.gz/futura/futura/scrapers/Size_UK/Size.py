import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    try:
        headers = {"Connection":"keep-alive",
        "Pragma":"no-cache",
        "Cache-Control":"no-cache",
        "Upgrade-Insecure-Requests":"1",
        "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
        "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Referer":"https://www.size.co.uk/store-locator/all-stores/",
        "Accept-Encoding":"gzip, deflate, br",
        "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6"}
        data = yield requests.get(url,headers = headers)
        soup = BeautifulSoup(data.text,"lxml")
        a = json.loads(soup.find("script",{"type":"application/ld+json"}).text)
        BussinessName = a['name'].replace("?","")
        lat = a['geo']['latitude']
        lon = a['geo']['longitude']
        Phone = ''.join(re.findall("\d+",a['telephone']))
        Country = "GB"
        City = a['address']['addressLocality']
        State = a['address']['addressRegion']
        Address = a['address']['streetAddress']
        Zip = a['address']['postalCode']
        BrandId = None
        BrandName = "Size"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    except:
        pass


# This registers the seeder(url) to be:
@register("https://www.size.co.uk/sitemaps/sitemap001.xml")
def seeder(url):
    headers = {"Connection":"keep-alive",
    "Pragma":"no-cache",
    "Cache-Control":"no-cache",
    "Upgrade-Insecure-Requests":"1",
    "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Referer":"https://www.size.co.uk/store-locator/all-stores/",
    "Accept-Encoding":"gzip, deflate, br",
    "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6"}
    data = yield requests.get(url,headers = headers)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("loc"):
        if "www.size.co.uk/store-locator" in i.text:
            # print (i.text)
            yield from extractor(i.text)