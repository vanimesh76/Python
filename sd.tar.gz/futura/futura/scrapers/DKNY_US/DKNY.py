import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url,verify = False)
    soup = BeautifulSoup(data.text,"lxml")
    a = soup.find("div",{"id":"outlet-list"})
    for i in a.find_all("li",{"class":"country-list-item"})[:1]:
        Country = i.get("id").split("-")[0].upper()
        for j in i.find_all("div",{"class":"location-list"}):
            try:
                Address = j.find("span",{"class":"c-address-street c-address-street-1"}).text+" "+j.find("span",{"class":"c-address-street c-address-street-2"}).text
            except:
                Address = j.find("span",{"class":"c-address-street c-address-street-1"}).text
            City = j.find("span",{"class":"c-address-city"}).text
            State = j.find("abbr",{"class":"c-address-state"}).text
            Zip = j.find("span",{"class":"c-address-postal-code"}).text
            Phone = ''.join(re.findall("\d+",j.find("div",{"class":"location-phone"}).a['href']))
            StoreType = "Outlet Store"
            BrandName = "DKNY"
            BussinessName = "DKNY"
            g = geocoder.google(Address+","+City+","+State+","+Zip)
            try:
                lat = g.lat
                lon = g.lng
            except:
                lat = 0.0
                lon = 0.0
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location
    a = soup.find("div",{"id":"retail-list"})
    for i in a.find_all("li",{"class":"country-list-item"})[:1]:
        Country = i.get("id").split("-")[0].upper()
        for j in i.find_all("div",{"class":"location-list"}):
            try:
                Address = j.find("span",{"class":"c-address-street c-address-street-1"}).text+" "+j.find("span",{"class":"c-address-street c-address-street-2"}).text
            except:
                Address = j.find("span",{"class":"c-address-street c-address-street-1"}).text
            City = j.find("span",{"class":"c-address-city"}).text
            State = j.find("abbr",{"class":"c-address-state"}).text
            Zip = j.find("span",{"class":"c-address-postal-code"}).text
            Phone = ''.join(re.findall("\d+",j.find("div",{"class":"location-phone"}).a['href']))
            StoreType = "Retail Store"
            BrandName = "DKNY"
            BussinessName = "DKNY"
            g = geocoder.google(Address+","+City+","+State+","+Zip)
            try:
                lat = g.lat
                lon = g.lng
            except:
                lat = 0.0
                lon = 0.0
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location

@register("https://stores.dkny.com/index.html#us-outlet")
def seeder(url):
    yield from extractor(url)