import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "mapsMarkers" in i.text:
            a = json.loads(re.findall("\= (.*?)\;",i.text)[0])
    try:
        Phone = ''.join(re.findall("\d+",soup.find("div",{"itemprop":"telephone"}).text))
    except:
        Phone = ""
        pass
    for i in a:
        Address = i['AddressLine1']
        StoreType = i['Facilities']
        lat = i['Latitude']
        lon = i['Longitude']
        City = i['Location']
        Zip = i['Postcode']
        State = ""
        Country = "UK"
        BussinessName = i['Title']
        BrandName = "Carluccio's"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("https://www.carluccios.com/googlesitemap.xml")
def seeder(url):
    data = yield requests.get(url)
    soupp= BeautifulSoup(data.text,"lxml")
    for j in soupp.find_all("loc"):
        if "restaurants/" in j.text:
            print (j.text)
            yield from extractor(j.text)