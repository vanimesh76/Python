import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    # soup = BeautifulSoup(data.text,"lxml")
    a = data.json()
    for i in a['results'][1:]:
        soup = BeautifulSoup(i['descript'],"lxml")
        c = soup.find("a").text
        b = soup.find("td").br.next
        try:
            Address = re.findall("(.*?)Tel",soup.find("td").text.replace(c,"").replace(b,""))[0]
        except:
            Address = soup.find("td").text.replace(c,"").replace(b,"")
        Zip = b.split()[0]
        City = b.split()[1]
        try:
            Phone = ''.join(re.findall("\d+",re.findall("Tel(.*?)Fax",soup.find("td").text)[0]))
        except:
            Phone = ""
        lat = i['lat']
        lon = i['lng']
        Country = "DE"
        StoreType = ""
        BrandName = "Dat Backhus"
        BussinessName = "Dat Backhus"
        State = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://dat-backhus.de/_include/ajax.asp?LatLng=&intDistance=5000&blnSunday=&blnWifi=&txtView=list&ts=1500363647593")
def seeder(url):
    yield from extractor(url)