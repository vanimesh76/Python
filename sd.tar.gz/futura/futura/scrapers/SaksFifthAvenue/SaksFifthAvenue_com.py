# encoding: utf-8
import json
import logging

from scrapy.spiders import Spider
from scrapy.http import Request

# Import a StoreLocation data structure to hold our POI data:
from ...types import StoreLocation
# And gather our special support for Scrapy:
from ...support import ScrapySupport

logger = logging.getLogger(__name__)
import re


# Be sure to inherit ScrapySupport as the first mixin:
class SaksFifthAvenue_Spider(ScrapySupport, Spider):
    # Specify your start_urls
    start_urls = [
        'http://www.saksfifthavenue.com/stores/allStores.jsp'
    ]

    def parse(self, response):
        links = re.findall(r'"storeEventsURL":\"(.*?)\",', str(response.body))
        # logger.debug(links)
        # This is what you're supposed to use instead of `logger.debug)`
        # You can see this debug line when you run Futura with `--debug`
        # logger.debug('Contacting saksfifthavenue fitness for gyms')

        for link in links:
            link = 'http://www.saksfifthavenue.com' + link
            yield Request(
                url=link,
                callback=self.parse_details)

    def parse_details(self, response):
        logger.debug(response.url)
        body = " ".join(str(response.body).split())
        # logger.debug(body)
        data = re.findall(r'var store = (.*?)\,\"AccessoryFlag\"', str(body))[0]
        data = data + '}'
        # logger.debug(data)

        Data = json.loads(data)
        logger.debug(Data)
        Longitude = Data['Longitude']
        State = Data['State']
        City = Data['City']
        try:
            PhoneNumber = Data['PrimaryPhoneNumber']
        except:
            PhoneNumber = ''
        Latitude = Data['Latitude']
        Full_street1 = Data['AddressLine1']
        Full_street2 = Data['AddressLine2']
        if Full_street2 is None:
            Full_street2 = ''
        else:
            Full_street2 = Full_street2

        Full_Street = Full_street1 + " " + Full_street2
        Zipcode = Data['PostalCode']

        StoreName = 'Saks Fifth Avenue'

        RawAddress = StoreName + "," + Full_Street + "," + City + "," + Zipcode + "," + State

        location = StoreLocation(
            brand_id=0, brand_name='Saks Fifth Avene',
            store_name='Saks Fifth Avene',
            address_1=Full_Street,
            type=None,
            city=City,
            state=State,
            zipcode=Zipcode,
            country_code='US',
            latitude=float(Latitude),
            longitude=float(Longitude),
            phone_number=PhoneNumber,
            raw_address=RawAddress,
            url=response.url)
        # Just `yield` the StoreLocation. Scrapy will capture it and handle it for
        # you.
        yield location
