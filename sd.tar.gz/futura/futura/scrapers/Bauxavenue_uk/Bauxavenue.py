import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"application/json"}):
        if "address1" in i.text:
            a = json.loads(i.text)
    for i in a:
        Address = i['address1']+" "+i['address2']
        City = i['city']
        lat = i['latitude']
        lon = i['longitude']
        BusinessName = i['name']
        Phone = ''.join(re.findall("\d+",i['phone']))
        Zip = i['postalCode']
        BrandName = "Boux Avenue"
        State = ""
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BusinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("http://www.bouxavenue.com/store-locator")
def seeder(url):
    yield from extractor(url)