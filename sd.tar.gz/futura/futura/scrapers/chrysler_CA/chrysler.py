# coding:utf-8
import logging
import json
import random
import re
import time
import requests
import sys
import pdb
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation

def extractor(url):
    print (url)
    headers = {"authority":"www.chrysler.ca",
                "method":"POST",
                "path":"/cci-app-suite/appsbe/retailer/getByPostalCode",
                "scheme":"https",
                "accept":"application/json, text/plain, */*",
                "accept-encoding":"gzip, deflate, br",
                "accept-language":"en-GB,en-US;q=0.8,en;q=0.6",
                "cache-control":"no-cache",
                "content-length":"107",
                "content-type":"application/json;charset=UTF-8",
                # "cookie":"JSESSIONID=08AD673B7769510DC3FC03B28936EF92.tomcat3; mf_a9e52c7a-81cb-4b98-a247-c852473e7048=-1; offers_region=ON%2Contario; __qca=P0-854025291-1499315557705; CAKEPHP=f1vo5265qmd229ifn87qajhfe6; CakeCookie[daaRegion]=ontario; ipe_s=9d20fcbd-437d-5eae-bef2-df6b19f7f4a8; location=%7B%22postalCode%22%3A%22H9R%201B1%22%2C%22province%22%3A%22QC%22%2C%22city%22%3A%22POINTE-CLAIRE%22%2C%22latitude%22%3A45.4738%2C%22longitude%22%3A-73.806%2C%22region%22%3A%22quebec%22%2C%22isConfirmed%22%3Atrue%7D; _ga=GA1.1.1324470612.1499315538; _gid=GA1.1.1694223539.1499315538; s_sq=%5B%5BB%5D%5D; s_cc=true; s_fid=21FEC511948D9069-216AF237DC5EF54F; __utmt=1; __utma=80826437.1324470612.1499315538.1499321341.1499323220.3; __utmb=80826437.1.10.1499323220; __utmc=80826437; __utmz=80826437.1499315554.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)",
                "origin":"https://www.chrysler.ca",
                "pragma":"no-cache",
                "referer":"https://www.chrysler.ca/locateretailer/en/",
                "user-agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"
            }
    payload = {"postalCode":"H9R 1B1","radius":50,"vehBrands":"CD","contest":"false","branches":"true","featuredFirst":"false"}
            
    res = yield requests.post(url,data = json.dumps(payload),headers=headers)
    print("jhsjh")
    print(res.data)
    soup = res.json()
    for store in soup['retailers']:
        BusinessName = store['title']
        Address1 = store['address'].replace('#',' ').replace(',',' ').replace('  ',' ')
        City = store['city']
        State = store['province']
        ZIP = store['postalCode']
        phone = ''.join(re.findall(r'\d+',str(store['phone'])))
        try:
            Latitude = store['latitude']
            Longitude = store['longitude']
        except:
            Latitude = '0.0'
            Longitude = '0.0'
        BrandName = 'Chrysler'
        StoreType = str(store['express']).replace('False','Normal Store').replace('True','Express Store')
        Rawaddress = ', '.join(filter(None, [BrandName, Address1, City,State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BusinessName,
            address_1=Address1,
            type=StoreType,
            city=City,
            state=State,
            zipcode=ZIP,
            country_code='CA',
            latitude=float(Latitude),
            longitude=float(Longitude),
            raw_address =Rawaddress,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            phone_number=phone,
            url=url)
        yield location


@register('http://www.furniturevillage.co.uk/stores/')
def seeder(url):
    print(url)
    url = "https://www.chrysler.ca/cci-app-suite/appsbe/retailer/getByPostalCode"
    yield from extractor(url)
           