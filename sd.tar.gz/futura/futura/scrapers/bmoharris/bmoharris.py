import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    res = yield requests.get(url)
    soup = BeautifulSoup(res.text, 'lxml')
    for i in soup.find_all("div",{"class":"location__item"}):
        lat = i.find("a",{"data-zoom":"14"})['data-lat']
        lon= i.find("a",{"data-zoom":"14"})['data-lng']  
        BussinessName = i.find("a",{"data-zoom":"14"})['data-title']   
        Address = i.find("span",{"itemprop":"streetAddress"}).text
        City = i.find("span",{"itemprop":"addressLocality"}).text
        State = i.find("span",{"itemprop":"addressRegion"}).text
        Zip = i.find("span",{"itemprop":"postalCode"}).text
        Country = i.find("span",{"itemprop":"addressCountry"}).text[:2]
        Phone = ''.join(re.findall("\d+",i.find("span",{"itemprop":"telephone"}).text))
        StoreType = soup.find("ul",{"class":"location__services"}).text.replace("\n","\\")
        BrandId = None
        BrandName = "ryder"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            raw_address = Rawaddress,
            url=url)
        yield location


# This registers the seeder(url) to be:
@register('https://ryder.com/locations/usa')
def seeder(url):
    links = []
    res = yield requests.get(url)
    soup = BeautifulSoup(res.text,"lxml")
    for i in soup.find_all("a",{"class":"js-grab-click js--location__link"})[3:]:
        data = yield requests.get("https://ryder.com"+i['href'])
        soup1 = BeautifulSoup(data.text,"lxml")
        print (i['href'])
        for j in soup1.find_all("a",{"class":"js-grab-click js--location__link location__link--cities"}):
            links.append("https://ryder.com"+j['href'])
        # break
    for l in links:
        yield from extractor(l)
        # break

