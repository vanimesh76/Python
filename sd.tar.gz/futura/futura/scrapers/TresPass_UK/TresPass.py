import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    print (url)
    headers = {"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
"accept-encoding":"gzip, deflate, br",
"accept-language":"en-GB,en-US;q=0.8,en;q=0.6",
"cache-control":"no-cache",
"cookie":"visid_incap_155660=oNCsXSgBQrec1mh0BOyfd7YeXlkAAAAAQUIPAAAAAAAmjVhkGvGI4PI+BjgyCYuz; _cid=ud6wls9ITSgmsqb4; _hjIncludedInSample=1; experiment=0; PHPSESSID=plbe6k4a4mp156g6vhhdqmcb71; _ga=GA1.2.1286983381.1499340474; _gid=GA1.2.22918407.1499340474; incap_ses_501_155660=CwwyG8A2qwuBaExAQenzBpEtXlkAAAAAKa5f2eKSrud1zQEizBtCtw==",
"pragma":"no-cache",
"upgrade-insecure-requests":"1",
"user-agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"}
    data= yield requests.get(url,headers = headers)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "var setLat" in i.text:
            a =  i.text.replace('\n', '').replace('\r', '').replace('\t', '')#.replace('\\', '\')
            c = re.findall('push-half--bottom\"\>\'(.*?)\'\<a href=',a)[0].replace("+","").strip(" ").replace("'","")
            b =  c.split("<br>")
            Zip = b[-1].strip(" ")
            City = b[-2].strip(" ")
            Address = ''.join(b[:-2]).replace("  ","")
            lat = re.findall("setLat = (.*?)\;",i.text)[0]
            lon = re.findall("Lon = (.*?)\;",i.text)[0]
            BrandName = "TresPass"
            BussinessName = "TresPass"
            State = ""
            Phone = re.findall("tel\:(.*?)\"",str(i))[0]
            Country = "UK"
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location

@register("https://www.supercuts.co.uk/page-sitemap.xml")
def seeder(url):
    url = "https://www.trespass.com/storelocator"
    yield from extractor(url)