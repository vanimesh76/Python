# coding:utf-8
import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    res = yield requests.get(url)
    soup = BeautifulSoup(res.text, 'lxml')
    if '"results":[' in str(soup):
        datajsons = str(re.findall(
            r'window.resourceLocator.storeSetup = (.*?)};', str(soup))[0]) + '}'

        datajsons = json.loads(datajsons)
        # print type(datajsons)
        # print datajsons
        for datajson in datajsons['results']:
            country_code = datajson['locationData']['country']
            if country_code != 'AU':
                continue
            state = datajson['locationData']['state']
            lat, lng = datajson['locationData']['geo']

            location = StoreLocation(
                brand_id=285,
                brand_name='Apple Store',
                store_name=datajson['storeName'],
                address_1=' '.join([
                    datajson['locationData']['streetAddress1'],
                    datajson['locationData']['streetAddress2']]),
                type=None,
                city=datajson['locationData']['city'],
                state=state,
                zipcode=datajson['locationData']['postalCode'],
                country_code=country_code,
                latitude=lat,
                longitude=lng,
                phone_number=datajson['phoneNumber'],
                url=url)
            yield location


# This registers the seeder(url) to be:
@register('http://www.latlong.net/country/australia-14.html')
def seeder(url):
    res = yield requests.get(url)
    soup = BeautifulSoup(res.text, "lxml")
    lat_long_link = soup.find('div', {'class': 'col-8'}).find('ul').find_all('li')
    for lat_long in lat_long_link:
        lat_long_links = lat_long.find('a').get('href')
        res2 = yield requests.get(lat_long_links)
        soup2 = BeautifulSoup(res2.text, "lxml")
        if 'next' in str(soup2):
            number_of_pages = soup2.find_all(
                'ul', {'class': 'list-horizontal'})[-2].find_all('li')[-2].text
            for page in range(1, int(number_of_pages)+1):
                pagelink = lat_long_links.replace('.html',  '-' + str(page) + '.html')
                time.sleep(random.randint(1, 4))
                res3 = yield requests.get(pagelink)
                soup3 = BeautifulSoup(res3.text, "lxml")
                lat_long_list = soup3.find('table').find_all('tr')

                for lat_long_main in lat_long_list:
                    if '<td><a href' in str(lat_long_main):
                        Latitude = ''.join(lat_long_main.find('td').find_next('td').text)
                        Longitude = ''.join(
                            lat_long_main.find('td').find_next('td').find_next('td').text)
                        new_url = ''.join(
                            ['https://locate.apple.com/au/en/sales/?pt=all&lat=', str(Latitude),
                             '&lon=', str(Longitude)])

                        yield from extractor(new_url)
                        # print new_url
        else:
            lat_long_list = soup2.find('table').find_all('tr')

            for lat_long_main in lat_long_list:
                if '<td><a href' in str(lat_long_main):
                    Latitude = ''.join(
                        lat_long_main.find('td').find_next('td').text)
                    Longitude = ''.join(
                        lat_long_main.find('td').find_next('td').find_next('td').text)
                    new_url = ''.join(
                        ['https://locate.apple.com/au/en/sales/?pt=all&lat=',
                         str(Latitude), '&lon=', str(Longitude)])

                    yield from extractor(new_url)

