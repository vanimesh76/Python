import logging
import json
import random
import re
import time
import requests
import datetime
import geocoder
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    try:
        Address = soup.find("div",{"class":"street-address"}).text+" "+soup.find("div",{"class":"extended-address"}).text
    except:
        Address = ""
    try:
        City = soup.find("span",{"class":"locality"}).text
    except:
        City = ""
    Zip = soup.find("span",{"class":"postal-code"}).text
    Country = soup.find("div",{"class":"country-name"}).text
    lat = re.findall("latitude\"\:(.*?)\,",data.text)[0]
    lon = re.findall("longitude\"\:(.*?)\,",data.text)[0]
    if "kingdom" in Country.lower():
        Country = "UK"
    elif "ireland" in Country.lower():
        Country = "IR"
    elif str(lat)!="0":
        try:
            g = geocoder.google(lat+","+lon)
            Country = g.country
        except:
            Country = "AA"
    BrandName = "Kurt Geiger"
    BussinessName = "Kurt Geiger"
    State = ""
    StoreType = soup.find("div",{"class":"street-address"}).text
    try:
        Phone = ''.join(re.findall("\d+",soup.find("a",{"class":"phone-number"}).text))
    except:
        Phone = ""
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BussinessName,
        address_1=Address,
        type=StoreType,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("http://www.kurtgeiger.com/storelocator")
def seeder(url):
    data= yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    a = soupp.find("dl",{"id":"tabs"})
    for i in a.find_all("a")[0:-1:2]:
        c = re.findall("\d+",i['href'])[0]
        yield from extractor("http://www.kurtgeiger.com/storelocator/store/view/id/"+c)
        if "138" == str(c):
            break
