import logging
import json
import random
import re
import time
import requests
import datetime
import ast
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "new Array" in i.text:
            listt = "["+re.findall("\((.*?)\)",i.text.replace("\r","").replace("\n","").replace("    ",""))[0]+"]"
    listt = ast.literal_eval(listt)
    for i in listt:
        lon = i[0]
        lat = i[1]
        Address = i[3].strip()+" "+i[4].strip()
        City = i[5].strip()
        State = i[6].strip()
        Zip = i[7].strip()
        Phone = i[8].replace(" ","").strip()
        BrandName = "Papa John's"
        BussinessName = "Papa John's"
        StoreType = ""
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address.strip(),
            type=StoreType,
            city=City.strip(),
            state=State.strip(),
            zipcode=Zip.strip(),
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone.strip(),
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.papajohns.co.uk/store-locator.aspx")
def seeder(url):
    yield from extractor(url)