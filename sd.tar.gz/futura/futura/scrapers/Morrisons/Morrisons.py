# coding:utf-8
import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    res = yield requests.get(url)
    a = res.json()
    for i in a['stores']:
        Address = i['address']['addressLine1']+" "+ i['address']['addressLine2']
        City = i['address']['city']
        Country = "UK"
        State =  i['address']['county']
        Zip = i['address']['postcode']
        lat = i['location']['latitude']
        lon = i['location']['longitude']
        BussinessName = i['storeName']
        StoreType = i['storeFormat']
        BrandId = None
        BrandName = "Morrisonss"
        Phone = i['telephone']
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=284,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=lat,
            longitude=lon,
            phone_number=Phone,
            raw_address = Rawaddress,
            url=url)
        yield location


# This registers the seeder(url) to be:
@register('https://api.morrisons.com/location/v2/stores?apikey=nIqSiqIFeSeaQEomK5F0PHKfyNKKVVvD&distance=5000000&lat=51.5205001831055&limit=10000&lon=-0.0974299982190132&offset=1&storeformat=supermarket')
def seeder(url):
    yield from extractor(url)

