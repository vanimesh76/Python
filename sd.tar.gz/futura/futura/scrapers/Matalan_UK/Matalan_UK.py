import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    b = json.loads(re.findall("var stores = (.*?)\;\\n",soup.find("p",{"id":"googleCurrentMarkerIcon"}).find_next("script").text)[0])
    for i in b:
        a = i['attributes']['address'].replace("\n\n","\n").split("\n")
        Country = a[-1]
        Zip = a[-2]
        City = i['attributes']['title']
        if len(a)==5:
            Address = a[-5]+" "+a[-4]
        else:
            Address = a[-4]
        lat = i['attributes']['latitude']
        lon = i['attributes']['longitude']
        State = ""
        Phone = ''.join(re.findall("\d+",i['attributes']['phone_number']))
        BussinessName = "Matalan"
        BrandId = None
        BrandName = "Matalan"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("https://www.matalan.co.uk/stores")
def seeder(url):
    yield from extractor(url)