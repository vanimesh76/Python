import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("marker"):
        Zip = i['address'].split(",")[-1]
        Phone = ''.join(re.findall("\d+",i['contactno']))
        City = i['name']
        Address = i['address'].replace(City,"").replace(Zip,"").replace(",","").strip(" ")
        BusinessName= i['manager']
        lat = i['lat']
        lon = i['lng']
        State = ""
        Country = "UK"
        BrandName = "The Whisky Shop"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BusinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

# This registers the seeder(url) to be:
@register("https://www.whiskyshop.com/lib/googlemaps/ajax-call.php?cmd=getmapstart&bounds=((48.38361828151321,%20-17.90771481249999),%20(59.87653362038744,%2011.00830081250001))")
def seeder(url):
    print("sds")
    yield from extractor(url)