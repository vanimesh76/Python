import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    a = soup.find("p",{"class":"context"}).text
    City = soup.find("h1",{"class":"storetitle"}).text
    Zip = a.split("\n")[-1].strip(" ")
    try:
        Address = a.split("\n")[-2].split(",")
        State = ""
        try:
            City = Address[0]
            State = Address[1]
        except:
            City = Address[0]
        Address = ''.join(a.replace(City,"").replace(State,"").split("\n")[:-1])
    except:
        Address = a
    for i in soup.find_all("tr"):
        if "Tel" in i.text:
            Phone = ''.join(re.findall("\d+",i.text))

    for i in soup.find_all("iframe"):
        if "maps" in i['src']:
            try:
                lat = re.findall("\&ll\=(.*?)\&spn",i['src'])[0].split(",")[0]
                lon = re.findall("\&ll\=(.*?)\&spn",i['src'])[0].split(",")[1] 
            except:
                try:
                    lat = re.findall("3d(.*?)\!",i['src'])[0]
                    lon = re.findall("2d(.*?)\!",i['src'])[0]
                except:
                    lat = 0.0
                    lon = 0.0
    State = ""
    BrandName = "The White Company"
    BussinessName = "The White Company"
    Country = "UK"
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BussinessName,
        address_1=Address,
        type=None,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location
    # except:
    #     pass

# This registers the seeder(url) to be:
@register("http://www.thewhitecompany.com/stores/")
def seeder(url):
    data = yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    b = soupp.find("ul",{"class":"clearfix medium-txt line-height-2"})
    for i in b.find_all("ul",{"style":"padding-left:5%;"}):
        for j in i.find_all("a"):
            yield from extractor("http://www.thewhitecompany.com"+j['href'])