import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "storeLocator" in i.text:
            a = json.loads(re.findall("initial_locations:(.*?)\]\,",i.text)[0]+"]")
    for i in a:
        City = i['city']
        Country = i['country']
        lat = i['latitude']
        lon = i['longitude']
        Phone = ''.join(re.findall("\d+",i['phone']))
        Zip = i['post_code']
        State = i['region']
        Address = i['address1']
        BrandName = "Fraser Hart"
        BussinessName = "Fraser Hart"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.fraserhart.co.uk/ustorelocator/location/map/")
def seeder(url):
    yield from extractor(url)