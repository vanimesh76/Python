# from bs4 import BeautifulSoup
# import urllib2
# import requests
# import json
# import re
# import MySQLdb
# import datetime
# import time
# import os
# import pp
# import math
# import csv
# con = MySQLdb.connect(host='10.100.10.46', user='root', passwd='india@123', db='O_O_DATA', use_unicode=True, charset="utf8")
# cur = con.cursor()


# def visit(url, start_index):
#     from bs4 import BeautifulSoup
#     import requests
#     import re
#     import random
#     import time
#     import MySQLdb
#     import sys
#     import datetime
#     import csv
#     import json
#     import pp
#     import math
#     import itertools
#     import os
#     import urllib2
#     #     print url
#     #     try:
#     con = MySQLdb.connect(host='10.100.10.46', user='root', passwd='india@123', db='O_O_DATA', use_unicode=True,
#                           charset="utf8")
#     cur = con.cursor()
#     for l in url:
#         try:
#             data = requests.get(l)
#             soup = BeautifulSoup(data.text,"lxml")
#             for i in soup.find_all("script",{"type":"text/javascript"}):
#                 if "storeLocatorWidget" in i.text:
#                     a = json.loads(re.findall("storeDetailsAsJson\: (.*?),fromStorePages",i.text.replace("\n","").replace("\t",""))[0])
#             Address =  a['highStreetStoreDetails'][0]['address1']+" "+a['highStreetStoreDetails'][0]['address2']
#             Country =  a['highStreetStoreDetails'][0]['countryCode']
#             lat = a['highStreetStoreDetails'][0]['latitude']
#             lon = a['highStreetStoreDetails'][0]['longitude']
#             Zip = a['highStreetStoreDetails'][0]['postcode']
#             State = a['highStreetStoreDetails'][0]['county']
#             City = a['highStreetStoreDetails'][0]['town']
#             Phone = ''.join(re.findall("\d+",a['highStreetStoreDetails'][0]['telephone']))
#             BrandName = "Halfords"
#             BussinessName = ""
#             BrandId = None
#             StoreType = ""
#             string_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
#             Last_update = datetime.datetime.strptime(string_time, "%Y-%m-%d %H:%M:%S")
#             Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
#             SecondarySIC = datetime.datetime.now().strftime("%Y-%m")
#             PrimarySIC = ''
#             Data = [BrandName, BussinessName, StoreType, Address, City, State, Zip, Country, Phone, PrimarySIC,
#                 SecondarySIC, lat, lon, BrandId, Rawaddress, Last_update, l]
#             # print Data
#             # break
#             cur.execute("INSERT IGNORE INTO " + str(
#                 'O_O_DATA') + " values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", Data)
#             con.commit()
#         except Exception as e:
#             print e
#             print l
#             pass
# linkss = []
# f = open("/home/skymap/PycharmProjects/Virtual env/futura/futura/scrapers/Halfords/sitemap-halfords-spac.xml",'r')
# data = f.read()

# soup = BeautifulSoup(data,"lxml")
# for i in soup.find_all("loc"):
#     # print i.text
#     if "ACArticleDisplay" not in str(i.text):
#         # print i.text
#         linkss.append(i.text)
        


# start_time = time.time()
# def increaser(inputlist):
#     number_of_process = 24
#     lencheck = len(inputlist)%number_of_process
#     # print len(inputlist), lencheck
#     for i in range(0, number_of_process-lencheck):
#         inputlist.append('')
#     # lencheck = len(inputlist)/number_of_process
#     # print lencheck,len(inputlist)
# #     print inputlist
#     return inputlist
# # print linkss
# url_list = increaser(linkss)

# def mp(url_list):
# #     print url_list
#     job_server = pp.Server(secret='abc')
#     job_server.set_ncpus(24)
#     slot = int(math.ceil(len(url_list)/job_server.get_ncpus()))
#     start_index = 0
#     end_index = 0
#     jobs = []

#     for k in range(job_server.get_ncpus()):
#         start_index = end_index
#         end_index = start_index+slot
#         print start_index,end_index
#         _file = url_list[start_index:end_index]
#         # print _file
#         jobs.append(job_server.submit(visit,(_file, start_index)))

#     for job in jobs:
#         print job()
#         print("--- %s seconds ---" % (time.time() - start_time))
# mp(url_list)
