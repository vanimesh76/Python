import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    try:
        print (url)
        res = yield requests.get(url)
        soup = BeautifulSoup(res.text,"lxml")
        Address = soup.find("span",{"itemprop":"streetAddress"}).text
        City = soup.find("span",{"itemprop":"addressLocality"}).text
        State = soup.find("span",{"itemprop":"addressRegion"}).text
        Zip = soup.find("span",{"itemprop":"postalCode"}).text
        Phone = soup.find("span",{"itemprop":"telephone"}).text
        lat = re.findall("lat\=(.*?)\&",str(soup.find("div",{"class":"store-map"}).noscript))[0]
        lon = re.findall("long\=(.*?)\&",str(soup.find("div",{"class":"store-map"}).noscript))[0]
        Country = "UK"
        BrandId = None
        BrandName = "Argos"
        StoreType = ""
        BussinessName = soup.find("div",{"itemprop":"name"}).text
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State,str(lat),str(lon)]))
        SecondarySIC = datetime.datetime.now().strftime("%Y-%m")
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = SecondarySIC,
            raw_address = Rawaddress,
            url=url)
        yield location
    except:
        print(url)
        pass


# This registers the seeder(url) to be:
@register('http://www.argos.co.uk/stores/')
def seeder(url):
    res =yield requests.get(url)
    soupp = BeautifulSoup(res.text,"lxml")
    for j in soupp.find_all("div",{"class":"store_list_data"}):
        for i in j.find_all("a"):
             yield from extractor("http://www.argos.co.uk"+i['href'])

