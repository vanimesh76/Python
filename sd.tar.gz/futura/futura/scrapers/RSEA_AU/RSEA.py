import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(j):
    url = "https://www.rsea.com.au/service/storeLocator/findNearestStore?rand=1500445791647"
    headers = {"Host":"www.rsea.com.au",
    "Connection":"keep-alive",
    "Content-Length":"244",
    "Pragma":"no-cache",
    "Cache-Control":"no-cache",
    "Origin":"https://www.rsea.com.au",
    "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
    "Content-Type":"application/json; charset=UTF-8",
    "Accept":"application/json, text/javascript, */*; q=0.01",
    "X-Requested-With":"XMLHttpRequest",
    "Referer":"https://www.rsea.com.au/store-locator",
    "Accept-Encoding":"gzip, deflate, br",
    "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
    "Cookie":"ASP.NET_SessionId=qss13wrkqxkiokpr5abohyaw; pnctest=1; dynamicServiceSessionId=guestuser00f4e7f3-6f12-4998-8290-cfb91efc9e1b; _ga=GA1.3.1247289067.1500373646; _gid=GA1.3.1530738864.1500373646; __insp_wid=520644594; __insp_slim=1500445116338; __insp_nv=true; __insp_targlpu=aHR0cHM6Ly93d3cucnNlYS5jb20uYXUvc3RvcmUtbG9jYXRvcg%3D%3D; __insp_targlpt=U3RvcmUgTG9jYXRvcg%3D%3D; __insp_norec_sess=true"}
    payload = {"latitude":0,"longitude":0,"filters":"State:eq:"+j,"featureFilter":"","maxStores":0,"jsonFieldGroupName":"","checkStoreAvailabilityClickAndCollect":False,"_sessionId":"guestuser00f4e7f3-6f12-4998-8290-cfb91efc9e1b","_applicationType":"cssnet"}
    data = yield requests.post(url,headers = headers, data = json.dumps(payload))
    a = json.loads(data.text)
    for i in a['data']:
        Address = i['AddressLine1'].strip()+" "+i['AddressLine2']
        Country = "AU"
        StoreType = str(i['IsActive'])
        lat = i['Latitude']
        lon = i['Longitude']
        Phone = i['Phone'].replace(" ","")
        Zip = i['Postcode']
        State = i['State']
        BussinessName = i['StoreName']
        City = i['Suburb']
        BrandName = "RSEA"

        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    listt = ["NT","QLD","SA","TAS","VIC","WA","NSW"]
    for j in listt:
        yield from extractor(j)