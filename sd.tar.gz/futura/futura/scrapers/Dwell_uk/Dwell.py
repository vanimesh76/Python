import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    a = soup.find("div",{"id":"istores"})
    for i in a.find_all("a"):
        url = i['href']
        data = yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        for i in soup.find_all("script",{"type":"application/ld+json"}):
            if "context" in i.text:
                data = json.loads(i.text)
        aa =' '.join(soup.find("address").text.strip().replace("\t","").replace(" \r\n",",").replace("    ","").split(","))
        City = data['address']['addressLocality']
        State = data['address']['addressRegion']
        Zip = data['address']['postalCode']
        Address = data['address']['streetAddress']
        # BussinessName = data['name']
        Address = Address+" "+aa.replace(Address,"").replace(City,"").replace(State,"").replace(Zip,"").strip()
        Phone = data['telephone'].replace(" ","")
        try:
            lat = re.findall("2d(.*?)\!",soup.find_all("iframe")[1]['src'])[0]
            lon = re.findall("3d(.*?)\!",soup.find_all("iframe")[1]['src'])[0]
        except:
            url = ''.join(['http://geocode.xad.com:8080/xadutils/tools/geocode?country=', Country, '&city=', City, '&zipcode=', Zip, '&address1=', Address, '&state=', State])
            headers = {'X-ACCESS-KEY':'1bb0e458-29d7-4c63-95af-03b19fcb1f91', 'X-APP-ID':'SCRAPE'}
            res = yield requests.get(url, headers = headers)
            datajson =  res.json()
            if 'result' in datajson.keys():
                lat = datajson['result']['lat']
                lon = datajson['result']['lon']
            else:
                lat = 0.0
                lon = 0.0
        BrandName = "Dwell"
        BussinessName = "Dwell"
        Country = "UK"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://dwell.co.uk/stores.htm")
def seeder(url):
    yield from extractor(url)