# coding:utf-8
import datetime
import logging
from ...types import StoreLocation
from ...support.bs4 import register

import requests


logger = logging.getLogger(__name__)


# This allows for this scraper to be accessible from Futura:
# This is where we'll store our Location Data:
@register('http://www.ah.be/data/winkelinformatie/winkels/json')
def seeder(url):
    res = yield requests.get(url)
    # soup = res.text.encode('utf-8')
    store_info = res.json()
    for store_infos in store_info['stores']:
        Address2 = store_infos['street']
        Address3 = store_infos['housenr']
        Address1 = ''.join([Address2, ' ', Address3])
        City = store_infos['city']
        State = ''
        ZIP = store_infos['zip']
        Country = 'BE'
        phone = store_infos['phoneNumber']
        Latitude = store_infos['lat']
        Longitude = store_infos['lng']
        BrandID = 0
        BrandName = 'AlbertHeijn'
        BusinessName = 'AlbertHeijn'
        storetype = ''
        string_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        Last_update = datetime.datetime.strptime(string_time, "%Y-%m-%d %H:%M:%S")
        PrimarySIC = ''
        SecondarySIC = ''
        Rawaddress = ', '.join([BrandName, Address1, City, State])
        Data = (BrandID, BrandName, BusinessName, storetype, Address1, City, State, ZIP,
                Country, phone, PrimarySIC, SecondarySIC, Latitude, Longitude, BrandID,
                Rawaddress, Last_update, url)

        location = StoreLocation(*Data)
        yield location
