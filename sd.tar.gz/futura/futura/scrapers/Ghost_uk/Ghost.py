import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        listt = ["STOCKISTS","CONSESSIONS","OUTLETS","BOUTIQUE"]
        for i in soup.find_all("section",{"role":"generic"})[:-1]:
            StoreType = listt.pop()
            for j in i.find_all("li",{"class":"four columns loc-details"}):
                try:
                    Zip = str(j.find("ul")).replace("</li><li>",",").replace("</li></ul>","").replace("<ul><li>","").strip(", ").split(",")[-1]
                    City = str(j.find("ul")).replace("</li><li>",",").replace("</li></ul>","").replace("<ul><li>","").strip(", ").split(",")[-2]
                    Address =''.join(str(j.find("ul")).replace("</li><li>",",").replace("</li></ul>","").replace("<ul><li>","").strip(", ").replace(Zip,"").replace(City,"").split(","))
                    Phone  =''.join(re.findall("\d+",j.find("div",{"class":"tel"}).text))
                    try:
                        lat = re.findall("\?q\=(.*?)\&",j.find("iframe",{"height":"450"})['src'])[0].split(",")[0]
                        lon = re.findall("\?q\=(.*?)\&",j.find("iframe",{"height":"450"})['src'])[0].split(",")[1]
                    except TypeError:
                        lat =0.0
                        lon = 0.0
                except IndexError:
                    pass
                
                BussinessName = ""
                BrandName = "Ghost"
                Country = "UK"
                State = ""
                Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
                location = StoreLocation(
                    brand_id=None,
                    brand_name=BrandName,
                    store_name=BussinessName,
                    address_1=Address,
                    type=StoreType,
                    city=City,
                    state="",
                    zipcode=Zip,
                    country_code=Country,
                    latitude=float(lat),
                    longitude=float(lon),
                    phone_number=Phone,
                    secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                    raw_address = Rawaddress,
                    url=url)
                yield location

# This registers the seeder(url) to be:
@register("http://www.ghost.co.uk/stores")
def seeder(url):
    yield from extractor(url)