import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(Zipp):
    data= yield requests.get("https://www.superdrug.com/store-finder?country=GB&q="+Zipp)
    soup = BeautifulSoup(data.text,"lxml")
    d = soup.find("div",{"class":"AjaxStoreName hide"})
    latt = []
    lonn = []
    c = 0
    try:
        for i in d.find_all("li"):
            latt.append(re.findall("\d+.\d+",i.text)[0])
            try:
                lonn.append(re.findall("-\d+.\d+",i.text)[0])
            except:
                lonn.append(re.findall("\d+.\d+",i.text)[1])
        for i in soup.find_all("li",{"class":"storename list-group-item-info"}):
            a = i.find("div",{"class":"storeaddress hide"}).text.replace("\t","").replace("\r","").strip("\n").strip(",\n ").split("\n")[0].strip(",").split(",")
            Zip = a[-1].strip()
            City = a[-2].strip()
            if a[-2].strip() == a[0]:
                Address = ' '.join(a[:3]).replace(City,"")
            else:
                Address = ' '.join(a[:3])
            lat = latt[c]
            lon = lonn[c]
            c+=1
            Phone = i.find("div",{"class":"popupcontent hide"}).b.next.next.replace(" ","")
            BrandName = "Superdrugs"
            BussinessName = "Superdrugs"
            State = ""
            Country = "UK"
            url = "https://www.superdrug.com"+i.a['href']
            data = yield requests.get(url)
            soupp = BeautifulSoup(data.text,"lxml")
            try:
                StoreType = soupp.find("p",{"class":"services"}).text.replace("Services","").replace("\t","").replace("\n","").replace("\r","").strip()
            except:
                StoreType = ""
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location
    except:
        pass

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    f = open("/home/skymap/Downloads/spreadsheet - UK_zip_latlon.csv","r")
    for i in f:
        Zipp,Lat,Lon = i.strip("\n").split(",")
        yield from extractor(Zipp.lstrip("0"))