# coding:utf-8
import logging
import json
import random
import re
import time
import requests

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register, RequestArguments
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url, cookies):
    headers = {
        "referer": "https://www.kwikshop.com/storeDirections?store=67200782",
        "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"
    }

    res = yield requests.get(url, cookies=cookies, headers=headers)
    print(res.text)
    soup = res.json()
    brand = soup['storeInformation']['brand']
    if brand == 'KWIK':
        try:
            location = StoreLocation(
                brand_id=None,
                brand_name='Kwik Shop',
                store_name= soup['storeInformation']['localName'],
                address_1= soup['storeInformation']['address']['addressLineOne'],
                type=None,
                city=soup['storeInformation']['address']['city'],
                state=soup['storeInformation']['address']['state'],
                zipcode=soup['storeInformation']['address']['zipCode'],
                country_code='US',
                latitude=float(soup['storeInformation']['latLong']['latitude']),
                longitude=float(soup['storeInformation']['latLong']['longitude']),
                phone_number=''.join(re.findall(r'\d+',soup['storeInformation']['phoneNumber']))[:10],
                url=url)
            yield location
        except:
            pass


@register(RequestArguments('https://www.kwikshop.com', {'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36'}))
def seeder(request_arguments):
    initial_session = yield requests.get(**request_arguments._asdict())

    res = yield requests.get(
        '{}/sitemap/kwikshop-storelocator.xml'.format(request_arguments.url),
        cookies=initial_session.cookies)

    soup = BeautifulSoup(res.text.encode('utf-8'), 'lxml')
    logger.debug(soup)
    store_link = soup.find_all('loc')
    logger.debug(store_link)
    for link in store_link:
        final_link = link.text
        if '/storeHours?store=' in str(final_link):
            store_information_link = \
                'https://www.kwikshop.com/store?store='+str(final_link.split('=')[-1])
            logger.debug(store_information_link)
            yield from extractor(store_information_link, res.cookies)
