import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    a = data.json()
    for i in a:
        Address = i['address']+" "+i['address2']
        City = i['city']
        lat = i['lat']
        lon = i['lng']
        State = i['state']
        BussinessName = i['store']
        Zip = i['zip']
        BrandName = "Mobile Bitz"
        StoreType = ""
        Phone = ""
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.mobilebitzltd.com/wp-admin/admin-ajax.php?action=store_search&lat=55.378051&lng=-3.43597299999999&max_results=500&radius=100&autoload=1")
def seeder(url):
    yield from extractor(url)