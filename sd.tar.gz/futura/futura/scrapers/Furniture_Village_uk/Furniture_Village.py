import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    Address = soup.find("span",{"itemprop":"streetAddress"}).text
    City = soup.find("span",{"itemprop":"addressLocality"}).text
    State = soup.find("span",{"itemprop":"addressRegion"}).text
    Zip = soup.find("span",{"itemprop":"postalCode"}).text
    Phone = ''.join(re.findall("\d+",soup.find("meta",{"itemprop":"telephone"})['content']))
    lat = soup.find("meta",{"itemprop":"latitude"})['content']
    lon = soup.find("meta",{"itemprop":"longitude"})['content']
    BrandName = "Furniture Village"
    Country = "GB"
    StoreType = ""
    BussinessName = "Furniture Village"
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BussinessName,
        address_1=Address,
        type=StoreType,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location

@register("http://www.furniturevillage.co.uk/stores/")
def seeder(url):
    data = yield requests.get(url)
    soupp = BeautifulSoup(data.text,"lxml")
    for i in soupp.find_all("option")[1:]:
        yield from extractor("http://www.furniturevillage.co.uk"+i["value"])