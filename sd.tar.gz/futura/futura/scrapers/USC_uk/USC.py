import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    url = "http://www.usc.co.uk/Stores/Search?lat=51.5073509&long=-0.1277583&sd=500"
    headers = {"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"}
    data = yield requests.get(url, headers = headers)
    soup = BeautifulSoup(data.text,"lxml",from_encoding="utf-8")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "markerOptions" in i.text:
            a =  json.loads("["+re.findall("\[(.*?)\]",i.text)[0]+"]")
    for i in a:
        soupp = BeautifulSoup(i['info'],"lxml")
        b = str(soupp.find("div",{"class":"StoreFinderBalloonFirst"})).replace("</div>","").strip("<br/>")
        c = b.split("<br/>")
        Zip = c[-1]
        City = c[-2]
        Address = c[-5]+" "+c[-4]+" "+c[-3]
        Phone = ''.join(re.findall("\d+",re.findall("Tel:(.*?)O",soupp.find("div",{"class":"StoreFinderBalloonSecond"}).text)[0]))
        lat = i['position']['lat']
        lon = i['position']['lng']
        BrandName = "USC"
        BussinessName = "USC"
        State = ""
        Country = "UK"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.usc.co.uk/Stores/Search?lat=51.5073509&long=-0.1277583&sd=500")
def seeder(url):
    yield from extractor(url)