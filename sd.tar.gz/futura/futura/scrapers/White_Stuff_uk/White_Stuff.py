import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script"):
        if "myStores" in i.text:
            data_json = json.loads("["+re.findall("\[(.*?)\]",i.text)[0]+"]")
    for i in data_json:
        Address = i['address1'].strip()+" "+i['address2'].strip()+" "+i['address3'].strip()
        lat = i['pca_wgs84_latitude']
        lon = i['pca_wgs84_longitude']
        Zip = i['postcode'].strip()
        State = i['region'].strip()
        Phone = ''.join(re.findall("\d+",i['storecontacts']))
        City = i['town'].strip()
        Country = "UK"
        BrandName = "White Stuff"
        BussinessName = re.findall("\((.*?)\)",i['name'])
        try:
            BussinessName = BussinessName[0]
        except:
            BussinessName = "White Stuff"
        StoreType = i['storeType']
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.whitestuff.com/storelocator.asp")
def seeder(url):
    yield from extractor(url)