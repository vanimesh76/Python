import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    StoreType = soup.find("span",{"class":"location-name-brand"}).text
    BussinessName = soup.find("span",{"class":"location-name-geo"}).text
    try:
        Address = soup.find("span",{"class":"c-address-street-1"}).text.strip()+" "+soup.find("span",{"class":"c-address-street-2"}).text.strip()
    except:
        Address = soup.find("span",{"class":"c-address-street-1"}).text.strip()
    State = soup.find("abbr",{"itemprop":"addressRegion"}).text
    City = soup.find("span",{"itemprop":"addressLocality"}).text
    Zip = soup.find("span",{"itemprop":"postalCode"}).text
    Country = soup.find("abbr",{"itemprop":"addressCountry"}).text
    Phone = ''.join(re.findall("\d+",soup.find("a",{"class":"c-phone-number-link c-phone-main-number-link"}).text))
    lat = re.findall("latitude\"\:(.*?)\,",data.text)[0]
    lon = re.findall("longitude\"\:(.*?)\,",data.text)[0]
    BrandName = "Guess"
    Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
    location = StoreLocation(
        brand_id=None,
        brand_name=BrandName,
        store_name=BussinessName,
        address_1=Address,
        type=StoreType,
        city=City,
        state=State,
        zipcode=Zip,
        country_code=Country,
        latitude=float(lat),
        longitude=float(lon),
        phone_number=Phone,
        secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
        raw_address = Rawaddress,
        url=url)
    yield location

@register("https://stores.guess.ca/index.html")
def seeder(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("li",{"class":"c-directory-list-content-item"}):
        data = yield requests.get("https://stores.guess.ca/"+i.a['href'])
        soupp = BeautifulSoup(data.text,"lxml")
        for j in soupp.find_all("li",{"class":"c-directory-list-content-item"}):
            data = yield requests.get("https://stores.guess.ca/"+re.findall("\.\.\/(.*?)$",j.a['href'])[0])
            souppp = BeautifulSoup(data.text,"lxml")
            for k in souppp.find_all("div",{"class":"c-location-grid-col"}):
                # listt.append("https://stores.guess.ca/"+re.findall("\.\.\/\.\.\/(.*?)$",k.a['href'])[0])
                yield from extractor("https://stores.guess.ca/"+re.findall("\.\.\/\.\.\/(.*?)$",k.a['href'])[0])