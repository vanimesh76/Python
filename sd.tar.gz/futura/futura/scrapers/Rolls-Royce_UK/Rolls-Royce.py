import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    a = data.json()
    for i in a['showrooms']:
        try:
            Phone = ''.join(re.findall("\d+",i['value']['contactInformation']['telephoneNumber']))
        except:
            Phone =""
        BussinessName = i['value']['dealerTradingName']
        StoreType = "Showroom"
        if i['value']['isDealer']==True:
            StoreType = StoreType+"/Dealer"
        elif  i['value']['isService']==True:
            StoreType = StoreType+"/Service"
        lat = i['value']['geolocation']['latitude']
        lon = i['value']['geolocation']['longitude']
        Zip = i['value']['postalAddress']['postalCode']
        City = i['value']['postalAddress']['city']
        State = i['value']['postalAddress']['state']
        Address = str(i['value']['postalAddress']['line1'])+" "+str(i['value']['postalAddress']['line2'])+" "+str(i['value']['postalAddress']['line3'])
        Address = Address.replace("None","")
        BrandName = "Rolls-Royce"
        Country = "US"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State, StoreType]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    for i in a['aftersales']:
        try:
            Phone = ''.join(re.findall("\d+",i['value']['contactInformation']['telephoneNumber']))
        except:
            Phone =""
        BussinessName = i['value']['dealerTradingName']
        StoreType = "AfterSales"
        if i['value']['isDealer']==True:
            StoreType = StoreType+"/Dealer"
        elif  i['value']['isService']==True:
            StoreType = StoreType+"/Service"
        lat = i['value']['geolocation']['latitude']
        lon = i['value']['geolocation']['longitude']
        Zip = i['value']['postalAddress']['postalCode']
        City = i['value']['postalAddress']['city']
        State = i['value']['postalAddress']['state']
        Address = str(i['value']['postalAddress']['line1'])+" "+str(i['value']['postalAddress']['line2'])+" "+str(i['value']['postalAddress']['line3'])
        Address = Address.replace("None","")
        BrandName = "Rolls-Royce"
        Country = "US"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State, StoreType]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    # l = ["London","The Tower of London","Big Ben","Buckingham Palace","Oxford Street","London Eye","york","Leeds","Belfast","Plymouth","Hull","Piccadilly Circus","Harrow","Aberdeen","Dunfermline","Cardiff","Inverness","Swansea","Bournemouth","Oxford","Hove","Swindon","Bedford","Preston","Heathrow Airport (LHR)","Gravesend","Solihull","Dover","Essex","Cornwall","Buckingham Palace Gardens","Church of England Cathedral of the Diocese of Liverpool","Doncaster","Weybridge","Harlow","Wolverhampton","Ashford","Northampton","Londonderry","Weymouth","Port Solent","Rugby","Boston","Salisbury","Kendal","Isle of Dogs","Marylebone","Glasgow Prestwick Airport (PIK)","Hastings","Wem","Enfield"]
    f = open("/home/skymap/Downloads/Downloads/US_ZIP.csv","r")
    for i in f:
        url = "https://www.rolls-roycemotorcars.com/services/dealerlocator?q=United%20States,"+str(i)
        # url = "https://www.rolls-roycemotorcars.com/services/dealerlocator?q=United%20Kingdom,"+i.lstrip("0")
        yield from extractor(url)