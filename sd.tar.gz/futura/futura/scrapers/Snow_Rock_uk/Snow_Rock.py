import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    data_json = data.json()
    for i in data_json:
        City = i['city']
        lat = i['latitude']
        lon = i['longitude']
        Phone = i['phoneNumber'].replace(" ","")
        Zip = i['postalcode']
        Address = i['street']
        BrandName = "Snow & Rock"
        BussinessName = "Snow & Rock"
        State = ""
        Country = "UK"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.snowandrock.com/api/services/public/store/snowandrock/en")
def seeder(url):
    yield from extractor(url)