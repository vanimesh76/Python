import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    data_json =data.json()
    for i in data_json:
        Country = i['country']
        if "kingdom" in Country.lower():
            Country = "UK"
        elif "usa" in Country.lower():
            Country = "US"
        elif "germany" in Country.lower():
            Country = "DE"
        elif "france" in Country.lower():
            Country = "FR"
        elif "canada" in Country.lower():
            Country = "CA"
        if Country in ["US","CA","DE","FR","UK"]:
            if i['address_line2']==None:
                Address = i['address_line1'].strip()
            elif i['address_line3']==None:
                Address = i['address_line1'].strip()+" "+i['address_line2'].strip()
            else:
                Address = i['address_line1'].strip()+" "+i['address_line2'].strip()+" "+i['address_line3'].strip()
            City = i['city']
            State = ""
            lat = i['coordinates']['latitude']
            lon = i['coordinates']['longitude']
            Zip = i['post_code']
            State = ""
            if Country == "US":
                try:
                    Zipp = Zip.replace(",","").split(" ")[1]
                    State = Zip.replace(",","").split(" ")[0]
                    Zip = Zipp
                except:
                    pass
            StoreType = ""
            BussinessName = i['name']
            BrandName = "All Saints"
            Address = Address.replace(City,"")
            Phone = ''.join(re.findall("\d+",i['phone_number']))
            Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
            location = StoreLocation(
                brand_id=None,
                brand_name=BrandName,
                store_name=BussinessName,
                address_1=Address,
                type=StoreType,
                city=City,
                state=State,
                zipcode=Zip,
                country_code=Country,
                latitude=float(lat),
                longitude=float(lon),
                phone_number=Phone,
                secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                raw_address = Rawaddress,
                url=url)
            yield location

@register("https://store-locator-api.allsaints.com/shops")
def seeder(url):
    yield from extractor(url)