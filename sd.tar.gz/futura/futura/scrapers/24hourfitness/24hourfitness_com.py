# encoding: utf-8
import json
import logging

from scrapy.spiders import Spider
from scrapy.http import Request

# Import a StoreLocation data structure to hold our POI data:
from ...types import StoreLocation
# And gather our special support for Scrapy:
from ...support import ScrapySupport

logger = logging.getLogger(__name__)


# Be sure to inherit ScrapySupport as the first mixin:
class TwentyFourHourFitness_US(ScrapySupport, Spider):
    # Specify your start_urls
    start_urls = ['https://www.24hourfitness.com/health_clubs/find-a-gym/']

    def parse(self, response):
        # This is what you're supposed to use instead of `print()`
        # You can see this debug line when you run Futura with `--debug`
        logger.debug('Contacting 24Hour fitness for gyms')
        yield Request(
            url='https://www.24hourfitness.com/ClubInformation/rest/v1/Gyms',
            callback=self.parse_details)

    def parse_details(self, response):
        data = json.loads(response.body_as_unicode())

        for index, clubs_by_group in enumerate(data['groupClubs']):
            logger.debug('{} clubs in group index {}'.format(len(clubs_by_group['clubs']), index))
            for club in clubs_by_group['clubs']:
                location = StoreLocation(
                    brand_id=3717, brand_name='24 Hour Fitness',
                    store_name=club['clubName'],
                    address_1=club['clubAddressStreet'],
                    type=None,
                    city=club['clubAddressCity'],
                    state=club['clubAddressState'],
                    zipcode=club['clubAddressZip'],
                    country_code='US',
                    latitude=float(club['clubAddressLatitude']),
                    longitude=float(club['clubAddressLongitude']),
                    phone_number=club['clubPhoneNumber'],
                    raw_address = club['clubAddressStreet']+club['clubAddressCity']+club['clubAddressState']+club['clubAddressZip'],
                    url=response.url)
                # Just `yield` the StoreLocation. Scrapy will capture it and handle it for
                # you.
                yield location
