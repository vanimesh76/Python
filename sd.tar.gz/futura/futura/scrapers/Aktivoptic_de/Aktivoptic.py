import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("div",{"class":"row store-box"}):
        addressinfo = [x.strip() for x in i.find("div",{"class":"col span3"}).text.replace('\t', '').replace('\r', '').replace('  ', ' ').strip().split('\n')[:-2]]
        print(addressinfo)
        Zip = re.findall("\d{4,5}",addressinfo[0])[0]
        City = addressinfo[0].replace(Zip, '').strip(" ")
        try:
            Address = addressinfo[1]+" "+addressinfo[2]
        except:
            Address = addressinfo[1]
        a = i.find("div",{"class":"col span3"}).find("a")['href']
        lat,lon =re.findall("/@(.*?),14z",str(a))[0].split(",")
        a = i.find("div",{"class":"col span4"})
        BussinessName = [x.strip() for x in i.find("div",{"class":"col span4"}).text.replace('\t', '').replace('\r', '').replace('  ', ' ').strip().split('\n')[:-2]][0]
        Phone = "".join(re.findall("\d+",[x.strip() for x in i.find("div",{"class":"col span4"}).text.replace('\t', '').replace('\r', '').replace('  ', ' ').strip().split('\n')[:-2]][1]))
        StoreType = ""
        State = ""
        BrandId = None
        BrandName = "Aktivoptik"
        Country = "DE"
        string_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        Last_update = datetime.datetime.strptime(string_time, "%Y-%m-%d %H:%M:%S")
        SecondarySIC = ''
        PrimarySIC = ''
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.aktivoptik.de/filialen?utf8=%E2%9C%93&search=")
def seeder(url):
    yield from extractor(url)