import logging
import json
import random
import re
import time
import requests
import datetime
import csv
import ast
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(c,cc):
    # print(payload)
    # payload = ast.literal_eval(payload)
    url = "http://www.thomson.co.uk/destinations/**/shop-finder?instart_disable_injection=true"
    headers = {"Host":"www.thomson.co.uk",
"Connection":"keep-alive",
"Content-Length":"86",
"Pragma":"no-cache",
"Cache-Control":"no-cache",
"Origin":"http://www.thomson.co.uk",
"X-Requested-With":"XMLHttpRequest",
"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
"Content-Type":"application/x-www-form-urlencoded",
"Accept":"*/*",
"Referer":"http://www.thomson.co.uk/destinations/shop-finder",
"Accept-Encoding":"gzip, deflate",
"Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
"Cookie":'CF592628B0A6AA45AA13B98AEC4F3F85.prod-hybp351a=true; Recommendations_ASP_v3=default; v1st=548260D8067FD198; FirstDomain=www.thomson.co.uk; uuid=77632dcb-cc5d-4af0-b13d-a219be3e8c95; ab_201706_r716_appbanner_Live=appbannerB; ab_201609_r916_DealsResultPage=dealsRPB; ab_201612_r916_THresponsivehpV1=THresponsivehpB; ab_201612_r916_ResponsiveSearchPanelv1=MresponsiveSPB; __qca=P0-1477401356-1499339074793; TLTSID=5EAE7F20687F106825E2C82489134DFF; i10c.sid=1500028192494; AMCV_41E27DA552A6473A0A490D4D%40AdobeOrg=283337926%7CMCMID%7C90921153839747211106450240785823325057%7CMCAAMLH-1500632993%7C3%7CMCAAMB-1500632993%7CNRX38WO0n5BH8Th-nqAG_A%7CMCAID%7CNONE; bn_u=6926801027708898893; BN_conditioncode=14.B%26g%26s; i10c_focloir=15:acdeee18ddc3018a1bbdf07deacfd2ca; JSESSIONID_TH=CF592628B0A6AA45AA13B98AEC4F3F85.prod-hybp351a; dtLatC=3; 17895=; mbox=PC#a71726d897a74900842ac7efa5eb2357.28_41#1501482601|check#true#1500273059|session#fc9b90db18694b608513b4a5dbe3565a#1500274859; s_depth=4; s_depth_vis=1; s_cc=true; __utmt_ensGA=1; __utma=67041841.248747972.1499339065.1500037199.1500273001.10; __utmb=67041841.1.10.1500273001; __utmc=67041841; __utmz=67041841.1499339065.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); _4c_=fZFNboMwFISvUr11GozxD2ZbqatUyg0iG9vBCsWIn5Iq4u55hKRSU6kb4Hk%2BxuPxBabKNVCknBAqM0KY4tkGTu67h%2BICXbDL6wsK0DItVeaUVsx4Lp2QrMypZTmVxHtmYAPnm49M8SEEVWTegA12F4%2Fv%2B4dL%2BoTlTKWIle0duMDY1chVw9AWSTJN03ao4mcfm20Zt%2BMpsa4fQqOHEJs%2B6avYvvrQWNehrzYHRN1eH91HNKF2B20GxNFuVSnBLdU6VqPp23hy62S6OPVoUsBb1aHHC1e4GrED2IVmPOPgMSKk3LFSCKUNMZa4VEmtMl06T%2FKcaUmRa5djMvyoY6nrxR%2F7xSKwZLDO67EeAE%2F8VEKGS8uftxLYH1mivGb8B1JL387fdbzFh55TQinP%2BaJjjPUmHll%2BY0xmi034oZ50IQSf5%2FkK; tlmChannel=undefined; tntPQRY=pageUid%3DstoreFinder; dtPC=-; clientipaddr=182.72.210.214; _uetsid=_uet8fa2dc51; flashtalkingad1="GUID=3474B3B03CFDFA|segment=(hu2-t:34850630)"; s_nr=1500273007160-Repeat; s_lv=1500273007162; s_lv_s=Less%20than%201%20day; gpv_pn=www.thomson.co.uk%2Fdestinations%2Fshop-finder; gpv_pn2=storeFinder; dtCookie=7549D0359D65FE217714FD68BE437AA7|VGhvbXNvblBhY2thZ2VzfDE'}
    payload = {"lat":"51.5073509","lng":"-0.12775829999998223","CSRFToken":"a796317a-5d4d-4be4-afcf-3d9619875f9a"}
    # payload = {'lat':str(c), 'lng':str(cc), 'CSRFToken': 'a796317a-5d4d-4be4-afcf-3d9619875f9a'}
    # payload = ast.literal_eval(payload)
    data = yield requests.post(url,headers = headers, data = payload)
    a = data.json()
    for i in a:
        City = i['city']
        Country = "UK"
        lat = i['latitude']
        lon = i['longitude']
        BussinessName = i['name']
        Phone = i['phone']
        Address = i['street']
        State = i['town']
        Zip = i['zip']
        BrandName = "Thompson"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location


@register('http://www.whistles.com/our-stores/our-stores.html')
def seeder(url):
    f = open("/home/skymap/PycharmProjects/Virtual env/Thomson1.csv","r")
    for payload in f:
        c = re.findall("lat\'\: \'(.*?)\'",payload)[0]
        cc = re.findall("lng\'\: \'(.*?)\'",payload)[0]
        yield from extractor(c,cc)
    # res = yield requests.get(url)
    # soup = BeautifulSoup(res.text.encode('utf-8'))
    # lat_long_link = soup.find('div',{'class':'col-8'}).find('ul').find_all('li')
    # mycsv = csv.writer(open('Thomson1.csv', 'w'))
    # for lat_long in lat_long_link:
    #   lat_long_links = lat_long.find('a').get('href')
    #   res2 = yield requests.get(lat_long_links)
    #   soup2 = BeautifulSoup(res2.text.encode('utf-8'))
    #   if 'next' in  str(soup2):
    #       number_of_pages = soup2.find_all('ul', {'class':'list-horizontal'})[-2].find_all('li')[-2].text.encode('utf-8')
    #       for page in range(1, int(number_of_pages)+1):
    #           pagelink = lat_long_links.replace('.html',  '-' + str(page) + '.html') 
    #           time.sleep(random.randint(1, 4))
    #           res3 = yield requests.get(pagelink)
    #           soup3 = BeautifulSoup(res3.text.encode('utf-8'))
    #           lat_long_list = soup3.find('table').find_all('tr')
                
    #           for lat_long_main in lat_long_list:
    #               if '<td><a href' in str(lat_long_main):     
    #                   Latitude = lat_long_main.find('td').find_next('td').text.encode('utf-8')
    #                   # print(Latitude)   
    #                   Longitude = lat_long_main.find('td').find_next('td').find_next('td').text.encode('utf-8')
    #                   # new_url = ''.join(['https://www.att.com/apis/maps/v2/locator/search/viewport.json?poi_types=pos&sw=', float(Latitude)),',', float(Longitude)),'&ne=',float(Latitude)+1),',', float(Longitude)+1),'&services=&apikey=457170cad6f312786d91748811795ab4b68b07de&jsonp=jQuery152008145695171644252_1485269245507&_=1485269361682'])
    #                   payload = {"lat":str(float(Latitude)),"lng":str(float(Longitude)),"CSRFToken":"17069528-73f3-4d00-b75f-00eb98b7b3d8"}
    #                   mycsv.writerows([[str(payload)]])
    #                   # yield from extractor(payload)
    #                   # print new_url
    #   else:
    #       lat_long_list = soup2.find('table').find_all('tr')
            
    #       for lat_long_main in lat_long_list:
    #           if '<td><a href' in str(lat_long_main):     
    #               Latitude = lat_long_main.find('td').find_next('td').text.encode('utf-8')            
    #               Longitude = lat_long_main.find('td').find_next('td').find_next('td').text.encode('utf-8')
    #               payload = {"lat":str(float(Latitude)),"lng":str(float(Longitude)),"CSRFToken":"17069528-73f3-4d00-b75f-00eb98b7b3d8"}
    #               mycsv.writerows([[str(payload)]])
    #               # print(payload)
    #               # yield from extractor(payload)