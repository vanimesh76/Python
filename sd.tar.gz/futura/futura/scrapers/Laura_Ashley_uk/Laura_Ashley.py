import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script"):
        if "var markers" in i.text:
            a = json.loads(re.findall("var markers \= (.*?)\,\]\;",i.text.replace("\n","").replace("  ",""))[0]+"]")
    for i in a:
        b = len(i['store_address'].split(","))
        if b==3:
            Zip = i['store_address'].split(",")[-1]
            City = i['store_address'].split(",")[-2]
            Address = i['store_address'].split(",")[0]
        elif b==5:
            Zip = i['store_address'].split(",")[-2]
            State = i['store_address'].split(",")[-3]
            City = i['store_address'].split(",")[-4]
            Address = i['store_address'].split(",")[0]
        elif b==6:
            Zip = i['store_address'].split(",")[-2]
            State = i['store_address'].split(",")[-3]
            City = i['store_address'].split(",")[-4]
            Address = i['store_address'].split(",")[-6]+" "+i['store_address'].split(",")[-5]
        elif b==7:
            Zip = i['store_address'].split(",")[-2]
            State = i['store_address'].split(",")[-3]
            City = i['store_address'].split(",")[-4]
            Address = i['store_address'].split(",")[-7]+" "+i['store_address'].split(",")[-6]+" "+i['store_address'].split(",")[-5]
        BussinessName = ""
        Country = i['store_address'].split(",")[-1]
        if "kingdom" in Country.lower():
            Country = "UK"
        elif "nort" in Country.lower():
            Country = "NI"
        else:
            Country = "IR"
        lat = i['store_lat']
        lon = i['store_long']
        Phone= ''.join(re.findall("\d+",i['store_phone']))
        BrandName = "Laura Ashleyy"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=None,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("http://stores.lauraashley.com/")
def seeder(url):
    yield from extractor(url)