# coding:utf-8
import logging
import json
import random
import re
import time
import requests
import sys
import pdb
import datetime
logger = logging.getLogger(__name__)
import csv
import itertools
from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation
def extractor(url):
    headers = {"Accept":"application/json, text/plain, */*",
                "Accept-Encoding":"gzip, deflate, br",
                "Accept-Language":"en-GB,en-US;q=0.8,en;q=0.6",
                "Cache-Control":"no-cache",
                "Connection":"keep-alive",
                "Content-Length":"41",
                "Content-Type":"application/json;charset=UTF-8",
                # "Cookie":"AMCVS_3D6068F454E7858C0A4C98A6%40AdobeOrg=1; lightBox=lightBoxCookie; AMCV_3D6068F454E7858C0A4C98A6%40AdobeOrg=1099438348%7CMCIDTS%7C17360%7CMCMID%7C14179608205039263211963132052678061307%7CMCAAMLH-1500445715%7C7%7CMCAAMB-1500445715%7CNRX38WO0n5BH8Th-nqAG_A%7CMCOPTOUT-1499848115s%7CNONE%7CMCAID%7CNONE%7CMCSYNCSOP%7C411-17367%7CvVersion%7C2.1.0; JSESSIONID=HiA1fC7DqoaCk4pn4vymQiUBpa__iobSbL1MRjTqOVgXdHFw5NaG!-563449139; ATG_SESSION_ID=HiA1fC7DqoaCk4pn4vymQiUBpa__iobSbL1MRjTqOVgXdHFw5NaG!-563449139!1499840917187; WLS_ROUTE=.www.h; gig_hasGmid=ver2; s_sq=%5B%5BB%5D%5D; _uetsid=_uetcbaca7a4; xyz_cr_356_et_100==&cr=356&et=100&ap=; rr_rcs=eF4FwbsNgDAMBcAmFbs8KbaeHXsD1sgHJAo6YH7uynZ_z7WqSGsQZgZrWqglQgEp79zZx0HnhIUp6Crw1QMjrFHlXJ79B3Q5EXs; RT="sl=2&ss=1499840908585&tt=24212&obo=0&bcn=%2F%2F36eb557d.mpstat.us%2F&sh=1499840961894%3D2%3A0%3A24212%2C1499840929943%3D1%3A0%3A19739&dm=michaelkors.ca&si=9a67346c-2451-447b-819c-87cb33fe4ce4&ld=1499840961894&nu=https%3A%2F%2Fwww.michaelkors.ca%2Fstores%2F&cl=1499840954605&r=https%3A%2F%2Fwww.michaelkors.ca%2Fstores%2F&ul=1499840976236&hd=1499840977532"; _gat=1; _ga=GA1.2.1498017152.1499840914; _gid=GA1.2.679879773.1499840914; mt.v=2.730583627.1499840913607; _gat_a4783b567b23728578c6a7d0a717c392=1; userPrefLanguage=en_CA; cookieLanguage=en_CA; gpv_pn=Store%20Locator; gpv_purl=%2Fstores%2F; gpv_ptyp=Store%20Locator; tp=960; s_ppv=Store%2520Locator%2C66%2C66%2C629; s_nr=1499840983852-New; s_vs=1; productMerchNum=3; dtm_pageviews=3; s_cc=true",
                "Host":"www.michaelkors.ca",
                "Origin":"https://www.michaelkors.ca",
                "Pragma":"no-cache",
                "Referer":"https://www.michaelkors.ca/stores/",
                "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"
                }
    payload = {"country":"Canada","state":"","city":""}
    res = yield requests.post(url,headers=headers,data=json.dumps(payload))
    soup = res.json()
    for store in soup['stores']:
        BusinessName = store['displayName']
        StoreType = store['type']
        Address1 = store['address']['addressLine1'].replace(',',' ').replace('#',' ').replace('  ',' ')
        City = store['address']['city']['name']
        State = store['address']['state']['name']
        try:
            ZIP = store['address']['zipcode']
        except:
            ZIP = ''
        phone = ''.join(re.findall(r'\d+',str(store['address']['phone'])))[:10]
        Latitude = store['geoLocation']['latitude']
        Longitude = store['geoLocation']['longitude']
        BrandName = 'Michael Kors'
        Rawaddress = ', '.join(filter(None, [BrandName,Address1, City,State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BrandName,
            address_1=Address1,
            type=None,
            city=City,
            state=State,
            zipcode=ZIP,
            country_code='US',
            latitude=float(Latitude),
            longitude=float(Longitude),
            raw_address =Rawaddress,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            phone_number=phone,
            url=url)
        yield location


@register('https://www.warbyparker.com/retail')
def seeder(url):
    yield from extractor('https://www.michaelkors.ca/server/stores')
        
   
           
    
   