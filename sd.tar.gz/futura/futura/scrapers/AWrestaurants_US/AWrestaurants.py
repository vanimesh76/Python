import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    print (url)
    data = yield requests.get(url)
    c = 0
    b = 1
    soup = BeautifulSoup(data.text,"lxml")
    a = re.findall("var positions = \[(.*?)\]\;",str(soup))[0].split(",")
    for i in soup.find_all("li",{"class":"location-entity"}):
        Address = i.find("div",{"class":"location-address inline"}).text
        City = i.find("span",{"class":"location-city inline"}).text.split(",")[0]
        State =  i.find("span",{"class":"location-city inline"}).text.split(",")[1].strip(" ").split(" ")[0]
        Zip = i.find("span",{"class":"location-city inline"}).text.split(",")[1].strip(" ").split(" ")[1]
        Phone = ''.join(re.findall("\d+",i.find("span",{"class":"location-phone inline"}).text))
        BrandId = None
        BrandName = "awrestaurant"
        BussinessName = "awrestaurant"
        Country = "US"
        StoreType = ""
        try:
            lat = a[c]
            lon = a[b]
        except:
            lat = ""
            lon = ""
            pass
        c+=2
        b+=2
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://www.porsche.com/all/dealer2/GetLocationsWebService.asmx/GetLocationsInStateSpecialJS?market=uk&siteId=uk&language=none&state=&_locationType=Search.LocationTypes.Dealer&searchMode=proximity&searchKey=51.5073509%7C-0.12775829999998223&address=london&maxproximity=10000&maxnumtries=&maxresults=1000")
def seeder(url):
    # linkss = []
    f = open("/home/skymap/Downloads/Downloads/US_ZIP.csv",'r')
    for i in f:
        i = str(i).strip("\n")
        # linkss.append("http://www.awrestaurants.com/locations?zipcode="+str(i).zfill(5))
        yield from extractor("http://www.awrestaurants.com/locations?zipcode="+str(i).zfill(5))