import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    b = re.findall("markersCoords.push\((.*?)\\n",data.text)

    a = soup.find("div",{"class":"addresses"})
    latt =re.findall("lat\: (.*?)\,",b[0])
    lonn =re.findall("lng\: (.*?)\,",b[0])
    c = 0
    for i in a.find_all("li"):
        lat = latt[c]
        lon =lonn[c]
        c+=1
        BussinessName = i.find("span",{"class":"name"}).text
        try:
            Address = i.find("span",{"class":"address"}).text+" "+i.find("span",{"class":"address2"}).text
        except:
            Address = i.find("span",{"class":"address"}).text
        City = i.find("span",{"class":"city"}).text
        try:
            State = i.find("span",{"class":"prov_state"}).text
        except:
            State = ""
        try:
            Zip = i.find("span",{"class":"postal_zip"}).text
        except:
            Zip = ""
        Country = i.find("span",{"class":"country"}).text
        Phone = ""
        if "kingdom" in Country.lower():
          Country = "UK"
        else:
          Country = "IR"
        StoreType = ""
        BrandName = "Skinny Dip"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName.strip(" "),
            address_1=Address.strip(" "),
            type=StoreType,
            city=City.strip(" "),
            state=State.strip(" "),
            zipcode=Zip.strip(" "),
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("https://www.skinnydiplondon.com/apps/store-locator/")
def seeder(url):
    yield from extractor(url)