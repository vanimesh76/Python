import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    a = data.json()
    for i in a:
        try:
            b = len(a[i]['AddressLine'].split(","))
            if b==5:
                City = a[i]['AddressLine'].split(",")[-1]
                Address = a[i]['AddressLine'].split(",")[-5]+" "+a[i]['AddressLine'].split(",")[-4]+" "+a[i]['AddressLine'].split(",")[-3]+" "+a[i]['AddressLine'].split(",")[-2]
            elif b==4:
                City = a[i]['AddressLine'].split(",")[-1]
                Address = a[i]['AddressLine'].split(",")[0]+" "+a[i]['AddressLine'].split(",")[1]+" "+a[i]['AddressLine'].split(",")[2]
            elif b==3:
                City = a[i]['AddressLine'].split(",")[-1]
                Address = a[i]['AddressLine'].split(",")[0]+" "+a[i]['AddressLine'].split(",")[1]
            elif b==2:
                City = a[i]['AddressLine'].split(",")[-1]
                Address = a[i]['AddressLine'].split(",")[0]
        except:
            Address = ""
        lat = a[i]['Latitude']
        lon = a[i]['Longitude']
        try:
            BussinessName = a[i]['branch_name']
        except:
            BussinessName = ""
        try:
            StoreType = a[i]['feature-0_SAS']['description']
        except:
            try:
                StoreType = a[i]['feature-0_SIS']['description']
            except:
                StoreType = ""
        try:
            Zip = a[i]['postcode']
        except:
            Zip =""
        State = ""
        BrandId = None
        Phone = ''.join(re.findall("\d+",a[i]['telephone']))
        BrandName = "Carphone Warehouse"
        Country = "UK"
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=BrandId,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address.strip(" "),
            type=StoreType,
            city=City.strip(" "),
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("https://www.carphonewarehouse.com/services/storedata?filter=&count=100000&lat=51.5073509&lng=-0.12775829999998223")
def seeder(url):
    yield from extractor(url)