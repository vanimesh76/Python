import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data= yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    latt = []
    lonn = []
    c = 0
    for i in re.findall("LatLng\((.*?)\)",data.text)[1:]:
        latt.append(i.split(",")[0])
        lonn.append(i.split(",")[1].strip(" "))
    for i in soup.find_all("div",{"class":"locationWrapper"}):
        a = re.findall("daddr\=(.*?)$",i.find("a")['href'].replace("%2c",",").replace("+"," "))[0].split(",")
        Zip = re.findall("\w+\d+ \d\w+|\w+\d \d\w+",a[-1])[0]
        State = a[-1].replace(Zip,"")
        City = a[-2]
        Address = ' '.join(a[:-2])
        lat = latt[c]
        lon = lonn[c]
        Phone = ''.join(re.findall("Phone\: (.*?)\<",str(i))).replace(" ","")
        c +=1
        BrandName = "Mr Pretzels"
        BussinessName = "Mr Pretzels"
        Country = "UK"
        StoreType = ""
        Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
        location = StoreLocation(
            brand_id=None,
            brand_name=BrandName,
            store_name=BussinessName,
            address_1=Address,
            type=StoreType,
            city=City,
            state=State,
            zipcode=Zip,
            country_code=Country,
            latitude=float(lat),
            longitude=float(lon),
            phone_number=Phone,
            secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
            raw_address = Rawaddress,
            url=url)
        yield location

@register("http://mrpretzels.co.uk/store-locator.aspx")
def seeder(url):
    yield from extractor(url)