import logging
import json
import random
import re
import time
import requests
import datetime

logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
    data = yield requests.get(url)
    soup = BeautifulSoup(data.text,"lxml")
    for i in soup.find_all("script",{"type":"text/javascript"}):
        if "var markerClusterer" in i.text:
            c = re.findall("parseJSON\(\'(.*?)\'\)\)\;",i.text)
    for i in c:
        for j in json.loads(i):
            if "germany" in j['Country']['Name'].lower():
                a = len(j['Address'].split("<br/>"))
                if a ==3:
                    Zip = re.findall("\d{5}",j['Address'])[0]
                    Address = ' '.join(j['Address'].replace(Zip,"").split("<br/>")[:2])
                elif a==4:
                    Zip = re.findall("\d{5}",j['Address'])[0]
                    Address = ' '.join(j['Address'].replace(Zip,"").split("<br/>")[:2])
                Country = "DE"
                lat = j['Latitude']
                lon = j['Longitude']
                City= j['Name']
                BrandId = None
                State = ""
                Phone = ""
                BrandName = "Primark"
                BussinessName = "Primark"
                Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
                string_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                location = StoreLocation(
                    brand_id=BrandId,
                    brand_name=BrandName,
                    store_name=BussinessName,
                    address_1=Address,
                    type=None,
                    city=City,
                    state=State,
                    zipcode=Zip,
                    country_code=Country,
                    latitude=float(lat),
                    longitude=float(lon),
                    phone_number=Phone,
                    updated_date = datetime.datetime.strptime(string_time, "%Y-%m-%d %H:%M:%S"),
                    secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                    raw_address = Rawaddress,
                    url=url)
                yield location
    # except:
    #     pass


# This registers the seeder(url) to be:
@register("https://www.primark.com/en/our-stores")
def seeder(url):
    yield from extractor(url)