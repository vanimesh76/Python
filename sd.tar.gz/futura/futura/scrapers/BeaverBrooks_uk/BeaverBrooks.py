import logging
import json
import random
import re
import time
import requests
import datetime
logger = logging.getLogger(__name__)

from bs4 import BeautifulSoup

# This allows for this scraper to be accessible from Futura:
from ...support.bs4 import register
# This is where we'll store our Location Data:
from ...types import StoreLocation


def extractor(url):
        data= yield requests.get(url)
        soup = BeautifulSoup(data.text,"lxml")
        for i in soup.find_all("li",{"class":"store-location"}):
            City = i.find("h2",{"class":"store-location-title houshka"}).text.replace("\n","").replace("\t","")
            Address = ''.join(i.find("p",{"class":"store-location-address"}).text.split(",")[:-1]).replace("\n","")
            Zip = i.find("p",{"class":"store-location-address"}).text.split(",")[-1].replace("\n","")
            Phone = ''.join(re.findall("\d+",i.find("p",{"class":"store-location-phone"}).text))
            try:
                lat = i.find("div",{"id":"closest-location-map"})['data-lat']
                lon = i.find("div",{"id":"closest-location-map"})['data-long']
            except:
                lat = i['data-lat']
                lon = i['data-long']
                BrandName = "Beaverbrooks"
                Country = "UK"
                State = ""
                BussinessName = ""
                StoreType = ""
                Rawaddress = ', '.join(filter(None, [BrandName, Address, City, State]))
                location = StoreLocation(
                    brand_id=None,
                    brand_name=BrandName,
                    store_name=BussinessName,
                    address_1=Address,
                    type=StoreType,
                    city=City,
                    state="",
                    zipcode=Zip,
                    country_code=Country,
                    latitude=float(lat),
                    longitude=float(lon),
                    phone_number=Phone,
                    secondary_sic = datetime.datetime.now().strftime("%Y-%m"),
                    raw_address = Rawaddress,
                    url=url)
                yield location

# This registers the seeder(url) to be:
@register("https://www.beaverbrooks.co.uk/stores")
def seeder(url):
    yield from extractor(url)