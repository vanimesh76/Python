from .atomic import Table, Column

import datetime


def validate_country_code(code):
    if len(code) != 2:
        raise ValueError('must be a 2-character country code')
    return code.upper()


class StoreLocation(Table):
    '''
    Define a StoreLocation that we can store into our database.

    It provides a dict-like interface, prevents illegal data types, supports defaults and column
    NULLability and can be dumped into MySQL `.execute(...)` function via its `to_mysql` function.

    Examples:

    >>> wendys = StoreLocation(
        6, "Wendy's", "Wendy's at 9192 Glades Rd # A", "9192 Glades Rd # A",
        None, "Boca Raton", "FL", "33434")

    '''
    Column[str]('brand_name')
    Column[str]('store_name')
    Column[str]('type', nullable=True)
    Column[str]('address_1')
    Column[str]('city', nullable=True)
    Column[str]('state', nullable=True)
    Column[str]('zipcode', nullable=True)
    # Column[str]('country_code', validator=validate_country_code)
    Column[str]('country_code', nullable=True)

    Column[str]('phone_number', nullable=True)
    Column[str]('primary_sic', nullable=True)
    Column[str]('secondary_sic', nullable=True)
    Column[float]('latitude', nullable=True)
    Column[float]('longitude', nullable=True)
    Column[int]('brand_id', nullable=True)
    Column[str]('raw_address', nullable=True)
    # Column[str]('address_2', nullable=True)
    # Column[bool]('del', default=False)
    Column[datetime.datetime]('updated_date', datetime.datetime.utcnow)
    Column[str]('url')

    # Aliases allow a column that has one name to be addressed as another.
    #   This alias will allow one to access the country_code property by `country` and
    #   even set it via the constructor via a keyword only argument.
    ALIASES = {
        'country_code': ['country'],
        'latitude': ['lat'],
        'longitude': ['lng'],
        'address_1': ['address1']
    }
