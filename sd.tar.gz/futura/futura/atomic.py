from scrapy.item import BaseItem
import six
from abc import ABCMeta, abstractmethod
import inspect
import collections
import functools
import sys
import datetime
import csv

from dateutil.parser import parse as parse_datetime
NoneType = type(None)
Scrapers = {}


class FrozenMapping(collections.Mapping):

    __slots__ = ('_initialized', '_data')

    def __init__(self, *iterables, **kwargs):
        self._data = {}
        super(FrozenMapping, self).__init__()
        for item in iterables:
            self._data.update(item)
        self._data.update(kwargs)
        self._initialized = True

    def __getitem__(self, key):
        return self._data[key]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

try:
    FrozenMapping.viewkeys
except AttributeError:
    FrozenMapping.viewkeys = lambda self: self._data.viewkeys()


def make_new(func, binding):
    '''
    Force a binding to __new__ that is cross compatible with 2/3.
    '''
    @functools.wraps(func)
    def wrapped(cls, *args, **kwargs):
        return func(cls, binding, *args, **kwargs)
    return wrapped


class SerializeError(Exception):
    def __init__(self, message, *args):
        assert args and all(isinstance(x, Exception) for x in args)

        self.msg = message
        self.errors = args
        super(SerializeError, self).__init__(message, *args)

    def __repr__(self):
        return '{.__class__.__name__}({}, {})'.format(
            self, self.msg, ', '.join([str(x) for x in self.errors]))

HUMAN_MAPPINGS = {
    int: 'Integer',
    str: 'String',
    bytes: 'Binary String'
}
if six.PY2:
    HUMAN_MAPPINGS[str] = 'Binary string'
    HUMAN_MAPPINGS[unicode] = 'Unicode String'
    HUMAN_MAPPINGS[long] = 'Long Integer'


def type_to_human(type_cls):
    return HUMAN_MAPPINGS.get(type_cls, type_cls.__name__.capitalize())


def types_to_names(type_vector):
    if len(type_vector) == 1:
        return 'a {}'.format(type_to_human(type_vector[0]))
    return 'a {} or {}'.format(
        ', '.join(type_to_human(x) for x in type_vector[1:]),
        type_to_human(type_vector[0]))


def find_docstring(new_cls, name):
    for cls in inspect.getmro(new_cls):
        if not hasattr(cls, name):
            continue
        value = getattr(cls, name)
        if hasattr(value, '__doc__') and value.__doc__ is not None:
            yield value.__doc__


def make_getter_func(field_name):
    def func(self):
        return getattr(self, '_{}'.format(field_name))
    func.__name__ = field_name
    return func


def make_setter_func(field):
    convertable_types = []
    if field.conversion_mappings:
        for bloc in field.conversion_mappings:
            if isinstance(bloc, type):
                bloc = (bloc,)
            convertable_types.extend(bloc)
    convertable_types = tuple(convertable_types)

    def func(self, value):
        if field.allows_nulls and value is None:
            setattr(self, '_{}'.format(field.column_name), value)
            return
        for type_cls in convertable_types:
            if isinstance(value, type_cls):
                value = field.conversion_mappings[type_cls](value)
                break
        if not isinstance(value, field.data_types_allowed):
            raise TypeError('{}={!r} ({}) must be {}'.format(
                field.column_name, value, type(value).__name__,
                types_to_names(field.data_types_allowed)))
        if field.validator:
            try:
                value = field.validator(value)
            except Exception as e:
                exc_type, exc, stack = sys.exc_info()
                new_exc = exc_type(
                    'Validation of {!r} failed as the value ({!r}) {}'.format(
                        field.column_name, value, str(e)))
                six.reraise(exc_type, new_exc, stack)
        setattr(self, '_{}'.format(field.column_name), value)
    func.__name__ = field.column_name
    return func

RESERVED_KEYWORDS = {
    'del': 'deleted'
}


class SerializeableMeta(ABCMeta):
    def __new__(cls, class_name, bases, attrs):

        if 'FIELDS' not in attrs:
            raise TypeError('{} requires FIELDS be defined'.format(class_name))
        fields = []
        if 'ALIASES' not in attrs:
            attrs['ALIASES'] = {}
        assert isinstance(attrs['ALIASES'], dict), \
            'Aliases must be a dict like or not declared at all'
        aliases = attrs['ALIASES']
        defaults = {}

        attrs['_orig_fields'] = tuple(sorted(attrs['FIELDS'], key=lambda obj: obj._global_index))
        for field in attrs['_orig_fields']:
            field_type = field.data_types_allowed
            field_name = field.column_name
            if field_name in RESERVED_KEYWORDS:
                if field_name not in aliases:
                    aliases[field_name] = set()

                if not isinstance(aliases[field_name], set):
                    if isinstance(aliases[field_name], str):
                        aliases[field_name] = (aliases[field_name],)
                    aliases[field_name] = set(aliases[field_name])

                # Example:
                #   del -> deleted
                #   This the means the constructor must accept del=1 if fed via **kwargs
                #   And the serialize method -> del
                #   but the iter method shall return deleted
                aliases[field_name].add(RESERVED_KEYWORDS[field_name])

            if field.allows_nulls:
                field_type = field_type + (NoneType,)

            if field.default is not None:
                default = field.default
                if not callable(field.default):
                    default = (lambda obj: lambda: obj)(field.default)
                defaults[field_name] = default

            attrs['_{}'.format(field_name)] = None

            fields.append((field_name, field_type))

        attrs['FIELDS'] = tuple(fields)
        attrs['_raw_fields'] = frozenset(x[0] for x in fields)
        attrs['_fields'] = tuple(field_name for field_name, _ in fields)
        attrs['_defaults'] = FrozenMapping(defaults)

        inverted_aliases = {}
        foreign_aliases = set()
        for base in bases:
            keys = dir(base)
            if 'ALIASES' in keys:
                for key in base.ALIASES:
                    if key not in attrs['ALIASES']:
                        attrs['ALIASES'][key] = base.ALIASES[key]
                        foreign_aliases.add(key)

        for true_name, aliased_names in six.iteritems(attrs['ALIASES']):
            for aliased_name in aliased_names:
                inverted_aliases[aliased_name] = true_name

        attrs['_inverted_aliases'] = FrozenMapping(inverted_aliases)
        attrs['ALIASES'] = FrozenMapping(attrs['ALIASES'])

        for field in attrs['_orig_fields']:
            attrs[field.column_name] = property(
                make_getter_func(field.column_name), make_setter_func(field))

        for true_name in six.viewkeys(attrs['ALIASES']) - foreign_aliases:
            for alias in attrs['ALIASES'][true_name]:
                attrs[alias] = attrs[true_name]
        try:
            new_cls = super(SerializeableMeta, cls).__new__(cls, class_name, bases, attrs)
        except Exception as e:
            six.raise_from(ValueError('Unable to synthesize {}'.format(class_name)), e)

        for name, item in six.iteritems(attrs):
            if callable(item) and hasattr(item, '__doc__') and item.__doc__ is None:
                docstrings = [x for x in find_docstring(new_cls, name)]
                if docstrings:
                    item.__doc__ = docstrings[0]
        return new_cls


class Serializable(six.with_metaclass(SerializeableMeta, BaseItem)):
    FIELDS = ()

    def __init__(self, *args, **kwargs):
        self._index = None
        if 'index' in kwargs:
            self._index = kwargs.pop('index')
            assert isinstance(self._index, (int, NoneType))
        data = {}
        for (index, arg), (field_name, _) in zip(enumerate(args), self.FIELDS):
            if field_name in kwargs:
                raise IndexError(
                    'Argument at {} should be for {}, but {} is defined in the kwargs!'.format(
                        index, field_name, field_name))
            data[field_name] = arg
        extra_keys = six.viewkeys(kwargs) - six.viewkeys(data)
        for key in extra_keys:
            if key not in self._raw_fields and key not in self._inverted_aliases:
                raise KeyError('{!r} is not recognized!'.format(key))
            data[key] = kwargs[key]
        for key, value in six.iteritems(self._defaults):
            setattr(self, '_%s' % key, value())
        self.update(data)

    def __repr__(self):
        return '{}({})'.format(
            self.__class__.__name__, ', '.join('{}={!r}'.format(key, value) for key, value in self))

    def __iter__(self):
        for key in self._fields:
            yield key, self[key]

    def __getitem__(self, key):
        if key not in self._raw_fields:
            raise KeyError(key)
        return getattr(self, key)

    def __setitem__(self, key, value):
        if key not in self._raw_fields:
            raise KeyError(key)
        setattr(self, key, value)

    def update(self, iterable):
        for key, value in six.iteritems(iterable):
            setattr(self, key, value)

    def bind_index(self, index):
        return self.__class__(index=index, **self.serialize())

    def fields(self):
        if self._index is None:
            return self._fields
        return tuple('{}_{}'.format(key, self._index) for key in self._fields)

    @property
    def key_mapping(self):
        return {
            from_field: to_field for from_field, to_field in zip(self._fields, self.fields())
        }

    def serialize(self):
        data = {}
        errors = []
        for field in self.FIELDS:
            field_name, field_types = field
            data[field_name] = getattr(self, field_name)
            if not isinstance(data[field_name], field_types):
                errors.append(ValueError(
                    '{} is not {}'.format(field_name, types_to_names(field_types))))
            if self._index is not None:
                data['{}_{}'.format(field_name, self._index)] = data.pop(field_name)
        if errors:
            raise SerializeError('Unable to serialize {}'.format(self.__class__.__name__), *errors)
        return data

    def to_array(self):
        results = []
        for field in self._orig_fields:
            results.append(self[field.column_name])
        return results

    def to_csv(self, fh, write_header=False):
        writer = csv.writer(fh, quotechar='"', quoting=csv.QUOTE_NONNUMERIC)
        if write_header:
            fh.write('# ')
            writer.writerow([x.column_name for x in self._orig_fields])
        writer.writerow(self.to_array())

    def to_mysql(self):
        return self.serialize()

    def to_json(self):
        data = self.serialize()
        for key, value in six.iteritems(data):
            if isinstance(value, datetime.date):
                data[key] = value.isoformat()
        return data


class Table(Serializable):
    FIELDS = ()

    def insert(self, connection):
        pass


class ColumnMeta(type):
    __shared_config__ = {
        'ordering': 0
    }
    default_conversions = {}

    def __init__(self, name, bases, namespace):
        super(ColumnMeta, self).__init__(name, bases, namespace)
        self.specialized_types = {}

    def _register_index(self, instance):
        instance._global_index = self.__shared_config__['ordering']
        self.__shared_config__['ordering'] += 1

    def __getitem__(self, data_types_allowed):
        assert isinstance(self.data_types_allowed, property), \
            '{} is already specialized'.format(self)
        if not isinstance(data_types_allowed, collections.Iterable):
            data_types_allowed = (data_types_allowed,)
        assert all(isinstance(item, type) for item in data_types_allowed), \
            'data_types ({!r}) must be a vector of types!'.format(
                data_types_allowed)
        try:
            return self.specialized_types[data_types_allowed]
        except KeyError:
            # Silently swap out bytes with unicode for Python 2 (only unicode)
            if six.PY2 and data_types_allowed == (str,):
                data_types_allowed = (unicode,)

            try:
                # Python 3
                wrapped_new = functools.partialmethod(self.__new__, data_types_allowed)
            except AttributeError:
                # Python 2
                wrapped_new = make_new(self.__new__, data_types_allowed)
            new_cls = type('{}[{}]'.format(self.__name__, data_types_allowed), (self,), {
                    '__new__': wrapped_new
                })
            self.specialized_types[data_types_allowed] = new_cls
            return new_cls

    def register_default_conversion(self, from_types, data_types, func):
        if not isinstance(data_types, tuple):
            data_types = (data_types,)
        if data_types not in self.default_conversions:
            self.default_conversions[data_types] = {
                from_types: func
            }
            return
        self.default_conversions[data_types][from_types] = func


USE_DEFAULT = object()
BUILTIN_SYMBOLS = \
    frozenset([x for x in dir(__builtins__) if not callable(getattr(__builtins__, x)) and
               not x.startswith('_')])
if six.PY2:
    IMMUTABLE_PRIMITIVES = (unicode, str, long, int)
else:
    IMMUTABLE_PRIMITIVES = (str, int, bytes,)


class Column(six.with_metaclass(
    ColumnMeta,
    collections.namedtuple(
        'Column',
        ['data_types_allowed', 'column_name', 'default', 'allows_nulls', 'conversion_mappings',
         'validator']))):
    _global_index = None

    def __new__(cls,
                data_types_allowed, column_name, default=None, nullable=False,
                conversion_mappings=USE_DEFAULT, validator=None):
        if conversion_mappings is USE_DEFAULT:
            if data_types_allowed in cls.default_conversions:
                conversion_mappings = cls.default_conversions[data_types_allowed]
            else:
                conversion_mappings = None

        if default is not None and not callable(default) and default not in BUILTIN_SYMBOLS \
                and not isinstance(default, IMMUTABLE_PRIMITIVES):
            raise ValueError(
                'Specifying a default for {} requires that it be a function that '
                'returns the default upon being called'.format(column_name))

        if validator is not None and not callable(validator):
            raise TypeError(
                'Validator for {} must be a callable function or None'.format(column_name))

        depth = 0
        frame = inspect.currentframe().f_back
        while depth < 1:
            try:
                frame = frame.f_back
                if frame is None:
                    break
            except Exception:
                break
            else:
                depth += 1
                if six.PY2 and all(x in frame.f_locals for x in ('__module__', '__doc__')):
                    break
                if '__qualname__' in frame.f_locals:
                    break
        else:
            frame = None
            raise SyntaxError('Column defined not inside a class!')

        if not isinstance(data_types_allowed, collections.Iterable):
            data_types_allowed = (data_types_allowed,)
        assert all(isinstance(item, type) for item in data_types_allowed), \
            '[{}] data_types ({!r}) must be a vector of types!'.format(
                column_name, data_types_allowed)
        assert isinstance(column_name, str) and column_name, \
            'Column name must be a string and non-empty'

        instance = super(Column, cls).__new__(
            cls, data_types_allowed, column_name, default,
            bool(nullable), conversion_mappings, validator)
        if 'FIELDS' not in frame.f_locals:
            frame.f_locals['FIELDS'] = []
        frame.f_locals['FIELDS'].append(instance)
        cls._register_index(instance)
        return instance

Column.register_default_conversion(NoneType, bool, bool)
if six.PY2:
    Column.register_default_conversion(str, unicode, lambda obj: obj.decode('utf8'))
    Column.register_default_conversion((str, unicode), datetime.datetime, parse_datetime)
    Column.register_default_conversion((str, unicode), datetime.date, lambda obj: parse_datetime(obj).date())
else:
    Column.register_default_conversion(bytes, str, lambda obj: obj.decode('utf8'))
    Column.register_default_conversion((str, bytes), datetime.datetime, parse_datetime)
    Column.register_default_conversion((str, bytes), datetime.date, lambda obj: parse_datetime(obj).date())
    Column.register_default_conversion(datetime.datetime, datetime.date, lambda obj: obj.date())
    Column.register_default_conversion(
        datetime.date, datetime.datetime, lambda obj: datetime.datetime(obj.year, obj.month, obj.day))
    Column.register_default_conversion(int, float, lambda obj: float(obj))


class IScraper(six.with_metaclass(ABCMeta, object)):
    @abstractmethod
    def run(self):
        pass


# class ScraperMeta(ABCMeta):
#     def __new__(cls, class_name, bases, attrs):
#         pass


# class IScraper(six.with_metaclass(ScraperMeta, object)):
#     pass


# class KFC(IScraper):
#     START_URL = 'https://kfc.nl/api/store?rpp=all'


# class JeansWest(IScraper):
#     START_URL = ['http://www.jeanswest.com.au/en-au/store.htm']
