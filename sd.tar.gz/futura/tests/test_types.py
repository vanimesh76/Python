import json
import six
import pytest
from futura.types import StoreLocation


def test_store_location_errors():
    with pytest.raises(ValueError) as excinfo:
        s = StoreLocation(country='This is not a 2 char code')
    assert 'must be a 2' in str(excinfo.value)


def test_store_location():
    s = StoreLocation('brand_name', 'store_name', None, 'address1', 'city', 'st',
                      'zipcode', 'co', latitude=12.2, longitude=23.12, url='www.google.com')

    data = s.serialize()
    print(data)


def test_store_location_outputs():
    s = StoreLocation(
        'Wendy\'s', 'Wendy\'s at 9192 Glades Rd # A', None, '9192 Glades Rd # A',
        'Boca Raton', 'FL', '33434', 'US', latitude=12, longitude=23, url='')
    assert json.loads(json.dumps(s.to_json())) == s.to_json(), 'JSON symmetry failure!'
    s.to_mysql()
    from mysql.connector.conversion import MySQLConverter
    conv = MySQLConverter()

    for key, value in six.iteritems(s.to_mysql()):
        try:
            conv.to_mysql(value)
        except Exception:
            raise ValueError('Unable to convert {} -> {} -> mysql'.format(key, value))
